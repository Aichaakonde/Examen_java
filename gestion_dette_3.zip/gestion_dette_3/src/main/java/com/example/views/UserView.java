package com.example.views;

import java.util.List;
import java.util.Scanner;

import com.example.entities.User;

public  abstract class UserView {
    private static final Scanner scanner = new Scanner(System.in);

    public static int menu(){
        System.out.println("Menu Utilisateur");
        System.out.println("1. Admin");
        System.out.println("2 Client");
        System.out.println("3. Boutiquier");
        System.out.println("0. Quitter");
        System.out.println("Faites votre choix");
        
        return Integer.parseInt(scanner.nextLine());
    }

     public static User create(){
        String login, password;

        System.out.println("Veuillez donner le login");
        login=scanner.nextLine();
        System.out.println("Veuillez donner le mot de passe");
        password=scanner.nextLine();
        System.out.println("Veuillez donner le rôle (Admin / Boutiquier / Client) : ");
        String role = scanner.nextLine();

        
        return new User(login, password, role, false);
    }

    public static void lister(List<User> users) {
        if (users.isEmpty()) {
            System.out.println("Il n y a pas d'Utilisateur disponible");
        }
        else {
            for(User user : users) {
                 System.out.println(user);

             } 
        }   
    }
}
