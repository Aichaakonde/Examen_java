package com.example.views;

import java.util.List;
import java.util.Scanner;

import com.example.entities.Admin;

public abstract class AdminView {
     private static final Scanner scanner = new Scanner(System.in);

     public static int menu(){
        System.out.println("Menu Admin");
        System.out.println("1. Client");
        System.out.println("2. Article");
        System.out.println("3. Demande");
        System.out.println("4. Dette");
        System.out.println("5. Utilisateur");
        System.out.println("0. Quitter");
        System.out.println("Faites votre choix");

        return Integer.parseInt(scanner.nextLine());
    }

    public static void lister(List<Admin> admins) {
        if (admins.isEmpty()) {
            System.out.println("Il n y a pas d'Admin disponible");
        }
        else {
            for(Admin admin : admins) {
                 System.out.println(admin);

             } 
        }   
    }

    
}

