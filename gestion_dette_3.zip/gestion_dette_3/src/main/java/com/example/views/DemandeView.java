package com.example.views;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.example.entities.Article;
import com.example.entities.Client;
import com.example.entities.Demande;
import com.example.entities.DetailsDemande;

public class DemandeView {
    private static Scanner scanner = new Scanner(System.in);  

    public static int menuClient(){
        System.out.println("Menu Demande");
        System.out.println("1. Ajouter une demande");
        System.out.println("2. Afficher les demandes");
        System.out.println("3. Afficher les demandes en cours");
        System.out.println("4. Afficher les demades rejetées");
        System.out.println("5. Afficher les demades acceptées");
        System.out.println("6. Voir les détails d'une demande");
        System.out.println("0. Quitter");
        System.out.println("Faites votre choix ");

        return Integer.parseInt(scanner.nextLine());
    }

    public static int menu(){
        System.out.println("Menu Demande");
        System.out.println("1. Lister toutes les demandes");
        System.out.println("2. Lister les demandes en cours");
        System.out.println("3. Lister les demades rejetées");
        System.out.println("4. Lister les demades acceptées");
        System.out.println("5. Traiter une demande ");
        System.out.println("0. Quitter");
        System.out.println("Faites votre choix ");

        return Integer.parseInt(scanner.nextLine());
    }

    
    public static Demande create(List<Article>articles, Client client) {

        LocalDate date = LocalDate.now();
        double montantTotal = 0;
        List <DetailsDemande> details =new ArrayList<>();
        List <Demande> demandes = client.getDemandes();

        System.out.println("Combien d'article voulez vous?");
        int nombreArticle = Integer.parseInt(scanner.nextLine());
        
        for (int i = 0; i < nombreArticle;){
          Article article = ArticleView.rechercherArticleParLibelle(articles);
          if (article != null) {
            System.out.println("Entrer la quantite de l'article");
            int quantite = Integer.parseInt(scanner.nextLine());
            if (quantite <= article.getQteStock()) {

                DetailsDemande detailsDemande = new DetailsDemande(Long.valueOf(quantite) ,article, null);
                montantTotal += quantite * article.getPrix();
                details.add(detailsDemande);
                i++;
            } else {
                System.out.println("La quantite de l'article n'est pas disponible en stock");
            }
          } else {
            System.out.println("Cet article n'est pas disponible");
            }
        }

        if (!details.isEmpty()) {
            Demande demande = new Demande(date, montantTotal, "En cours", client,details);

            for(DetailsDemande detail: details) {
                detail.setDemande(demande);
            
            }

            demandes.add(demande);
            client.setDemandes(demandes);
        
            System.out.println("La demande a été enregistrer avec succès.");
            return demande;

        }
        System.out.println("La demande n'a pas été enregistrer.");
        return null;
    }
 

    public static void lister(List<Demande>demandes) {
        if (demandes.isEmpty()) {
            System.out.println("Il n y a pas demande disponible");  
        }
        else{
            for(Demande demande :demandes){
                System.out.println(demande);
            }
        }  
    }

    public static Demande rechercherDemandeParId (List<Demande>demandes) {
        int id = saisieIdentifiant();
        for(Demande demande :demandes){
            if (demande.getId() == id ) {
                return demande;
            }  
        }
        return null;
    }  
    public static int saisieIdentifiant(){
        System.out.println("Entrer l'identifiant de la demande");
        return Integer.parseInt(scanner.nextLine());
    }

    
    
    
}
