package com.example.views;

import java.util.List;

import com.example.entities.DetailsDemande;

public abstract class DetailsDemandeView {
    
    public static void lister(List<DetailsDemande> detailsDemandes){
       
         for(DetailsDemande detailsDemande : detailsDemandes){
                System.out.println(detailsDemande);
        }

    }
}
    

