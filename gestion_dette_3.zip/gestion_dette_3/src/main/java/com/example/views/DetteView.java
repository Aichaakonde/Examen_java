package com.example.views;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.example.entities.Article;
import com.example.entities.Client;
import com.example.entities.Dette;
import com.example.entities.Paiement;
import com.example.entities.DetailsDetteArticle;

public class DetteView {
    private static Scanner scanner = new Scanner(System.in);  

    public static int menu(){
        System.out.println("Menu Dette");
        System.out.println("1. Créer une nouvelle dette");
        System.out.println("2. Lister les dettes");
        System.out.println("3. Lister les dettes soldées");
        System.out.println("4. Lister les dettes non soldées");
        System.out.println("5. Lister les dettes d'un client");
        System.out.println("6. Voir les détails d'une dette");
        System.out.println("7. Enregistrer un paiement pour une dette");
        System.out.println("0. Quitter");
        System.out.println("Faites votre choix");
        return Integer.parseInt(scanner.nextLine());
    }

    public static int menuDettesClient(){
        System.out.println("Menu Dettes");
        System.out.println("1. Lister les dettes");
        System.out.println("2. Lister les dettes soldées");
        System.out.println("3. Lister les dettes non soldées");
        System.out.println("4. Voir les détails d'une dette");
        System.out.println("0. Quitter");
        System.out.println("Faites votre choix");
        return Integer.parseInt(scanner.nextLine());
    }

    public static int menuDettesDetails(){
        System.out.println("Menu Détails Dettes");
        System.out.println("1. Voir les articles");
        System.out.println("2. Voir les paiements");
        System.out.println("0. Quitter");
        System.out.println("Faites votre choix");
        return Integer.parseInt(scanner.nextLine());
    }

    
    public static Dette create(List<Article>articles, Client client){
        double montant =  0;
        double montantVerser=0;
        LocalDate date = LocalDate.now();
        
        List<DetailsDetteArticle> details =new ArrayList<>();
        List <Dette> dettes = client.getDettes();
        List <Paiement> paiements=new ArrayList<>() ;

        System.out.println("Combien d'article voulez vous dans cette dette");
        int nombreArticle = Integer.parseInt(scanner.nextLine());

        for (int i = 0; i < nombreArticle; i++){
            Article article = ArticleView.rechercherArticleParLibelle(articles);
            if (article!= null) {
                System.out.println("Entrer la quantite de l'article");
                int quantite = Integer.parseInt(scanner.nextLine());
                if (quantite <= article.getQteStock()) {

                DetailsDetteArticle detailsDetteArticle = new DetailsDetteArticle(quantite, article, null);
                details.add(detailsDetteArticle);

                montant += quantite * article.getPrix();

               
            } else {
                System.out.println("La quantite de l'article n'est pas disponible en stock");
            }
          } else {
            System.out.println("Cet article n'est pas disponible");

            }
        }
         if (!details.isEmpty()) {
            Dette dette = new Dette(date, montant, montantVerser,"Non soldée", client, details, paiements);


            for(DetailsDetteArticle detail: details) {
                detail.setDette(dette);

            }
            dettes.add(dette);
            client.setDettes(dettes);
        
            System.out.println("La dette a été enregistrer avec succès.");
            return dette;

        }
        System.out.println("La dette n'a pas été enregistrer.");
        return null;
    } 

    public static void lister(List<Dette>dettes) {
        if (dettes.isEmpty()) {
            System.out.println("Il n y a pas dette disponible");  
        }
        else{
            for(Dette dette :dettes){
                System.out.println(dette);
            }
        }  
    }

    public static Dette rechercherDetteParId (List<Dette>dettes) {
        int id = saisieIdentifiant();
        for(Dette dette :dettes){
            if (dette.getId() == id ) {
                return dette;
            }  
        }
        return null;
    }  


 public static int saisieIdentifiant(){
        System.out.println("Entrer l'identifiant de la dette");
        return Integer.parseInt(scanner.nextLine());
    }
    

}

