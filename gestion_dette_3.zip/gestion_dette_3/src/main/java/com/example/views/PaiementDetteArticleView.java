package com.example.views;

import java.util.List;

import com.example.entities.Paiement;



public abstract class PaiementDetteArticleView {

     public static void lister(List<Paiement> paiements) {
        if (paiements.isEmpty()) {
            System.out.println("Il n y a pas de paiement disponible");
        }
        else {
            for(Paiement paiement : paiements) {
                 System.out.println(paiement);

             } 
        }   
    }
    
}
