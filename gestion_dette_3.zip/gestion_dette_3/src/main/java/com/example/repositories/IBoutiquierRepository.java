package com.example.repositories;

import java.sql.SQLException;

import com.example.core.IRepository;
import com.example.entities.Boutiquier;

public interface IBoutiquierRepository  extends IRepository<Boutiquier> {

    Boutiquier selectByLogin(String login) throws SQLException;
    
}
