package com.example.repositories;

import java.sql.SQLException;

import com.example.entities.Article;
import com.example.core.IRepository;

public interface IArticleRepository extends IRepository <Article> {
    Article findByLibelle(String libelle) throws SQLException;
    
}
