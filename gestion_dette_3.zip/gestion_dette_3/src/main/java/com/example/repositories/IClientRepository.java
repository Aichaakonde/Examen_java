package com.example.repositories;

import com.example.core.IRepository;
import com.example.entities.Client;
import java.sql.SQLException;


public interface IClientRepository extends IRepository <Client> {
    
    Client selectByTelephone(String telephone) throws SQLException;

    Client selectByLogin(String login) throws SQLException;
}
