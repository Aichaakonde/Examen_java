package com.example.repositories;

import com.example.core.IRepository;
import com.example.entities.Paiement;

public interface IPaiementRepository extends IRepository <Paiement>{
    
}
