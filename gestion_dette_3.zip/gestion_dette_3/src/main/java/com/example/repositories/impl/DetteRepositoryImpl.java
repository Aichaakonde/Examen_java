package com.example.repositories.impl;

import com.example.entities.Dette;
import com.example.entities.DetailsDetteArticle;
import com.example.entities.Paiement;
import com.example.entities.Client;
import com.example.repositories.IDetteRepository;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class DetteRepositoryImpl implements IDetteRepository {

    private final Connection connection;

    public DetteRepositoryImpl(Connection connection) {
        this.connection = connection;
    }

    @Override
    public Dette add(Dette dette) throws SQLException {
        String query = "INSERT INTO dette (date, montant, montant_verser, statut, client_id) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {
            statement.setDate(1, Date.valueOf(dette.getDate()));
            statement.setDouble(2, dette.getMontant());
            statement.setDouble(3, dette.getMontantVerser());
            statement.setString(4, dette.getStatut());
            statement.setLong(5, dette.getClient().getId()); 

            int affectedRows = statement.executeUpdate();
            if (affectedRows > 0) {
                try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        Long id = generatedKeys.getLong(1);
                        dette.setId(id);
                        return dette;
                    }
                }
            }
        }
        return null;
    }

    @Override
    public List<Dette> selectAll() throws SQLException {
        String query = "SELECT * FROM dette";
        List<Dette> dettes = new ArrayList<>();

        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {

            while (resultSet.next()) {
                dette = mapResultSetToDette(resultSet);
                dettes.add(dette);
            }
        }
        return dettes;
    }

    @Override
    public Dette findById(Long id) throws SQLException {
        String query = "SELECT * FROM dette WHERE id = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setLong(1, id);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    return mapResultSetToDette(resultSet);
                }
            }
        }
        return null;
    }

    @Override
    public void update(Dette dette) throws SQLException {
        String query = "UPDATE dette SET date = ?, montant = ?, montant_verser = ?, statut = ?, client_id = ? WHERE id = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setDate(1, Date.valueOf(dette.getDate()));
            statement.setDouble(2, dette.getMontant());
            statement.setDouble(3, dette.getMontantVerser());
            statement.setString(4, dette.getStatut());
            statement.setLong(5, dette.getClient().getId());
            statement.setLong(6, dette.getId());

            statement.executeUpdate();
        }
    }

    @Override
    public void delete(Dette dette) throws SQLException {
        deleteById(dette.getId());
    }

    @Override
    public void deleteById(Long id) throws SQLException {
        String query = "DELETE FROM dette WHERE id = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setLong(1, id);
            statement.executeUpdate();
        }
    }

    private Dette mapResultSetToDette(ResultSet resultSet) throws SQLException {
        Long id = resultSet.getLong("id");
        LocalDate date = resultSet.getDate("date").toLocalDate();
        double montant = resultSet.getDouble("montant");
        double montantVerser = resultSet.getDouble("montant_verser");
        String statut = resultSet.getString("statut");
        Long clientId = resultSet.getLong("client_id");

        // Récupérer le client
        Client client = new Client(clientId, "Nom Client", "Prenom Client", statut, null, null, null); 

        // Récupérer les paiements et détails liés
        List<DetailsDetteArticle> detailsDetteArticles = fetchDetailsDetteArticles(id);
        List<Paiement> paiements = fetchPaiements(id);

        return new Dette(id, date, montant, montantVerser, statut, detailsDetteArticles, paiements, client);
    }

    private List<DetailsDetteArticle> fetchDetailsDetteArticles(Long detteId) throws SQLException {
        String query = "SELECT * FROM details_dette_article WHERE dette_id = ?";
        List<DetailsDetteArticle> details = new ArrayList<>();
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setLong(1, detteId);
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    DetailsDetteArticle detail = new DetailsDetteArticle(
                            resultSet.getLong("id"),
                            resultSet.getLong("quantite"),
                            new Article(resultSet.getLong("article_id")), 
                            new Dette(detteId) 
                    );
                    details.add(detail);
                }
            }
        }
        return details;
    }

    private List<Paiement> fetchPaiements(Long detteId) throws SQLException {
        String query = "SELECT * FROM paiement WHERE dette_id = ?";
        List<Paiement> paiements = new ArrayList<>();
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setLong(1, detteId);
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    Paiement paiement = new Paiement(
                            resultSet.getLong("id"),
                            resultSet.getDouble("montant"),
                            resultSet.getDate("date").toLocalDate(),
                            new Dette(detteId)
                    );
                    paiements.add(paiement);
                }
            }
        }
        return paiements;
    }

    @Override
    public List<Dette> findByStatut(String statut) throws SQLException {
        String query = "SELECT * FROM dette WHERE statut = ?";
        List<Dette> dettes = new ArrayList<>();

        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, statut);
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    dette = mapResultSetToDette(resultSet);
                    dettes.add(dette);
                }
            }
        }
        return dettes;
    }

    @Override
    public List<Dette> findByClient(Client client) throws SQLException {
        String query = "SELECT * FROM dette WHERE client_id = ?";
        List<Dette> dettes = new ArrayList<>();

        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setLong(1, client.getId());
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    dette = mapResultSetToDette(resultSet);
                    dettes.add(dette);
                }
            }
        }
        return dettes;
    }

    @Override
    public List<Dette> findByClientAndStatut(Client client, String statut) throws SQLException {
        String query = "SELECT * FROM dette WHERE client_id = ? AND statut = ?";
        List<Dette> dettes = new ArrayList<>();

        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setLong(1, client.getId());
            statement.setString(2, statut);
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    dette = mapResultSetToDette(resultSet);
                    dettes.add(dette);
                }
            }
        }
        return dettes;
    }
}
