package com.example.repositories.impl;

import com.example.entities.Boutiquier;
import com.example.repositories.IBoutiquierRepository;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;

import java.util.List;

public class BoutiquierRepositoryImpl implements IBoutiquierRepository {

    // Utilisation de l'EntityManager pour les opérations de persistance
    @PersistenceContext
    private EntityManager entityManager;

    // Ajouter un boutiquier
    @Override
    @Transactional
    public Boutiquier add(Boutiquier boutiquier) {
        entityManager.persist(boutiquier); // Persiste le boutiquier dans la base de données
        return boutiquier;
    }

    // Sélectionner tous les boutiquiers
    @Override
    public List<Boutiquier> selectAll() {
        return entityManager.createQuery("SELECT b FROM Boutiquier b", Boutiquier.class).getResultList();
    }

    // Trouver un boutiquier par son identifiant
    @Override
    public Boutiquier findById(Long id) {
        return entityManager.find(Boutiquier.class, id); // Recherche le boutiquier par son ID
    }

    // Trouver un boutiquier par son login
    @Override
    public Boutiquier selectByLogin(String login) {
        return entityManager.createQuery("SELECT b FROM Boutiquier b WHERE b.user.login = :login", Boutiquier.class)
                .setParameter("login", login)
                .getResultStream()
                .findFirst()
                .orElse(null); // Retourne null si aucun boutiquier n'est trouvé
    }

    // Mettre à jour un boutiquier
    @Override
    @Transactional
    public void update(Boutiquier entity) {
        entityManager.merge(entity); // Met à jour le boutiquier dans la base de données
    }

    // Supprimer un boutiquier
    @Override
    @Transactional
    public void delete(Boutiquier entity) {
        Boutiquier managedBoutiquier = entityManager.find(Boutiquier.class, entity.getId());
        if (managedBoutiquier != null) {
            entityManager.remove(managedBoutiquier); // Supprime le boutiquier de la base de données
        }
    }

    // Supprimer un boutiquier par son identifiant
    @Override
    @Transactional
    public void deleteById(Long id) {
        Boutiquier boutiquier = entityManager.find(Boutiquier.class, id);
        if (boutiquier != null) {
            entityManager.remove(boutiquier); // Supprime le boutiquier de la base de données
        }
    }
}
