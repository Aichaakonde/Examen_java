package com.example.repositories;

import java.sql.SQLException;
import java.util.List;

import com.example.core.IRepository;
import com.example.entities.Client;
import com.example.entities.Dette;

public interface IDetteRepository  extends IRepository <Dette>{
    List<Dette> findByStatut(String statut) throws SQLException;
    List<Dette> findByClient(Client client) throws SQLException;
    List<Dette> findByClientAndStatut(Client client, String statut) throws SQLException;
    
}
