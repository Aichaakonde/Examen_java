package com.example.repositories.impl;

import com.example.entities.Article;
import com.example.repositories.IArticleRepository;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;

import java.util.List;

public class ArticleRepositoryImpl implements IArticleRepository {

    // Utilisation de l'EntityManager pour interagir avec la base de données
    @PersistenceContext
    private EntityManager entityManager;

    // Ajouter un article
    @Override
    @Transactional
    public Article add(Article article) {
        entityManager.persist(article); // Persiste l'article dans la base de données
        return article;
    }

    // Sélectionner tous les articles
    @Override
    public List<Article> selectAll() {
        return entityManager.createQuery("SELECT a FROM Article a", Article.class).getResultList();
    }

    // Trouver un article par son identifiant
    @Override
    public Article findById(Long id) {
        return entityManager.find(Article.class, id);
    }

    // Mettre à jour un article
    @Override
    @Transactional
    public void update(Article article) {
        entityManager.merge(article); // Met à jour l'article dans la base de données
    }

    // Supprimer un article
    @Override
    @Transactional
    public void delete(Article article) {
        Article managedArticle = entityManager.find(Article.class, article.getId());
        if (managedArticle != null) {
            entityManager.remove(managedArticle); // Supprime l'article de la base de données
        }
    }

    // Supprimer un article par son identifiant
    @Override
    @Transactional
    public void deleteById(Long id) {
        Article article = entityManager.find(Article.class, id);
        if (article != null) {
            entityManager.remove(article); // Supprime l'article de la base de données
        }
    }

    // Trouver un article par son libellé
    @Override
    public Article findByLibelle(String libelle) {
        return entityManager.createQuery("SELECT a FROM Article a WHERE a.nom = :nom", Article.class)
                .setParameter("nom", libelle)
                .getResultStream()
                .findFirst()
                .orElse(null); // Si aucun résultat, retourne null
    }
}
