package com.example.repositories.impl;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.example.entities.Article;
import com.example.entities.Demande;
import com.example.entities.DetailsDemande;
import com.example.repositories.IDetailsDemandeRepository;

public class DetailsDemandeRepositoryImpl implements IDetailsDemandeRepository {

    private final Connection connection;

    public DetailsDemandeRepositoryImpl(Connection connection) {
        this.connection = connection;
    }

    @Override
    public DetailsDemande add(DetailsDemande detailsDemande) {
        String sql = "INSERT INTO details_demandes (id, quantite, article_id, demande_id) VALUES (?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setLong(1, detailsDemande.getId());
            stmt.setLong(2, detailsDemande.getQuantite());
            stmt.setLong(3, detailsDemande.getArticle().getId());
            stmt.setLong(4, detailsDemande.getDemande().getId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
        return detailsDemande;
    }

    @Override
    public List<DetailsDemande> selectAll() {
        List<DetailsDemande> detailsDemandes = new ArrayList<>();
        String sql = "SELECT * FROM details_demandes";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                detailsDemandes.add(mapRowToDetailsDemande(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return detailsDemandes;
    }

    @Override
    public DetailsDemande findById(Long id) {
        String sql = "SELECT * FROM details_demandes WHERE id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setLong(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapRowToDetailsDemande(rs);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public void update(DetailsDemande detailsDemande) {
        String sql = "UPDATE details_demandes SET quantite = ?, article_id = ?, demande_id = ? WHERE id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setLong(1, detailsDemande.getQuantite());
            stmt.setLong(2, detailsDemande.getArticle().getId());
            stmt.setLong(3, detailsDemande.getDemande().getId());
            stmt.setLong(4, detailsDemande.getId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void delete(DetailsDemande detailsDemande) {
        try {
            deleteById(detailsDemande.getId());
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private DetailsDemande mapRowToDetailsDemande(ResultSet rs) throws SQLException {
        DetailsDemande detailsDemande = new DetailsDemande();
        detailsDemande.setId(rs.getLong("id"));
        detailsDemande.setQuantite(rs.getLong("quantite"));

        // Assuming Article and Demande objects can be fetched by their IDs
        Article article = new Article();
        article.setId(rs.getLong("article_id"));
        detailsDemande.setArticle(article);

        Demande demande = new Demande();
        demande.setId(rs.getLong("demande_id"));
        detailsDemande.setDemande(demande);

        return detailsDemande;
    }

    @Override
    public void deleteById(Long id) throws SQLException {
        String sql = "DELETE FROM details_demandes WHERE id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setLong(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
