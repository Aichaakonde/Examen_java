package com.example.repositories.impl;

import com.example.entities.Client;
import com.example.entities.User;
import com.example.repositories.IClientRepository;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;

import java.util.List;

public class ClientRepositoryImpl implements IClientRepository {

    // Utilisation de l'EntityManager pour la gestion des entités
    @PersistenceContext
    private EntityManager entityManager;

    // Ajouter un client
    @Override
    @Transactional
    public Client add(Client client) {
        if (client.getUser() != null) {
            // Si un utilisateur est associé, on s'assure qu'il est persisté avant le client
            entityManager.persist(client.getUser());
        }
        entityManager.persist(client);  // Persiste le client dans la base de données
        return client;
    }

    // Récupérer tous les clients
    @Override
    public List<Client> selectAll() {
        return entityManager.createQuery("SELECT c FROM Client c", Client.class).getResultList();
    }

    // Récupérer un client par son téléphone
    @Override
    public Client selectByTelephone(String telephone) {
        try {
            return entityManager.createQuery("SELECT c FROM Client c WHERE c.telephone = :telephone", Client.class)
                    .setParameter("telephone", telephone)
                    .getSingleResult();
        } catch (Exception e) {
            return null;  // Aucun client trouvé
        }
    }

    // Récupérer un client par son login
    @Override
    public Client selectByLogin(String login) {
        try {
            return entityManager.createQuery(
                    "SELECT c FROM Client c WHERE c.user.login = :login", Client.class)
                    .setParameter("login", login)
                    .getSingleResult();
        } catch (Exception e) {
            return null;  // Aucun client trouvé
        }
    }

    // Mettre à jour un client
    @Override
    @Transactional
    public void update(Client client) {
        entityManager.merge(client);  // Met à jour le client existant dans la base de données
    }

    // Supprimer un client
    @Override
    @Transactional
    public void delete(Client client) {
        Client managedClient = entityManager.find(Client.class, client.getId());
        if (managedClient != null) {
            entityManager.remove(managedClient);  // Supprime le client de la base de données
        }
    }

    // Supprimer un client par son ID
    @Override
    @Transactional
    public void deleteById(Long id) {
        Client client = entityManager.find(Client.class, id);
        if (client != null) {
            entityManager.remove(client);  // Supprime le client de la base de données
        }
    }

    // Trouver un client par son ID
    @Override
    public Client findById(Long id) {
        return entityManager.find(Client.class, id);  // Recherche le client par son ID
    }
}
