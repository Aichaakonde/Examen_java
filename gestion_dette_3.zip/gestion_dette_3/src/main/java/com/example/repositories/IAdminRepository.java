package com.example.repositories;

import java.sql.SQLException;

import com.example.core.IRepository;
import com.example.entities.Admin;

public interface IAdminRepository extends IRepository<Admin> {

    Admin selectByLogin(String login) throws SQLException;
}
