package com.example.repositories.impl;

import com.example.entities.Admin;
import com.example.entities.User;
import com.example.repositories.IAdminRepository;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;


import java.util.List;

public class AdminRepositoryImpl implements IAdminRepository {

    // Utilisation de l'EntityManager pour interagir avec la base de données
    @PersistenceContext
    private EntityManager entityManager;

    // Ajout d'un nouvel admin
    @Override
    @Transactional
    public Admin add(Admin admin) {
        entityManager.persist(admin); // Persiste l'objet Admin dans la base de données
        return admin;
    }

    // Sélectionner tous les admins
    @Override
    public List<Admin> selectAll() {
        return entityManager.createQuery("SELECT a FROM Admin a", Admin.class).getResultList();
    }

    // Trouver un admin par son identifiant
    @Override
    public Admin findById(Long id) {
        return entityManager.find(Admin.class, id);
    }

    // Sélectionner un admin par son login
    @Override
    public Admin selectByLogin(String login) {
        return entityManager.createQuery(
                "SELECT a FROM Admin a JOIN a.user u WHERE u.login = :login", Admin.class)
                .setParameter("login", login)
                .getResultStream()
                .findFirst()
                .orElse(null); // Si aucun résultat, retourne null
    }

    // Mettre à jour un admin
    @Override
    @Transactional
    public void update(Admin admin) {
        entityManager.merge(admin); // Met à jour l'objet Admin dans la base de données
    }

    // Supprimer un admin
    @Override
    @Transactional
    public void delete(Admin admin) {
        Admin managedAdmin = entityManager.find(Admin.class, admin.getId());
        if (managedAdmin != null) {
            entityManager.remove(managedAdmin); // Supprime l'admin de la base de données
        }
    }

    // Supprimer un admin par son identifiant
    @Override
    @Transactional
    public void deleteById(Long id) {
        Admin admin = entityManager.find(Admin.class, id);
        if (admin != null) {
            entityManager.remove(admin); // Supprime l'admin de la base de données
        }
    }
}
