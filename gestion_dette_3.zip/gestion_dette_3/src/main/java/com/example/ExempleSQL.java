package com.example;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.SQLException;

public class ExempleSQL {
    public static void main(String[] args) {
        try {
            connectToDatabase();
        } catch (SQLException e) {
            System.out.println("Erreur SQL : " + e.getMessage());
        }
    }

    // Cette méthode peut lever une SQLException
    public static void connectToDatabase() throws SQLException {
        String url = "jdbc:postgresql://localhost:5432/gestion_dette"; // URL de connexion PostgreSQL
        String user = "postgres"; // Nom d'utilisateur PostgreSQL
        String password = "passer123"; // Mot de passe PostgreSQL

        // Connexion à la base de données
        Connection conn = DriverManager.getConnection(url, user, password);

        // Création d'une requête
        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT * FROM utilisateurs");

        // Lecture des résultats
        while (rs.next()) {
            System.out.println("Nom : " + rs.getString("nom"));
        }

        // Fermeture des ressources
        rs.close();
        stmt.close();
        conn.close();
    }
}
