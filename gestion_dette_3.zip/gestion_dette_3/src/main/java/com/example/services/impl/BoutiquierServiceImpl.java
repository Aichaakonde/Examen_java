package com.example.services.impl;

import com.example.entities.Boutiquier;
import com.example.repositories.IBoutiquierRepository;
import com.example.services.IBoutiquierService;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import java.sql.SQLException;
import java.util.List;

public class BoutiquierServiceImpl implements IBoutiquierService {
    private final IBoutiquierRepository boutiquierRepository;
    private final EntityManager entityManager;

    public BoutiquierServiceImpl(IBoutiquierRepository boutiquierRepository, EntityManager entityManager) {
        this.boutiquierRepository = boutiquierRepository;
        this.entityManager = entityManager;
    }

    @Override
    public Boutiquier add(Boutiquier boutiquier) throws SQLException {
        EntityTransaction transaction = entityManager.getTransaction();
        try {
            transaction.begin();
            entityManager.persist(boutiquier);
            transaction.commit();
            return boutiquier;
        } catch (Exception e) {
            transaction.rollback();
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public List<Boutiquier> selectAll() throws SQLException {
        return boutiquierRepository.selectAll();
    }

    @Override
    public Boutiquier findById(Long id) throws SQLException {
        return boutiquierRepository.findById(id);
    }

    @Override
    public void update(Boutiquier boutiquier) throws SQLException {
        EntityTransaction transaction = entityManager.getTransaction();
        try {
            transaction.begin();
            entityManager.merge(boutiquier);
            transaction.commit();
        } catch (Exception e) {
            transaction.rollback();
            e.printStackTrace();
        }
    }

    @Override
    public void delete(Boutiquier boutiquier) throws SQLException {
        EntityTransaction transaction = entityManager.getTransaction();
        try {
            transaction.begin();
            entityManager.remove(entityManager.contains(boutiquier) ? boutiquier : entityManager.merge(boutiquier));
            transaction.commit();
        } catch (Exception e) {
            transaction.rollback();
            e.printStackTrace();
        }
    }

    @Override
    public void deleteById(Long id) throws SQLException {
        Boutiquier boutiquier = findById(id);
        if (boutiquier != null) {
            delete(boutiquier);
        }
    }
}
