package com.example.services.impl;

import com.example.entities.Demande;
import com.example.repositories.IDemandeRepository;
import com.example.services.IDemandeService;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import java.sql.SQLException;
import java.util.List;

public class DemandeServiceImpl implements IDemandeService {
    private final IDemandeRepository demandeRepository;
    private final EntityManager entityManager;

    public DemandeServiceImpl(IDemandeRepository demandeRepository, EntityManager entityManager) {
        this.demandeRepository = demandeRepository;
        this.entityManager = entityManager;
    }

    @Override
    public Demande add(Demande demande) throws SQLException {
        EntityTransaction transaction = entityManager.getTransaction();
        try {
            transaction.begin();
            entityManager.persist(demande);
            transaction.commit();
            return demande;
        } catch (Exception e) {
            transaction.rollback();
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public List<Demande> selectAll() throws SQLException {
        return demandeRepository.selectAll();
    }

    @Override
    public Demande findById(Long id) throws SQLException {
        return demandeRepository.findById(id);
    }

    @Override
    public void update(Demande demande) throws SQLException {
        EntityTransaction transaction = entityManager.getTransaction();
        try {
            transaction.begin();
            entityManager.merge(demande);
            transaction.commit();
        } catch (Exception e) {
            transaction.rollback();
            e.printStackTrace();
        }
    }

    @Override
    public void delete(Demande demande) throws SQLException {
        EntityTransaction transaction = entityManager.getTransaction();
        try {
            transaction.begin();
            entityManager.remove(entityManager.contains(demande) ? demande : entityManager.merge(demande));
            transaction.commit();
        } catch (Exception e) {
            transaction.rollback();
            e.printStackTrace();
        }
    }

    @Override
    public void deleteById(Long id) throws SQLException {
        Demande demande = findById(id);
        if (demande != null) {
            delete(demande);
        }
    }

    @Override
    public void addDetail(Long id, Long id2, long quantite) {
        // La logique pour ajouter des détails peut être implémentée ici
        throw new UnsupportedOperationException("Unimplemented method 'addDetail'");
    }
}
