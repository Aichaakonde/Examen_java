package com.example.services;

import java.sql.SQLException;

import com.example.core.IService;
import com.example.entities.Article;

public interface IArticleService extends IService <Article> {

        Article findByLibelle(String libelle) throws SQLException;

    
}
