package com.example.services.impl;

import com.example.entities.Admin;
import com.example.repositories.IAdminRepository;
import com.example.services.IAdminService;
import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import java.util.List;

public class AdminServiceImpl implements IAdminService {
    private final IAdminRepository adminRepository;
    private final EntityManager entityManager;

    public AdminServiceImpl(IAdminRepository adminRepository, EntityManager entityManager) {
        this.adminRepository = adminRepository;
        this.entityManager = entityManager;
    }

    @Override
    public Admin selectByLogin(String login) {
        return adminRepository.selectByLogin(login);
    }

    @Override
    public Admin add(Admin entity) {
        EntityTransaction transaction = entityManager.getTransaction();
        try {
            transaction.begin();
            entityManager.persist(entity);
            transaction.commit();
            return entity;
        } catch (Exception e) {
            transaction.rollback();
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public List<Admin> selectAll() {
        return adminRepository.selectAll();
    }

    @Override
    public Admin findById(Long id) {
        return adminRepository.findById(id);
    }

    @Override
    public void update(Admin entity) {
        EntityTransaction transaction = entityManager.getTransaction();
        try {
            transaction.begin();
            entityManager.merge(entity);
            transaction.commit();
        } catch (Exception e) {
            transaction.rollback();
            e.printStackTrace();
        }
    }

    @Override
    public void delete(Admin entity) {
        EntityTransaction transaction = entityManager.getTransaction();
        try {
            transaction.begin();
            entityManager.remove(entityManager.contains(entity) ? entity : entityManager.merge(entity));
            transaction.commit();
        } catch (Exception e) {
            transaction.rollback();
            e.printStackTrace();
        }
    }

    @Override
    public void deleteById(Long id) {
        Admin admin = findById(id);
        if (admin != null) {
            delete(admin);
        }
    }
}
