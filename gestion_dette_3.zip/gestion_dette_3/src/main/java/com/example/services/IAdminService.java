package com.example.services;

import java.sql.SQLException;

import com.example.core.IAccount;
import com.example.core.IService;
import com.example.entities.Admin;

public interface IAdminService extends IService<Admin> , IAccount<Admin> {
 
    Admin selectByLogin(String login) throws SQLException;

}
