package com.example.services.impl;

import com.example.entities.Article;
import com.example.repositories.IArticleRepository;
import com.example.services.IArticleService;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import java.sql.SQLException;
import java.util.List;

public class ArticleServiceImpl implements IArticleService {
    private final IArticleRepository articleRepository;
    private final EntityManager entityManager;

    public ArticleServiceImpl(IArticleRepository articleRepository, EntityManager entityManager) {
        this.articleRepository = articleRepository;
        this.entityManager = entityManager;
    }

    @Override
    public Article add(Article article) throws SQLException {
        EntityTransaction transaction = entityManager.getTransaction();
        try {
            transaction.begin();
            entityManager.persist(article);
            transaction.commit();
            return article;
        } catch (Exception e) {
            transaction.rollback();
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public List<Article> selectAll() throws SQLException {
        return articleRepository.selectAll();
    }

    @Override
    public Article findById(Long id) throws SQLException {
        return articleRepository.findById(id);
    }

    @Override
    public void update(Article article) throws SQLException {
        EntityTransaction transaction = entityManager.getTransaction();
        try {
            transaction.begin();
            entityManager.merge(article);
            transaction.commit();
        } catch (Exception e) {
            transaction.rollback();
            e.printStackTrace();
        }
    }

    @Override
    public void delete(Article article) throws SQLException {
        EntityTransaction transaction = entityManager.getTransaction();
        try {
            transaction.begin();
            entityManager.remove(entityManager.contains(article) ? article : entityManager.merge(article));
            transaction.commit();
        } catch (Exception e) {
            transaction.rollback();
            e.printStackTrace();
        }
    }

    @Override
    public void deleteById(Long id) throws SQLException {
        Article article = findById(id);
        if (article != null) {
            delete(article);
        }
    }
}
