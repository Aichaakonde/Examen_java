package com.example.services.impl;

import com.example.entities.User;
import com.example.repositories.IUserRepository;
import com.example.services.IUserService;

import java.sql.SQLException;
import java.util.List;

public class UserServiceImpl implements IUserService {

    private final IUserRepository userRepository;

    public UserServiceImpl(IUserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public User add(User user) throws SQLException {
        return userRepository.add(user);
    }

    @Override
    public List<User> selectAll() throws SQLException {
        return userRepository.selectAll(); 
    }

    @Override
    public User findById(Long id) throws SQLException {
        return userRepository.findById(id); 
    }

    @Override
    public void update(User user) throws SQLException {
        userRepository.update(user); 
    }

    @Override
    public void delete(User user) throws SQLException {
        userRepository.delete(user); 
    }

    @Override
    public void deleteById(Long id) throws SQLException {
        userRepository.deleteById(id); 
    }
}
