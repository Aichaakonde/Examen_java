package com.example.services.impl;

import com.example.entities.Client;
import com.example.repositories.IClientRepository;
import com.example.services.IClientService;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import java.sql.SQLException;
import java.util.List;

public class ClientServiceImpl implements IClientService {
    private final IClientRepository clientRepository;
    private final EntityManager entityManager;

    public ClientServiceImpl(IClientRepository clientRepository, EntityManager entityManager) {
        this.clientRepository = clientRepository;
        this.entityManager = entityManager;
    }

    @Override
    public Client add(Client client) throws SQLException {
        EntityTransaction transaction = entityManager.getTransaction();
        try {
            transaction.begin();
            entityManager.persist(client);
            transaction.commit();
            return client;
        } catch (Exception e) {
            transaction.rollback();
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public List<Client> selectAll() throws SQLException {
        return clientRepository.selectAll();
    }

    @Override
    public Client findById(Long id) throws SQLException {
        return clientRepository.findById(id);
    }

    @Override
    public void update(Client client) throws SQLException {
        EntityTransaction transaction = entityManager.getTransaction();
        try {
            transaction.begin();
            entityManager.merge(client);
            transaction.commit();
        } catch (Exception e) {
            transaction.rollback();
            e.printStackTrace();
        }
    }

    @Override
    public void delete(Client client) throws SQLException {
        EntityTransaction transaction = entityManager.getTransaction();
        try {
            transaction.begin();
            entityManager.remove(entityManager.contains(client) ? client : entityManager.merge(client));
            transaction.commit();
        } catch (Exception e) {
            transaction.rollback();
            e.printStackTrace();
        }
    }

    @Override
    public void deleteById(Long id) throws SQLException {
        Client client = findById(id);
        if (client != null) {
            delete(client);
        }
    }
}
