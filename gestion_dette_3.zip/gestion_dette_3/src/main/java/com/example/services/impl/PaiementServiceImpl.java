package com.example.services.impl;

import com.example.entities.Paiement;
import com.example.repositories.IPaiementRepository;
import com.example.services.IPaiementService;

import java.sql.SQLException;
import java.util.List;

public class PaiementServiceImpl implements IPaiementService {

    private final IPaiementRepository paiementRepository;

    public PaiementServiceImpl(IPaiementRepository paiementRepository) {
        this.paiementRepository = paiementRepository;
    }

    @Override
    public Paiement add(Paiement paiement) throws SQLException {
        return paiementRepository.add(paiement);
    }

    @Override
    public List<Paiement> selectAll() throws SQLException {
        return paiementRepository.selectAll();
    }

    @Override
    public Paiement findById(Long id) throws SQLException {
        return paiementRepository.findById(id);
    }

    @Override
    public void update(Paiement paiement) throws SQLException {
        paiementRepository.update(paiement);
    }

    @Override
    public void delete(Paiement paiement) throws SQLException {
        paiementRepository.delete(paiement);
    }

    @Override
    public void deleteById(Long id) throws SQLException {
        paiementRepository.deleteById(id);
    }
}
