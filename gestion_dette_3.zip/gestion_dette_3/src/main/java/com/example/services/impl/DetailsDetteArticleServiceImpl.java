package com.example.services.impl;

import com.example.entities.DetailsDetteArticle;
import com.example.repositories.IDetailsDetteArticleRepository;
import com.example.services.IDetailsDetteArticleService;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import java.sql.SQLException;
import java.util.List;

public class DetailsDetteArticleServiceImpl implements IDetailsDetteArticleService {
    private final IDetailsDetteArticleRepository detailsDetteArticleRepository;
    private final EntityManager entityManager;

    public DetailsDetteArticleServiceImpl(IDetailsDetteArticleRepository detailsDetteArticleRepository, EntityManager entityManager) {
        this.detailsDetteArticleRepository = detailsDetteArticleRepository;
        this.entityManager = entityManager;
    }

    @Override
    public DetailsDetteArticle add(DetailsDetteArticle detailsDetteArticle) throws SQLException {
        EntityTransaction transaction = entityManager.getTransaction();
        try {
            transaction.begin();
            entityManager.persist(detailsDetteArticle);
            transaction.commit();
            return detailsDetteArticle;
        } catch (Exception e) {
            transaction.rollback();
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public List<DetailsDetteArticle> selectAll() throws SQLException {
        return detailsDetteArticleRepository.selectAll();
    }

    @Override
    public DetailsDetteArticle findById(Long id) throws SQLException {
        return detailsDetteArticleRepository.findById(id);
    }

    @Override
    public void update(DetailsDetteArticle detailsDetteArticle) throws SQLException {
        EntityTransaction transaction = entityManager.getTransaction();
        try {
            transaction.begin();
            entityManager.merge(detailsDetteArticle);
            transaction.commit();
        } catch (Exception e) {
            transaction.rollback();
            e.printStackTrace();
        }
    }

    @Override
    public void delete(DetailsDetteArticle detailsDetteArticle) throws SQLException {
        EntityTransaction transaction = entityManager.getTransaction();
        try {
            transaction.begin();
            entityManager.remove(entityManager.contains(detailsDetteArticle) ? detailsDetteArticle : entityManager.merge(detailsDetteArticle));
            transaction.commit();
        } catch (Exception e) {
            transaction.rollback();
            e.printStackTrace();
        }
    }

    @Override
    public void deleteById(Long id) throws SQLException {
        DetailsDetteArticle detailsDetteArticle = findById(id);
        if (detailsDetteArticle != null) {
            delete(detailsDetteArticle);
        }
    }
}
