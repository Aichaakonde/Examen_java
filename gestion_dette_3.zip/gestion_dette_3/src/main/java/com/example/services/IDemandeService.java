package com.example.services;

import java.sql.SQLException;
import java.util.List;

import com.example.core.IService;
import com.example.entities.Client;
import com.example.entities.Demande;

public interface IDemandeService extends IService <Demande> {
        List<Demande> findByEtat(String etat) throws SQLException;
    List<Demande> findByClient(Client client) throws SQLException;
    List<Demande> findByClientandEtat(Client client, String etat) throws SQLException;
    void addDetail(Long id, Long id2, long quantite);

    
}
