package com.example.services.impl;

import com.example.entities.DetailsDemande;
import com.example.repositories.IDetailsDemandeRepository;
import com.example.services.IDetailsDemandeService;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import java.sql.SQLException;
import java.util.List;

public class DetailsDemandeServiceImpl implements IDetailsDemandeService {
    private final IDetailsDemandeRepository detailsDemandeRepository;
    private final EntityManager entityManager;

    public DetailsDemandeServiceImpl(IDetailsDemandeRepository detailsDemandeRepository, EntityManager entityManager) {
        this.detailsDemandeRepository = detailsDemandeRepository;
        this.entityManager = entityManager;
    }

    @Override
    public DetailsDemande add(DetailsDemande detailsDemande) throws SQLException {
        EntityTransaction transaction = entityManager.getTransaction();
        try {
            transaction.begin();
            entityManager.persist(detailsDemande);
            transaction.commit();
            return detailsDemande;
        } catch (Exception e) {
            transaction.rollback();
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public List<DetailsDemande> selectAll() throws SQLException {
        return detailsDemandeRepository.selectAll();
    }

    @Override
    public DetailsDemande findById(Long id) throws SQLException {
        return detailsDemandeRepository.findById(id);
    }

    @Override
    public void update(DetailsDemande detailsDemande) throws SQLException {
        EntityTransaction transaction = entityManager.getTransaction();
        try {
            transaction.begin();
            entityManager.merge(detailsDemande);
            transaction.commit();
        } catch (Exception e) {
            transaction.rollback();
            e.printStackTrace();
        }
    }

    @Override
    public void delete(DetailsDemande detailsDemande) throws SQLException {
        EntityTransaction transaction = entityManager.getTransaction();
        try {
            transaction.begin();
            entityManager.remove(entityManager.contains(detailsDemande) ? detailsDemande : entityManager.merge(detailsDemande));
            transaction.commit();
        } catch (Exception e) {
            transaction.rollback();
            e.printStackTrace();
        }
    }

    @Override
    public void deleteById(Long id) throws SQLException {
        DetailsDemande detailsDemande = findById(id);
        if (detailsDemande != null) {
            delete(detailsDemande);
        }
    }
}
