package com.example.services.impl;

import com.example.entities.Dette;
import com.example.repositories.IDetteRepository;
import com.example.services.IDetteService;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import java.sql.SQLException;
import java.util.List;

public class DetteServiceImpl implements IDetteService {

    private final IDetteRepository detteRepository;
    private final EntityManager entityManager;

    public DetteServiceImpl(IDetteRepository detteRepository, EntityManager entityManager) {
        this.detteRepository = detteRepository;
        this.entityManager = entityManager;
    }

    @Override
    public Dette add(Dette dette) throws SQLException {
        EntityTransaction transaction = entityManager.getTransaction();
        try {
            transaction.begin();
            entityManager.persist(dette);
            transaction.commit();
            return dette;
        } catch (Exception e) {
            transaction.rollback();
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public List<Dette> selectAll() throws SQLException {
        return detteRepository.selectAll();
    }

    @Override
    public Dette findById(Long id) throws SQLException {
        return detteRepository.findById(id);
    }

    @Override
    public void update(Dette dette) throws SQLException {
        EntityTransaction transaction = entityManager.getTransaction();
        try {
            transaction.begin();
            entityManager.merge(dette);
            transaction.commit();
        } catch (Exception e) {
            transaction.rollback();
            e.printStackTrace();
        }
    }

    @Override
    public void delete(Dette dette) throws SQLException {
        EntityTransaction transaction = entityManager.getTransaction();
        try {
            transaction.begin();
            entityManager.remove(entityManager.contains(dette) ? dette : entityManager.merge(dette));
            transaction.commit();
        } catch (Exception e) {
            transaction.rollback();
            e.printStackTrace();
        }
    }

    @Override
    public void deleteById(Long id) throws SQLException {
        Dette dette = findById(id);
        if (dette != null) {
            delete(dette);
        }
    }
}
