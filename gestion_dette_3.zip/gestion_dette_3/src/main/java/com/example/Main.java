package com.example;

import com.example.datasource.PostgreSQLDataSourceImpl;
import com.example.entities.User;
import com.example.repositories.impl.UserRepositoryImpl;
import com.example.services.impl.UserServiceImpl;

import java.sql.SQLException;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        // Créer une instance de PostgreSQLDataSourceImpl
        PostgreSQLDataSourceImpl dataSource = PostgreSQLDataSourceImpl.getInstance();

        // Tester la connexion à la base de données
        testConnection(dataSource);

        // Initialiser le UserRepository et UserService
        UserRepositoryImpl userRepository = new UserRepositoryImpl(dataSource);
        UserServiceImpl userService = new UserServiceImpl(userRepository);

        // Exemples d'utilisation du service utilisateur
        try {
            // Ajouter un nouvel utilisateur
            User newUser = new User("aicha", "passer123", "ADMIN", true);
            userService.add(newUser);
            System.out.println("Utilisateur ajouté : " + newUser);

            // Lister tous les utilisateurs
            List<User> users = userService.selectAll();
            System.out.println("Liste des utilisateurs :");
            users.forEach(System.out::println);

            // Trouver un utilisateur par ID
            User foundUser = userService.findById(newUser.getId());
            System.out.println("Utilisateur trouvé : " + foundUser);

            // Mettre à jour un utilisateur
            if (foundUser != null) {
                foundUser.setPassword("newpassword456");
                userService.update(foundUser);
                System.out.println("Utilisateur mis à jour : " + foundUser);
            }

            // Supprimer un utilisateur
            userService.deleteById(newUser.getId());
            System.out.println("Utilisateur supprimé avec ID : " + newUser.getId());

        } catch (SQLException e) {
            System.err.println("Erreur SQL : " + e.getMessage());
        }
    }

    // Méthode pour tester la connexion à la base de données
    private static void testConnection(PostgreSQLDataSourceImpl dataSource) {
        try (var connection = dataSource.getConnection()) {
            if (connection != null && !connection.isClosed()) {
                System.out.println("Connexion réussie à la base de données !");
            }
        } catch (SQLException e) {
            System.err.println("Échec de la connexion à la base de données : " + e.getMessage());
        }
    }
}
