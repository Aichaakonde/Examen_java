package com.example.entities;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Article {
    private Long id;
    private String nom;
    private double prix;
    private Long qteStock;
    private String etat;
    private static long compteurId = 1;

    public Article() {
        this.id = compteurId++;
    }

    public Article(String nom, double prix, Long qteStock, String etat) {
        this.id = compteurId++;
        this.nom = nom;
        this.prix = prix;
        this.qteStock = qteStock;
        this.etat = etat;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String toString() {
        return "Article{" +
            "id=" + id +
            ", nom='" + nom + '\'' +
            ", prix='" + prix + '\'' +
            ", qteStock='" + qteStock + '\'' +
            ", etat=" + etat +
            '}';
    }
}
