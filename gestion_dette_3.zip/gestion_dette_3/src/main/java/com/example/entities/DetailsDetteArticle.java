package com.example.entities;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class DetailsDetteArticle {
    private Long id;
    private Long quantite;
    private Article article;
    private Dette dette;
    private static long compteurId = 1;

    public DetailsDetteArticle() {
        this.id = compteurId++;
    }

    public DetailsDetteArticle(long quantite, Article article, Dette dette) {
        this.quantite = quantite;
        this.article = article;
        this.dette = dette;
    }

    @Override
    public String toString() {
        return "DetailsDetteArticle [id=" + id + ", quantite=" + quantite + ", prix=" + article.getPrix() * quantite + ", article=" + article.getNom() + ", dette=" + dette.getId() + "]";
    }
}
