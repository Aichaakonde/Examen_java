package com.example.entities;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Demande {
    private Long id;
    private LocalDate date;
    private double montantTotal;
    private static long compteurId = 1;
    private String statut; // en cours, annulée, acceptée
    private Client client;
    private List<DetailsDemande> detailsDemandes = new ArrayList<>();

    public Demande(LocalDate date, double montantTotal, String statut, Client client, List<DetailsDemande> detailsDemandes) {
        this.id = compteurId++;
        this.date = date;
        this.montantTotal = montantTotal;
        this.statut = statut;
        this.client = client;
        this.detailsDemandes = detailsDemandes;
    }

    @Override
    public String toString() {
        return "Demande [id=" + id + ", date=" + date + ", montantTotal=" + montantTotal + ", statut=" + statut + ", clientId=" + client.getId() + ", details=" + detailsDemandes.size() + "]";
    }
}
