package com.example.menus;

import java.sql.SQLException;

import com.example.entities.Client;
import com.example.entities.Dette;
import com.example.services.IArticleService;
import com.example.services.IDetteService;
import com.example.views.DetailsDetteArticleView;
import com.example.views.DetteView;
import com.example.views.PaiementDetteArticleView;

public abstract class DetteMenuClient {
    private DetteMenuClient(){};

    public static void commencer(IDetteService detteService, IArticleService articleService, Client client)  throws SQLException {


        //Menu Dette pour le client
        int choix;
        do {
            choix = DetteView.menuDettesClient();
            switch (choix) {
                case 1:
                   DetteView.lister(detteService.findByClient(client));
                    break;
                case 2:
                   DetteView.lister(detteService.findByClientAndStatut(client,"Soldée"));
                    break;
                case 3:
                    DetteView.lister(detteService.findByClientAndStatut(client,"Non Soldée"));
                    break;
                case 4:
                    Dette detteTrouve= DetteView.rechercherDetteParId(detteService.selectAll());
                    if (detteTrouve != null) {
                       int choixSousMenu = DetteView.menuDettesDetails();
                        do {  
                            switch (choixSousMenu) {
                                case 1:
                                    DetailsDetteArticleView.lister(detteTrouve.getDetailsDetteArticles());
                                    break;

                                case 2:
                                    PaiementDetteArticleView.lister(detteTrouve.getPaiements());
                                    break;
                                case 0:
                                    System.out.println("Quitter");
                                    break;
                                default:
                                    System.out.println("Choix  invalide.");
                                    break;
                            }
                        } while (choixSousMenu != 0);

                    } else {
                         System.out.println("Il n'y a pas de dette associée à cet ID.");
                        }
                        break;
                    case 0:
                    System.out.println("Quitter");
                    return;
                default:
                    System.out.println("Faites votre choix");
            }
        } while (choix!=0);
    }
    
}
