package com.example.menus;

import java.sql.SQLException;

import com.example.entities.Article;
import com.example.services.IArticleService;
import com.example.views.ArticleView;

public abstract class ArticleMenu {

    private ArticleMenu(){}

    public static void commencer(IArticleService articleService) throws SQLException{
        //Menu Article lance charge

        
        int choix;
        do {
            choix =ArticleView.menu();
            switch (choix) {
                case 1 :
                    Article article = ArticleView.create();
                    articleService.add(article);
                    break;
                case 2 :
                    ArticleView.lister(articleService.selectAll());
                    break;
                case 3:
                    break;
                case 4 :
                    String libelle = ArticleView.saisieLibelle();
                    Article articleTrouve = articleService.findByLibelle(libelle);
                    if (articleTrouve != null) {
                        System.out.println(articleTrouve);   
                    }else {
                        System.out.println("Il n'y a pas d'article associé à ce libelle");
                    }
                    break;
                case 0 :
                    System.out.println("Quitter"); 
                default :
                    System.out.println("Choix Invalide");    
                }
            
        } while (choix != 0);

        
    }
    
}
