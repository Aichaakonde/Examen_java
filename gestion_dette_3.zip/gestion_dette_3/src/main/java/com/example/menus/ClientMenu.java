package com.example.menus;

import java.sql.SQLException;
import java.util.Scanner;

import com.example.core.config.Config;
import com.example.entities.Client;
import com.example.entities.User;
import com.example.services.IClientService;
import com.example.services.IUserService;
import com.example.views.ClientView;
import com.example.views.UserView;

public class ClientMenu {
    private static Scanner scanner = new Scanner(System.in);
    
    private static final IUserService userService = Config.getUserService();

    private ClientMenu(){};


    public static void commencer(IClientService clientService)  throws SQLException{
        
        //Menu Client
        int choix;
        do {
            choix = ClientView.menu();
            switch (choix) {
                case 1:
                    Client client = ClientView.create();

                    System.out.println("Voulez-vous associer un compte utilisateur à ce client?");
                    String response = scanner.nextLine();

                    if (response.equalsIgnoreCase("oui")) {
                        User user = UserView.create();
                        user.setRole("Client");
                        client =  userService.associerUser(client, user);
                    }

                    clientService.add(client);

                    break;
                case 2:
                    ClientView.lister(clientService.selectAll());
                    break;
                case 3:
                    String telephone = ClientView.saisieTelephone();
                    Client clientTrouve = clientService.selectByTelephone(telephone);
                    if (clientTrouve!= null) {
                        System.out.println(clientTrouve);
                    } else {
                        System.out.println("Il n'y a pas de client associé à ce telephone");
                    }
                    break;
                case 0 :
                    System.out.println("Quitter"); 
                default :
                    System.out.println("Choix Invalide");    
                }
            
        } while (choix != 0);
    }
}
