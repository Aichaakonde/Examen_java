package com.example.menus;

import com.example.core.config.Config;
import com.example.entities.Admin;
import com.example.services.*;
import com.example.views.AdminView;
import java.sql.SQLException;

public abstract class AdminMenu {
    private static final IClientService clientService =  Config.getClientService();
    private static final IArticleService articleService = Config.getArticleService();
    private static final IUserService userService = Config.getUserService();
    private static final IDemandeService demandeService = Config.getDemandeService();
    private static final IDetteService detteService = Config.getDetteService();

    private AdminMenu() {}

    public static void commencer(IAdminService adminservice) throws SQLException {
        Admin admin = LoginMenu.afficherMenuConnexion(adminservice) ;

        // Menu Admin
        if (admin != null) {
            int choix;
            do {
                choix = AdminView.menu();
                switch (choix) {
                    case 1:
                        ClientMenu.commencer(clientService);
                        break;
                    case 2:
                        ArticleMenu.commencer(articleService);
                        break;
                    case 3:
                        DemandeMenu.commencer(demandeService);
                        break;
                    case 4:
                        DetteMenu.commencer(detteService);
                        break;
                    case 5:
                        UserMenu.commencer(userService);
                        break;
                    case 0:
                        System.out.println("Quitter");
                        break;
                    default:
                        System.out.println("Choix invalide");
                }
            } while (choix != 0);
        } else {
            System.out.println("Identifiants invalides!");
        }
    }
}
