package com.example.core.factory;

public interface RepositoryFactory {
    <T> T getInstance(Class<T> repositoryClass);
}