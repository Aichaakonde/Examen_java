package com.example.menus;

import java.sql.SQLException;

import com.example.services.IUserService;
import com.example.views.AdminView;
import com.example.views.BoutiquierView;
import com.example.views.ClientView;
import com.example.views.UserView;

public abstract class UserMenu {
    private UserMenu(){};

    public static void commencer(IUserService userService) throws SQLException{
        //Menu User 
        int choix;
        do {
            choix = UserView.menu();
            switch (choix) {
                case 1:
                    AdminView.menu();
                    break;
                case 2:
                    ClientView.menu();
                    break;
                case 3:
                    BoutiquierView.menu();
                    break;
                case 0 :
                    System.out.println("Quitter"); 
                default :
                    System.out.println("Choix Invalide"); 
            }
        } while (choix!=0);
        
    }
    
}
