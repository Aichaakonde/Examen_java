package com.example.menus;

import java.sql.SQLException;

import com.example.services.IDemandeService;
import com.example.views.DemandeView;

public abstract class DemandeMenu {

    private DemandeMenu(){};

    public static void commencer(IDemandeService demandeService)  throws SQLException{
        //Menu demande
        int choix;
        do {
            choix = DemandeView.menu();
            switch (choix) {
                case 1:
                try {
                    DemandeView.lister(demandeService.selectAll()) ;
                } catch (Exception e) {
                    // TODO: handle exception
                }
                    break;
                case 2:
                    DemandeView.lister(demandeService.findByEtat("En cours"));
                    break;
                case 3:
                   DemandeView.lister(demandeService.findByEtat("Rejetée"));
                    break;
                case 4:
                    DemandeView.lister(demandeService.findByEtat("Acceptée"));
                    break;
                case 5:

                    break;
                case 0:
                
                    // Quitter
                    System.out.println("Quitter");
                    return;
                default:
                    System.out.println("Faites votre choix");
            }
        } while (true);
    }

    
}
