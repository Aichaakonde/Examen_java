package com.example.menus;


import java.sql.SQLException;

import com.example.core.config.Config;
import com.example.services.IAdminService;
import com.example.services.IBoutiquierService;
import com.example.services.IClientService;
import com.example.views.LoginView;





public class MainMenu {
    private static final IAdminService adminService = Config.getAdminService();
    private static final IBoutiquierService boutiquierService = Config.getBoutiquierService();
    private static final IClientService clientService = Config.getClientService();

    private MainMenu(){};

    public static void commencer() throws SQLException{
        int choix;
        do {
            choix = LoginView.menuConnexion();
            switch (choix) {
                case 1 -> AdminMenu.commencer(adminService);
                case 2 -> BoutiquierMenu.commencer(boutiquierService);
                case 3 -> MenuClient.commencer(clientService);
                case 0 -> System.out.println("Au revoir !");
                default -> System.out.println("Choix invalide !");
            } 
        }while (choix != 0);
    }
}


    
    










// public MainMenu(IAdminService adminService,IBoutiquierService boutiquierService, IClientService clientService, IArticleService articleService,IUserService userService, IDetteService detteService, IDemandeService demandeService, Client client) {
//     this.adminService = adminService;
//     this.boutiquierService = boutiquierService;
//     this.clientService = clientService;
//     this.articleService = articleService;
//     this.userService = userService;
//     this.detteService = detteService;   
//     this.demandeService = demandeService;

    


// public void afficherMenuPrincipal() {
//     Scanner scanner = new Scanner(System.in);
//     int choix;

//     do {

//         choix = scanner.nextInt();
//         scanner.nextLine(); 

//         switch (choix) {
//             case 1:
//                 afficherMenuAdmin();
//                 break;
//             case 2:
//                 afficherMenuBoutiquier();
//                 break;
//             case 3:
//                 afficherMenuClient();
//                     break;
//                 case 0:
//                     System.out.println("Au revoir !");
//                     break;
//                 default:
//                     System.out.println("Choix invalide. Veuillez réessayer.");
//             }
//         } while (choix != 0);
//     }

    // private void afficherMenuAdmin() {
    //     System.out.println("===== MENU ADMIN =====");
    //     AdminMenu adminMenu = new AdminMenu();
    //     Client client = choisirClient();
    //     AdminMenu.commencer(adminService, clientService, articleService, userService, detteService, demandeService, client);
    // }


    // private void afficherMenuBoutiquier() {
    //     System.out.println("===== MENU BOUTIQUIER =====");
    //     BoutiquierMenu boutiquierMenu = new BoutiquierMenu();
    //     boutiquierMenu.commencer(boutiquierService);
    // }

    // private void afficherMenuClient() {
    //     System.out.println("===== MENU CLIENT =====");
    //     ClientMenu clientMenu = new ClientMenu();
    //     clientMenu.commencer(clientService);
    // }

    // private Client choisirClient() {
    //     System.out.println("Saisissez le nom du client : ");
    //     Scanner scanner = new Scanner(System.in);
    //     String nomClient = scanner.nextLine();
    //     return clientService.selectByLogin(nomClient);
    // }

    //  public static void main(String[] args) {
    //     IAdminService adminService = new AdminServiceImpl(null);
    //     IBoutiquierService boutiquierService = new BoutiquierServiceImpl(null);
    //     IClientService clientService = new ClientServiceImpl(null);

    //     MainMenu mainMenu = new MainMenu(adminService, boutiquierService, clientService, articleService,userService,detteService,demandeService, client);
    //     mainMenu.afficherMenuPrincipal();
    // }




