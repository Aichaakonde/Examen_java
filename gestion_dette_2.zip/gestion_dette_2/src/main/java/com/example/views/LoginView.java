package com.example.views;

import java.util.Scanner;

public class LoginView {

    private static final Scanner scanner = new Scanner(System.in);

    private LoginView(){};

    public static int menuConnexion(){
        System.out.println("Menu Connexion");
        System.out.println("1. Connexion Admin");
        System.out.println("2. Connexion Boutiquier");
        System.out.println("3. Connexion Client");
        System.out.println("0. Quitter");
        System.out.print("Faites votre choix: ");

        return Integer.parseInt(scanner.nextLine());
    }
    
}
