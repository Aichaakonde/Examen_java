package com.example.views;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.example.entities.Client;

public abstract class ClientView {
    private static final Scanner scanner = new Scanner(System.in);

    public static int menu(){
        System.out.println("Menu Client");
        System.out.println("1. Créer un client");
        System.out.println("2. Lister les clients");
        System.out.println("3. Rechercher un client par telephone");
        System.out.println("0. Quitter");
        System.out.println("Faites votre choix:");

        return Integer.parseInt(scanner.nextLine());
    }

    public static int menuClient(){
        System.out.println("Menu Client");
        System.out.println("1. Demandes");
        System.out.println("2. Dettes");
        System.out.println("0. Quitter");
        System.out.println("Faites votre choix:");

        return Integer.parseInt(scanner.nextLine());
    }



    public static Client create(){
        String surname,adresse,telephone;

        System.out.println("Veuillez donner le surname");
        surname=scanner.nextLine();
        // System.out.println("Veuillez donner l'id");
        // int id = Integer.parseInt(scanner.nextLine());
        System.out.println("Veuillez donner l'adresse");
        adresse=scanner.nextLine();
        System.out.println("Veuillez donner le telephone");
        telephone=scanner.nextLine();
        
        return new Client( surname, telephone, adresse, null, new ArrayList<>(), new ArrayList<>());
    }

    public static void lister(List<Client> clients){
        if (clients.isEmpty()) {
            System.out.println("Il n'y a pas de client disponible");
        }else{
            for(Client client : clients){
                System.out.println(client);
            }
        }
    }
    public static Client rechercherClientParId(List<Client> clients){
        int id = saisieIdentifiant();

        for(Client client : clients){
            if (client.getId() == id ) {
                return client;
            }  
        }
        return null;

    }

    public static Client rechercheClientParTelephone(List<Client> clients){
        System.out.println("Entrer le telephone du client");
        String telephone = scanner.nextLine();

        for(Client client : clients){
            if (client.getTelephone().equals(telephone)) { 
                return client;
            }
                      
        }
        return null;
    }


    public static int saisieIdentifiant(){
        System.out.println("Entrer l'identifiant du client");
        return Integer.parseInt(scanner.nextLine());
    }

    public static String saisieTelephone(){
        System.out.println("Entrer le telephone du client");
        return scanner.nextLine();
    }
   
}    

