package com.example.views;

import java.util.List;

import com.example.entities.DetailsDetteArticle;

public abstract class DetailsDetteView {

    public static void lister(List<DetailsDetteArticle> detailsDetteArticles){
       
         for(DetailsDetteArticle detailsDetteArticle : detailsDetteArticles){
                System.out.println(detailsDetteArticle);
        }

    }
    
}
