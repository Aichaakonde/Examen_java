package com.example.views;

import java.util.Scanner;
import java.util.List;

import com.example.core.factory.Factory;
import com.example.entities.Article;

public abstract class ArticleView {
    private static final Scanner scanner = new Scanner(System.in);
    public static Article create() {
        Article article = Factory.getInstance().getInstance(Article.class);

        System.out.println("Veuillez entrer le nom de l'article");
        String noms = scanner.nextLine();
        
        System.out.println("Veuillez entrer le prix unitaire de l'article");
        double prixUnitaire = scanner.nextDouble();
        
        System.out.println("Veuillez entrer la quantité en stock de l'article");
        Long qteStock = scanner.nextLong();
        scanner.nextLine();
        
        article.setNom(noms);
        article.setPrix(prixUnitaire);
        article.setQteStock(qteStock);
        article.setEtat((qteStock > 0) ? "Disponible" : "Rupture");

        return article;
    }

    public static int menu(){
        System.out.println("Menu Article");
        System.out.println("1. Ajouter un article");
        System.out.println("2. Lister les articles");
        System.out.println("3. Approvisionnement d'articles");
        System.out.println("4. Rechercher un article par libelle");
        System.out.println("0. Quitter");
        System.out.println("Faites votre choix");

        return Integer.parseInt(scanner.nextLine());
       
    }

    public static void lister(List<Article> articles) {
        if (articles.isEmpty()) {
            System.out.println("Il n y a pas d article disponible");
        }
        else {
            for(Article article : articles) {
                 System.out.println(article);

             } 
        }   
    }

    public static Article rechercherArticleParId(List<Article> articles) {
        int id = saisieIdentifiant();

        for(Article article : articles) {
            if(article.getId() == id) {
                return article;
            }
        }
        return null;
    }

    public static Article rechercherArticleParLibelle(List<Article> articles) {
        String libelle = saisieLibelle();

        for(Article article : articles) {
            if (article.getNom().equals(libelle)) {
                return article;
                
            }
        }
        return null;
    }

    public static int saisieIdentifiant(){
        System.out.println("Entrer l'identifiant de l'article");
        return Integer.parseInt(scanner.nextLine());
    }

    public static String saisieLibelle(){
        System.out.println("Entrer le libelle de l'article");
        return scanner.nextLine();
    }
   
}

