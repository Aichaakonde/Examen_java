package com.example.views;

import java.util.List;
import java.util.Scanner;

import com.example.entities.Boutiquier;

public  abstract class BoutiquierView {
    private static final Scanner scanner = new Scanner(System.in);

    public static int menu(){
        System.out.println("Menu Boutiquier");
        System.out.println("1. Client");
        System.out.println("2. Article");
        System.out.println("3. Demande");
        System.out.println("4. Dette");
        System.out.println("0. Quitter");
        System.out.println("Faites votre choix");

        return Integer.parseInt(scanner.nextLine());

    }
    
    public static Boutiquier create(){
        String noms, prenoms, telephone;
        System.out.println("Entrer le nom du Boutiquier");
        noms = scanner.nextLine();
        System.out.println("Entrer le prenom du Boutiquier");
        prenoms = scanner.nextLine();
        System.out.println("Entrer le telephone du Boutiquier");
        telephone = scanner.nextLine();

        return new Boutiquier(noms, prenoms, telephone,null);
    }


    public static void lister(List<Boutiquier> boutiquiers) {
        if (boutiquiers.isEmpty()) {
            System.out.println("Il n y a pas d'Admin disponible");
        }
        else {
            for(Boutiquier boutiquier : boutiquiers) {
                 System.out.println(boutiquier);

            }
        }
    }  
    
    



    
}

    
