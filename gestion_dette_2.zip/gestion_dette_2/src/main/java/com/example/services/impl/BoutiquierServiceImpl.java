package com.example.services.impl;

import com.example.entities.Boutiquier;
import com.example.repositories.IBoutiquierRepository;
import com.example.services.IBoutiquierService;

import java.sql.SQLException;
import java.util.List;

public class BoutiquierServiceImpl implements IBoutiquierService {
    private final IBoutiquierRepository boutiquierRepository;

    public BoutiquierServiceImpl(IBoutiquierRepository boutiquierRepository) {
        this.boutiquierRepository = boutiquierRepository;
    }

    @Override
    public Boutiquier selectByLogin(String login) throws SQLException {
        return boutiquierRepository.selectByLogin(login);
    }

    @Override
    public Boutiquier add(Boutiquier entity) throws SQLException {
        return boutiquierRepository.add(entity);
    }

    @Override
    public List<Boutiquier> selectAll() throws SQLException {
        return boutiquierRepository.selectAll();
    }

    @Override
    public Boutiquier findById(Long id) throws SQLException {
        return boutiquierRepository.findById(id);
    }

    @Override
    public void update(Boutiquier entity) throws SQLException {
        boutiquierRepository.update(entity);
    }

    @Override
    public void delete(Boutiquier entity) throws SQLException {
        boutiquierRepository.delete(entity);
    }

    @Override
    public void deleteById(Long id) throws SQLException {
        boutiquierRepository.deleteById(id);
    }

    // Utiliser getNoms() pour obtenir le nom du Boutiquier
    public String getBoutiquierName(Boutiquier boutiquier) {
        return boutiquier.getNoms();
    }
}
