package com.example.services.impl;

import java.sql.SQLException;
import java.util.List;

import com.example.entities.Client;
import com.example.entities.Dette;
import com.example.repositories.IDetteRepository;
import com.example.services.IDetteService;

public class DetteServiceImpl implements IDetteService {

    private final IDetteRepository detteRepository;

    public DetteServiceImpl(IDetteRepository detteRepository) {
        this.detteRepository = detteRepository;
    }

    @Override
    public Dette add(Dette dette) throws SQLException {
        return detteRepository.add(dette);
    }

    @Override
    public List<Dette> selectAll() throws SQLException {
        return detteRepository.selectAll();
    }

    @Override
    public Dette findById(Long id) throws SQLException {
        return detteRepository.findById(id);
    }

    @Override
    public void update(Dette dette) throws SQLException {
        detteRepository.update(dette);
    }

    @Override
    public void delete(Dette dette) throws SQLException {
        detteRepository.delete(dette);
    }

    @Override
    public void deleteById(Long id) throws SQLException {
        detteRepository.deleteById(id);
    }

    @Override
    public List<Dette> findByStatut(String statut) throws SQLException {
        return detteRepository.findByStatut(statut);
    }

    @Override
    public List<Dette> findByClient(Client client) throws SQLException {
        return detteRepository.findByClient(client);
    }

    // @Override
    // public void enregistrerPaiement(Dette dette, double montant) throws SQLException {
    //     double montantRestant = dette.getMontant() - montant;
    //     dette.setMontant(montantRestant);

    //     // Logique pour enregistrer le paiement - la création du paiement dans la base de données est à implémenter
    //     // Paiement paiement = new Paiement(dette.getPaiements().size() + 1, montant);
    //     // dette.getPaiements().add(paiement);
    // }

    @Override
    public List<Dette> findByClientAndStatut(Client client, String statut) throws SQLException {
        return detteRepository.findByClientAndStatut(client, statut);
    }

   
}
