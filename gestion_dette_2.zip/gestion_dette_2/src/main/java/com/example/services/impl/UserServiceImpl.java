package com.example.services.impl;

import java.sql.SQLException;
import java.util.List;

import com.example.core.IHasUser;
import com.example.entities.Client;
import com.example.entities.User;
import com.example.repositories.IUserRepository;
import com.example.services.IUserService;

public class UserServiceImpl implements IUserService {
    private final IUserRepository userRepository;

    public UserServiceImpl(IUserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public User add(User user) throws SQLException{
        return userRepository.add(user);
    }

    @Override
    public List<User> selectAll() throws SQLException{
        return userRepository.selectAll(); 
    }

    @Override
    public User findById(Long id) throws SQLException{
        return userRepository.findById(id); 
    }

    @Override
    public void update(User user)throws SQLException {
        userRepository.update(user); 
    }

    @Override
    public void delete(User user) throws SQLException{
        userRepository.delete(user); 
    }

    @Override
    public void deleteById(Long id)throws SQLException {
        userRepository.deleteById(id); 
    }

     @Override
    public <T extends IHasUser> T associerUser(Client client, User user) throws SQLException{
        if (client != null) {
            client.setUser(user);
            user.setActive(true);
            userRepository.update(user);
            return (T) client;
        } else {
            System.out.println("Entité ou utilisateur introuvable.");
            return null;
        }
    }

   

   

   
}
