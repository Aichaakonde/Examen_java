package com.example.services.impl;

import com.example.entities.DetailsDemande;
import com.example.repositories.IDetailsDemandeRepository;
import com.example.services.IDetailsDemandeService;

import java.sql.SQLException;
import java.util.List;

public class DetailsDemandeServiceImpl implements IDetailsDemandeService {
    private final IDetailsDemandeRepository detailsDemandeRepository;

    public DetailsDemandeServiceImpl(IDetailsDemandeRepository detailsDemandeRepository) {
        this.detailsDemandeRepository = detailsDemandeRepository;
    }

    @Override
    public DetailsDemande add(DetailsDemande detailsDemande) throws SQLException {
        return detailsDemandeRepository.add(detailsDemande);
    }

    @Override
    public List<DetailsDemande> selectAll() throws SQLException {
        return detailsDemandeRepository.selectAll();
    }

    @Override
    public DetailsDemande findById(Long id) throws SQLException {
        return detailsDemandeRepository.findById(id);
    }

    @Override
    public void update(DetailsDemande detailsDemande) throws SQLException {
        detailsDemandeRepository.update(detailsDemande);
    }

    @Override
    public void delete(DetailsDemande detailsDemande) throws SQLException {
        detailsDemandeRepository.delete(detailsDemande);
    }

    @Override
    public void deleteById(Long id) throws SQLException {
        detailsDemandeRepository.deleteById(id);
    }

   
}
 