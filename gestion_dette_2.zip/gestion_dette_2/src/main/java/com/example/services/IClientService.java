package com.example.services;

import com.example.core.IAccount;
import com.example.core.IService;

import java.sql.SQLException;

import com.example.entities.Client;

public interface IClientService extends IService<Client>,IAccount<Client>{


    Client selectByTelephone(String telephone) throws SQLException;

    Client selectByLogin(String login) throws SQLException;

   
}
