package com.example.services;


import java.sql.SQLException;

import com.example.core.IHasUser;
import com.example.core.IService;
import com.example.entities.Client;
import com.example.entities.User;

public interface IUserService extends IService <User>{
    <T extends IHasUser> T associerUser(Client client, User user) throws SQLException;
    
}
