package com.example.services;

import java.sql.SQLException;

import com.example.core.IAccount;
import com.example.core.IService;
import com.example.entities.Boutiquier;

public interface IBoutiquierService extends IService <Boutiquier> , IAccount<Boutiquier>{
        Boutiquier selectByLogin(String login) throws SQLException;

    
}
