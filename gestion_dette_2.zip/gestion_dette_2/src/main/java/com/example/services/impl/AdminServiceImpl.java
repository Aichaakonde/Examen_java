package com.example.services.impl;

import com.example.entities.Admin;
import com.example.repositories.IAdminRepository;
import com.example.services.IAdminService;

import java.sql.SQLException;
import java.util.List;

public class AdminServiceImpl implements IAdminService {
    private final IAdminRepository adminRepository;

    public AdminServiceImpl(IAdminRepository adminRepository) {
        this.adminRepository = adminRepository;
    }

    @Override
    public Admin selectByLogin(String login) throws SQLException {
        return adminRepository.selectByLogin(login);
    }

    @Override
    public Admin add(Admin entity) throws SQLException {
        return adminRepository.add(entity);
    }

    @Override
    public List<Admin> selectAll() throws SQLException {
        return adminRepository.selectAll();
    }

    @Override
    public Admin findById(Long id) throws SQLException {
        return adminRepository.findById(id);
    }

    @Override
    public void update(Admin entity) throws SQLException {
        adminRepository.update(entity);
    }

    @Override
    public void delete(Admin entity) throws SQLException {
        adminRepository.delete(entity);
    }

    @Override
    public void deleteById(Long id) throws SQLException {
        adminRepository.deleteById(id);
    }

    // Use getNoms() instead of getSurname()
    public String getAdminName(Admin admin) {
        return admin.getNoms(); 
    }
}
