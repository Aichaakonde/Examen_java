package com.example.services.impl;

import com.example.entities.Client;
import com.example.entities.Demande;
import com.example.repositories.IDemandeRepository;
import com.example.services.IDemandeService;

import java.sql.SQLException;
import java.util.List;

public class DemandeServiceImpl implements IDemandeService {
    private final IDemandeRepository demandeRepository;

    public DemandeServiceImpl(IDemandeRepository demandeRepository) {
        this.demandeRepository = demandeRepository;
    }

    @Override
    public Demande add(Demande demande) throws SQLException {
        return demandeRepository.add(demande);
    }

    @Override
    public List<Demande> selectAll() throws SQLException {
        return demandeRepository.selectAll();
    }

    @Override
    public Demande findById(Long id) throws SQLException {
        return demandeRepository.findById(id);
    }

    @Override
    public void update(Demande demande) throws SQLException {
        demandeRepository.update(demande);
    }

    @Override
    public void delete(Demande demande) throws SQLException {
        demandeRepository.delete(demande);
    }

    @Override
    public void deleteById(Long id) throws SQLException {
        demandeRepository.deleteById(id);
    }

    @Override
    public List<Demande> findByEtat(String etat) throws SQLException {
        return demandeRepository.findByEtat(etat);
    }

    @Override
    public List<Demande> findByClient(Client client) throws SQLException {
        return demandeRepository.findByClient(client);
    }

    @Override
    public List<Demande> findByClientandEtat(Client client, String etat) throws SQLException {
        return demandeRepository.findByClientandEtat(client, etat);
    }

    @Override
    public void addDetail(Long id, Long id2, long quantite) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'addDetail'");
    }

  
}
