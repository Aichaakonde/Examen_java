package com.example.services.impl;

import com.example.entities.Article;
import com.example.repositories.IArticleRepository;
import com.example.services.IArticleService;

import java.sql.SQLException;
import java.util.List;

public class ArticleServiceImpl implements IArticleService {
    private final IArticleRepository articleRepository;

    public ArticleServiceImpl(IArticleRepository articleRepository) {
        this.articleRepository = articleRepository;
    }

    @Override
    public Article add(Article article) throws SQLException {
        return articleRepository.add(article);
    }

    @Override
    public List<Article> selectAll() throws SQLException {
        return articleRepository.selectAll();
    }

    @Override
    public Article findById(Long id) throws SQLException {
        return articleRepository.findById(id);
    }

    @Override
    public void update(Article article) throws SQLException {
        articleRepository.update(article);
    }

    @Override
    public void delete(Article article) throws SQLException {
        articleRepository.delete(article);
    }

    @Override
    public void deleteById(Long id) throws SQLException {
        articleRepository.deleteById(id);
    }

    @Override
    public Article findByLibelle(String libelle) throws SQLException {
        return articleRepository.findByLibelle(libelle);
    }

   

   
}
