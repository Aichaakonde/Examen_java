package com.example.services;

import com.example.core.IService;
import com.example.entities.DetailsDemande;

public interface IDetailsDemandeService  extends IService <DetailsDemande>{
    
}
