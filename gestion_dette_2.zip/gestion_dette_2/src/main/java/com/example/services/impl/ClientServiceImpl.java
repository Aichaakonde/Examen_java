package com.example.services.impl;

import com.example.entities.Client;
import com.example.repositories.IClientRepository;
import com.example.services.IClientService;

import java.sql.SQLException;
import java.util.List;

public class ClientServiceImpl implements IClientService {
    private final IClientRepository clientRepository;

    public ClientServiceImpl(IClientRepository clientRepository) {
        this.clientRepository = clientRepository;
    }

    @Override
    public Client add(Client client) throws SQLException {
        return clientRepository.add(client);
    }

    @Override
    public List<Client> selectAll() throws SQLException {
        return clientRepository.selectAll();
    }

    @Override
    public Client findById(Long id) throws SQLException {
        return clientRepository.findById(id);
    }

    @Override
    public void update(Client client) throws SQLException {
        clientRepository.update(client);
    }

    @Override
    public void delete(Client client) throws SQLException {
        clientRepository.delete(client);
    }

    @Override
    public void deleteById(Long id) throws SQLException {
        clientRepository.deleteById(id);
    }

    @Override
    public Client selectByLogin(String email) throws SQLException {
        return clientRepository.selectByLogin(email);
    }

    @Override
    public Client selectByTelephone(String telephone) throws SQLException {
        return clientRepository.selectByTelephone(telephone);
    }
}
