package com.example.services.impl;

import java.sql.SQLException;
import java.util.List;

import com.example.entities.DetailsDetteArticle;
import com.example.repositories.IDetailsDetteArticleRepository;
import com.example.services.IDetailsDetteArticleService;

public class DetailsDetteArticleServiceImpl implements IDetailsDetteArticleService {

    private final IDetailsDetteArticleRepository detailsDetteArticleRepository;

    public DetailsDetteArticleServiceImpl(IDetailsDetteArticleRepository detailsDetteArticleRepository) {
        this.detailsDetteArticleRepository = detailsDetteArticleRepository;
    }

    @Override
    public DetailsDetteArticle add(DetailsDetteArticle detailsDetteArticle) throws SQLException {
        return detailsDetteArticleRepository.add(detailsDetteArticle);
    }

    @Override
    public List<DetailsDetteArticle> selectAll() throws SQLException {
        return detailsDetteArticleRepository.selectAll();
    }

    @Override
    public DetailsDetteArticle findById(Long id) throws SQLException {
        return detailsDetteArticleRepository.findById(id);
    }

    @Override
    public void update(DetailsDetteArticle detailsDetteArticle) throws SQLException {
        detailsDetteArticleRepository.update(detailsDetteArticle);
    }

    @Override
    public void delete(DetailsDetteArticle detailsDetteArticle) throws SQLException {
        detailsDetteArticleRepository.delete(detailsDetteArticle);
    }

    @Override
    public void deleteById(Long id) throws SQLException {
        detailsDetteArticleRepository.deleteById(id);
    }

}
