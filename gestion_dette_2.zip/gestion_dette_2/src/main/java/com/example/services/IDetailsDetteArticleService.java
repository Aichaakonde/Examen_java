package com.example.services;

import com.example.core.IService;
import com.example.entities.DetailsDetteArticle;

public interface IDetailsDetteArticleService extends IService <DetailsDetteArticle>{
    
}
