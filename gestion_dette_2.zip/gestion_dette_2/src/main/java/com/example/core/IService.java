package com.example.core;

import java.sql.SQLException;
import java.util.List;

public interface IService<T> {  

    T add(T entity) throws SQLException;

    List<T> selectAll() throws SQLException;

    T findById(Long id) throws SQLException;

    void update(T entity) throws SQLException;

    void delete(T entity) throws SQLException;

    void deleteById(Long id) throws SQLException;
}
