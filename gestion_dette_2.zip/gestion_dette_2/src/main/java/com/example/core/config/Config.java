package com.example.core.config;

import com.example.repositories.impl.*;
import com.example.services.*;
import com.example.services.impl.*;

import lombok.Getter;

public class Config {

    // Initialisation des repositories JDBC
    private static final ClientRepositoryImpl clientRepository = new ClientRepositoryImpl(null);
    private static final ArticleRepositoryImpl articleRepository = new ArticleRepositoryImpl(null);
    private static final BoutiquierRepositoryImpl boutiquierRepository = new BoutiquierRepositoryImpl(null);
    private static final DetteRepositoryImpl detteRepository = new DetteRepositoryImpl(null);
    private static final DemandeRepositoryImpl demandeRepository = new DemandeRepositoryImpl(null);
    private static final AdminRepositoryImpl adminRepository = new AdminRepositoryImpl(null);
    private static final PaiementRepositoryImpl paiementRepository = new PaiementRepositoryImpl(null);
    private static final UserRepositoryImpl userRepository = new UserRepositoryImpl(null);
    private static final DetailsDemandeRepositoryImpl detailsDemandeRepository = new DetailsDemandeRepositoryImpl(null);
    private static final DetailsDetteArticleRepositoryImpl detailsDetteArticleRepository = new DetailsDetteArticleRepositoryImpl(null);

    // Initialisation des services basés sur les repositories ImplDetteRepositoryImpl
    @Getter
    private static final IClientService clientService = new ClientServiceImpl(clientRepository);
    @Getter
    private static final IArticleService articleService = new ArticleServiceImpl(articleRepository);
    @Getter
    private static final IBoutiquierService boutiquierService = new BoutiquierServiceImpl(boutiquierRepository);
    @Getter
    private static final IDetteService detteService = new DetteServiceImpl(detteRepository);
    @Getter
    private static final IDemandeService demandeService = new DemandeServiceImpl(demandeRepository);
    @Getter
    private static final IAdminService adminService = new AdminServiceImpl(adminRepository);
    @Getter
    private static final IPaiementService paiementService = new PaiementServiceImpl(paiementRepository);
    @Getter
    private static final IUserService userService = new UserServiceImpl(userRepository);
    @Getter
    private static final IDetailsDemandeService detailsDemandeService = new DetailsDemandeServiceImpl(detailsDemandeRepository);
    @Getter
    private static final IDetailsDetteArticleService detailsDetteArticleService = new DetailsDetteArticleServiceImpl(detailsDetteArticleRepository);

    // Constructeur privé pour empêcher l'instanciation
    private Config() {}
}
