package com.example.core;

import java.sql.SQLException;

import com.example.entities.User;

public interface IHasUser {
    void setUser(User user) throws SQLException;
    User getUser()throws SQLException;
}
