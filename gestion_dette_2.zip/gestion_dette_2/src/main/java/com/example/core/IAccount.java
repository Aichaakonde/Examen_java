package com.example.core;

import java.sql.SQLException;

public interface IAccount <T> {
    T selectByLogin(String login) throws SQLException;
}
