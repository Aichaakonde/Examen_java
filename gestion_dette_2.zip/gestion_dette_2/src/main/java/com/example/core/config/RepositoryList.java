package com.example.core.config;

import java.util.ArrayList;
import java.util.List;


public class RepositoryList <T> implements Repository<T>{
    List<T> list=new ArrayList<>();

    @Override
    public void add(T objet){
        list.add(objet);
    }
    @Override
    public List<T> selectAll(){
        return this.list;
    }
}
