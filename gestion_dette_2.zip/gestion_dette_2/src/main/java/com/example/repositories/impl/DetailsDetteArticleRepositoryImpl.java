package com.example.repositories.impl;

import com.example.entities.DetailsDetteArticle;
import com.example.entities.Article;
import com.example.entities.Dette;
import com.example.repositories.IDetailsDetteArticleRepository;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DetailsDetteArticleRepositoryImpl implements IDetailsDetteArticleRepository {
    private final Connection connection;

    public DetailsDetteArticleRepositoryImpl(Connection connection) {
        this.connection = connection;
    }

    @Override
    public DetailsDetteArticle add(DetailsDetteArticle detailsDetteArticle) {
        String sql = "INSERT INTO details_dette_article (quantite, article_id, dette_id) VALUES (?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setLong(1, detailsDetteArticle.getQuantite());
            stmt.setLong(2, detailsDetteArticle.getArticle().getId());
            stmt.setLong(3, detailsDetteArticle.getDette().getId());

            stmt.executeUpdate();

            try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    detailsDetteArticle.setId(generatedKeys.getLong(1));
                }
            }

            return detailsDetteArticle;
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public List<DetailsDetteArticle> selectAll() {
        String sql = "SELECT * FROM details_dette_article";
        List<DetailsDetteArticle> detailsDetteArticles = new ArrayList<>();

        try (PreparedStatement stmt = connection.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                DetailsDetteArticle detailsDetteArticle = mapResultSetToDetailsDetteArticle(rs);
                detailsDetteArticles.add(detailsDetteArticle);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return detailsDetteArticles;
    }

    @Override
    public DetailsDetteArticle findById(Long id) {
        String sql = "SELECT * FROM details_dette_article WHERE id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setLong(1, id);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToDetailsDetteArticle(rs);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }

    @Override
    public void update(DetailsDetteArticle detailsDetteArticle) {
        String sql = "UPDATE details_dette_article SET quantite = ?, article_id = ?, dette_id = ? WHERE id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setLong(1, detailsDetteArticle.getQuantite());
            stmt.setLong(2, detailsDetteArticle.getArticle().getId());
            stmt.setLong(3, detailsDetteArticle.getDette().getId());
            stmt.setLong(4, detailsDetteArticle.getId());

            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void delete(DetailsDetteArticle detailsDetteArticle) {
        deleteById(detailsDetteArticle.getId());
    }

    @Override
    public void deleteById(Long id) {
        String sql = "DELETE FROM details_dette_article WHERE id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setLong(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private DetailsDetteArticle mapResultSetToDetailsDetteArticle(ResultSet rs) throws SQLException {
        DetailsDetteArticle detailsDetteArticle = new DetailsDetteArticle();
        detailsDetteArticle.setId(rs.getLong("id"));
        detailsDetteArticle.setQuantite(rs.getLong("quantite"));

        // Simuler la récupération des objets liés (Article et Dette).
        Article article = new Article();
        article.setId(rs.getInt("article_id"));
        detailsDetteArticle.setArticle(article);

        Dette dette = new Dette();
        dette.setId(rs.getLong("dette_id"));
        detailsDetteArticle.setDette(dette);

        return detailsDetteArticle;
    }
}
