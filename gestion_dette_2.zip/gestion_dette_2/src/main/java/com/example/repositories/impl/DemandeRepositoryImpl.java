package com.example.repositories.impl;

import com.example.entities.Article;
import com.example.entities.Client;
import com.example.entities.Demande;
import com.example.entities.DetailsDemande;
import com.example.repositories.IDemandeRepository;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DemandeRepositoryImpl implements IDemandeRepository {
    
    private Connection connection;

    public DemandeRepositoryImpl(Connection connection) {
        this.connection = connection;
    }

    @Override
    public Demande add(Demande demande) {
        String query = "INSERT INTO demandes (client_id, statut, montant_total, date) VALUES (?, ?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {
            statement.setLong(1, demande.getClient().getId());
            statement.setString(2, demande.getStatut());
            statement.setDouble(3, demande.getMontantTotal());
            statement.setDate(4, Date.valueOf(demande.getDate())); 
            statement.executeUpdate();

            // Obtenir l'ID généré pour la demande
            ResultSet generatedKeys = statement.getGeneratedKeys();
            if (generatedKeys.next()) {
                demande.setId(generatedKeys.getLong(1));
            }

            // Insérer les détails de la demande
            for (DetailsDemande details : demande.getDetailsDemandes()) {
                String detailsQuery = "INSERT INTO details_demandes (demande_id, description, montant) VALUES (?, ?, ?)";
                try (PreparedStatement detailsStatement = connection.prepareStatement(detailsQuery)) {
                    detailsStatement.setLong(1, demande.getId());
                    detailsStatement.setString(2, details.getArticle().getNom());  // Utiliser le nom de l'article à la place
                    detailsStatement.setDouble(3, details.getQuantite() * details.getArticle().getPrix());
                    detailsStatement.executeUpdate();
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return demande;
    }

    @Override
    public List<Demande> selectAll() {
        List<Demande> demandes = new ArrayList<>();
        String query = "SELECT * FROM demandes";
        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {

            while (resultSet.next()) {
                Demande demande = new Demande();
                demande.setId(resultSet.getLong("id"));
                // Récupérer le client associé
                Client client = getClientById(resultSet.getLong("client_id"));
                demande.setClient(client);
                demande.setStatut(resultSet.getString("statut"));
                demande.setMontantTotal(resultSet.getDouble("montant_total"));
                demande.setDate(resultSet.getDate("date").toLocalDate());  // Conversion de Date en LocalDate

                // Récupérer les détails de la demande
                List<DetailsDemande> detailsDemandes = getDetailsDemandesByDemandeId(demande.getId());
                demande.setDetailsDemandes(detailsDemandes);

                demandes.add(demande);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return demandes;
    }

    @Override
    public Demande findById(Long id) {
        Demande demande = null;
        String query = "SELECT * FROM demandes WHERE id = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setLong(1, id);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                demande = new Demande();
                demande.setId(resultSet.getLong("id"));
                Client client = getClientById(resultSet.getLong("client_id"));
                demande.setClient(client);
                demande.setStatut(resultSet.getString("statut"));
                demande.setMontantTotal(resultSet.getDouble("montant_total"));
                demande.setDate(resultSet.getDate("date").toLocalDate());

                // Récupérer les détails de la demande
                List<DetailsDemande> detailsDemandes = getDetailsDemandesByDemandeId(demande.getId());
                demande.setDetailsDemandes(detailsDemandes);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return demande;
    }

    @Override
    public void update(Demande demande) {
        String query = "UPDATE demandes SET statut = ?, montant_total = ?, date = ? WHERE id = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, demande.getStatut());
            statement.setDouble(2, demande.getMontantTotal());
            statement.setDate(3, Date.valueOf(demande.getDate()));  // Conversion LocalDate to Date
            statement.setLong(4, demande.getId());
            statement.executeUpdate();

            // Mettre à jour les détails de la demande
            for (DetailsDemande details : demande.getDetailsDemandes()) {
                String detailsQuery = "UPDATE details_demandes SET description = ?, montant = ? WHERE demande_id = ? AND id = ?";
                try (PreparedStatement detailsStatement = connection.prepareStatement(detailsQuery)) {
                    detailsStatement.setString(1, details.getArticle().getNom());  // Utiliser le nom de l'article à la place
                detailsStatement.setDouble(2, details.getQuantite() * details.getArticle().getPrix());
                detailsStatement.setLong(3, demande.getId());
                detailsStatement.setLong(4, details.getId());  // L'ID du détail
                detailsStatement.executeUpdate();
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void delete(Demande demande) {
        String query = "DELETE FROM demandes WHERE id = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setLong(1, demande.getId());
            statement.executeUpdate();

            // Supprimer les détails de la demande
            deleteDetailsByDemandeId(demande.getId());

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void deleteById(Long id) {
        String query = "DELETE FROM demandes WHERE id = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setLong(1, id);
            statement.executeUpdate();

            // Supprimer les détails de la demande
            deleteDetailsByDemandeId(id);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public List<Demande> findByEtat(String etat) {
        List<Demande> demandesByEtat = new ArrayList<>();
        String query = "SELECT * FROM demandes WHERE statut = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, etat);
            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                Demande demande = new Demande();
                demande.setId(resultSet.getLong("id"));
                Client client = getClientById(resultSet.getLong("client_id"));
                demande.setClient(client);
                demande.setStatut(resultSet.getString("statut"));
                demande.setMontantTotal(resultSet.getDouble("montant_total"));
                demande.setDate(resultSet.getDate("date").toLocalDate());

                // Récupérer les détails de la demande
                List<DetailsDemande> detailsDemandes = getDetailsDemandesByDemandeId(demande.getId());
                demande.setDetailsDemandes(detailsDemandes);

                demandesByEtat.add(demande);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return demandesByEtat;
    }

    @Override
    public List<Demande> findByClient(Client client) {
        List<Demande> demandesByClient = new ArrayList<>();
        String query = "SELECT * FROM demandes WHERE client_id = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setLong(1, client.getId());
            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                Demande demande = new Demande();
                demande.setId(resultSet.getLong("id"));
                demande.setClient(client);
                demande.setStatut(resultSet.getString("statut"));
                demande.setMontantTotal(resultSet.getDouble("montant_total"));
                demande.setDate(resultSet.getDate("date").toLocalDate());

                // Récupérer les détails de la demande
                List<DetailsDemande> detailsDemandes = getDetailsDemandesByDemandeId(demande.getId());
                demande.setDetailsDemandes(detailsDemandes);

                demandesByClient.add(demande);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return demandesByClient;
    }

    @Override
    public List<Demande> findByClientandEtat(Client client, String etat) {
        List<Demande> demandesByClientEtat = new ArrayList<>();
        String query = "SELECT * FROM demandes WHERE client_id = ? AND statut = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setLong(1, client.getId());
            statement.setString(2, etat);
            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                Demande demande = new Demande();
                demande.setId(resultSet.getLong("id"));
                demande.setClient(client);
                demande.setStatut(resultSet.getString("statut"));
                demande.setMontantTotal(resultSet.getDouble("montant_total"));
                demande.setDate(resultSet.getDate("date").toLocalDate());

                // Récupérer les détails de la demande
                List<DetailsDemande> detailsDemandes = getDetailsDemandesByDemandeId(demande.getId());
                demande.setDetailsDemandes(detailsDemandes);

                demandesByClientEtat.add(demande);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return demandesByClientEtat;
    }

    private Client getClientById(long clientId) {
        // Récupérer le client par son ID
        // Implémentation à adapter selon votre logique de récupération de clients.
        return new Client();  // Remplacez par l'appel réel au repository Client
    }

    private List<DetailsDemande> getDetailsDemandesByDemandeId(long demandeId) {
        List<DetailsDemande> detailsDemandes = new ArrayList<>();
        String query = "SELECT * FROM details_demandes WHERE demande_id = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setLong(1, demandeId);
            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                DetailsDemande details = new DetailsDemande();
            details.setId(resultSet.getLong("id"));
            details.setQuantite(resultSet.getLong("quantite"));
            
            Article article = new Article();
            article.setNom(resultSet.getString("article_nom"));
            details.setArticle(article);  
            detailsDemandes.add(details);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return detailsDemandes;
    }

    private void deleteDetailsByDemandeId(long demandeId) {
        String query = "DELETE FROM details_demandes WHERE demande_id = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setLong(1, demandeId);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
