package com.example.repositories.impl;

import com.example.entities.Admin;
import com.example.entities.User;
import com.example.repositories.IAdminRepository;
import com.example.datasource.DataSource;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AdminRepositoryImpl implements IAdminRepository {
    private final DataSource dataSource;

    public AdminRepositoryImpl(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @Override
    public Admin add(Admin admin) throws SQLException {
        String sql = "INSERT INTO admins (noms, prenoms, telephone, user_id) VALUES (?, ?, ?, ?)";
        
        try (Connection conn = dataSource.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            stmt.setString(1, admin.getNoms());
            stmt.setString(2, admin.getPrenoms());
            stmt.setString(3, admin.getTelephone());
            stmt.setLong(4, admin.getUser().getId()); // Assumes user is already set with a valid ID

            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        admin.setId(generatedKeys.getLong(1)); // Set the generated ID
                    }
                }
            }
        }
        return admin;
    }

    @Override
    public List<Admin> selectAll() throws SQLException {
        String sql = "SELECT id, noms, prenoms, telephone, user_id FROM admins";
        List<Admin> admins = new ArrayList<>();

        try (Connection conn = dataSource.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                Admin admin = mapToAdmin(rs);
                admins.add(admin);
            }
        }

        return admins;
    }

    @Override
    public Admin findById(Long id) throws SQLException {
        String sql = "SELECT id, noms, prenoms, telephone, user_id FROM admins WHERE id = ?";
        Admin admin = null;

        try (Connection conn = dataSource.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setLong(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    admin = mapToAdmin(rs);
                }
            }
        }

        return admin;
    }

    @Override
    public Admin selectByLogin(String login) throws SQLException {
        String sql = "SELECT a.id, a.noms, a.prenoms, a.telephone, a.user_id " +
                     "FROM admins a JOIN users u ON a.user_id = u.id WHERE u.login = ?";
        Admin admin = null;

        try (Connection conn = dataSource.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, login);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    admin = mapToAdmin(rs);
                }
            }
        }

        return admin;
    }

    @Override
    public void update(Admin admin) throws SQLException {
        String sql = "UPDATE admins SET noms = ?, prenoms = ?, telephone = ?, user_id = ? WHERE id = ?";
        
        try (Connection conn = dataSource.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, admin.getNoms());
            stmt.setString(2, admin.getPrenoms());
            stmt.setString(3, admin.getTelephone());
            stmt.setLong(4, admin.getUser().getId());
            stmt.setLong(5, admin.getId());

            stmt.executeUpdate();
        }
    }

    @Override
    public void delete(Admin admin) throws SQLException {
        String sql = "DELETE FROM admins WHERE id = ?";
        
        try (Connection conn = dataSource.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setLong(1, admin.getId());
            stmt.executeUpdate();
        }
    }

    @Override
    public void deleteById(Long id) throws SQLException {
        String sql = "DELETE FROM admins WHERE id = ?";
        
        try (Connection conn = dataSource.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setLong(1, id);
            stmt.executeUpdate();
        }
    }

    // Mapper le ResultSet à l'objet Admin
    private Admin mapToAdmin(ResultSet rs) throws SQLException {
        Admin admin = new Admin();
        admin.setId(rs.getLong("id"));
        admin.setNoms(rs.getString("noms"));
        admin.setPrenoms(rs.getString("prenoms"));
        admin.setTelephone(rs.getString("telephone"));

        // Mapper l'utilisateur associé
        User user = new User();
        user.setId(rs.getLong("user_id"));
        admin.setUser(user);

        return admin;
    }
}
