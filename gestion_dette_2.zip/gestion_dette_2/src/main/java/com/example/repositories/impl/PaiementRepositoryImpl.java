package com.example.repositories.impl;

import com.example.entities.Paiement;
import com.example.repositories.IPaiementRepository;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PaiementRepositoryImpl implements IPaiementRepository {
    private Connection connection;

    public PaiementRepositoryImpl(Connection connection) {
        this.connection = connection;
    }

    @Override
    public Paiement add(Paiement paiement) {
        String query = "INSERT INTO paiements (montant, date_paiement, id_client) VALUES (?, ?, ?)";
        
        try (PreparedStatement stmt = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setDouble(1, paiement.getMontant());
            stmt.setDate(2, Date.valueOf(paiement.getDatePaiement()));
            stmt.setLong(3, paiement.getIdClient());

            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        paiement.setId(generatedKeys.getLong(1));
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return paiement;
    }

    @Override
    public List<Paiement> selectAll() {
        List<Paiement> paiements = new ArrayList<>();
        String query = "SELECT * FROM paiements";

        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                Paiement paiement = new Paiement();
                paiement.setId(rs.getLong("id"));
                paiement.setMontant(rs.getDouble("montant"));
                paiement.setDatePaiement(rs.getDate("date_paiement").toLocalDate());
                paiement.setIdClient(rs.getLong("id_client"));
                paiements.add(paiement);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return paiements;
    }

    @Override
    public Paiement findById(Long id) {
        Paiement paiement = null;
        String query = "SELECT * FROM paiements WHERE id = ?";

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setLong(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    paiement = new Paiement();
                    paiement.setId(rs.getLong("id"));
                    paiement.setMontant(rs.getDouble("montant"));
                    paiement.setDatePaiement(rs.getDate("date_paiement").toLocalDate());
                    paiement.setIdClient(rs.getLong("id_client"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return paiement;
    }

    @Override
    public void update(Paiement paiement) {
        String query = "UPDATE paiements SET montant = ?, date_paiement = ?, id_client = ? WHERE id = ?";

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setDouble(1, paiement.getMontant());
            stmt.setDate(2, Date.valueOf(paiement.getDatePaiement()));
            stmt.setLong(3, paiement.getIdClient());
            stmt.setLong(4, paiement.getId());

            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected == 0) {
                throw new IllegalArgumentException("Paiement not found");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void delete(Paiement paiement) {
        String query = "DELETE FROM paiements WHERE id = ?";

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setLong(1, paiement.getId());
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected == 0) {
                throw new IllegalArgumentException("Paiement not found");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void deleteById(Long id) {
        Paiement paiement = findById(id);
        if (paiement != null) {
            delete(paiement);
        } else {
            throw new IllegalArgumentException("Paiement not found");
        }
    }
}
