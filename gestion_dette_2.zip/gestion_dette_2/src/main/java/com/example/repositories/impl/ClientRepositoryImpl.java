package com.example.repositories.impl;

import com.example.entities.Client;
import com.example.entities.User;
import com.example.repositories.IClientRepository;
import com.example.repositories.RepositoryBDImpl;
import com.example.datasource.DataSource;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ClientRepositoryImpl implements IClientRepository {
    private final RepositoryBDImpl repositoryBD;

    public ClientRepositoryImpl(DataSource dataSource) {
        this.repositoryBD = new RepositoryBDImpl(dataSource);
    }

    // Ajouter un client
    public Client add(Client client) throws SQLException {
        String[] fields = {"surname", "telephone", "adresse", "user_id"};
        Object[] values = {
            client.getSurname(),
            client.getTelephone(),
            client.getAdresse(),
            (client.getUser() != null) ? client.getUser().getId() : null
        };
        int generatedId = repositoryBD.insert("clients", fields, values);
    
        client.setId((long) generatedId); // Convertir l'ID en type Long si nécessaire
        return client;
    }

    // Récupérer tous les clients
    public List<Client> selectAll() throws SQLException {
        ResultSet resultSet = repositoryBD.selectAll("clients");

        List<Client> clients = new ArrayList<>();

        while (resultSet.next()) {
            Client client = mapToClient(resultSet);
            clients.add(client);
        }

        return clients;
    }


    // Récupérer un client par son téléphone
    public Client selectByTelephone(String telephone) throws SQLException {
        String sql = "SELECT * FROM clients WHERE telephone = ?";
        ResultSet resultSet = repositoryBD.getDataSource().executeQuery(sql, telephone);

        if (resultSet.next()) {
            return mapToClient(resultSet);
        }

        return null; // Aucun client trouvé avec ce numéro de téléphone
    }

    // Récupérer un client par son login
    @Override
    public Client selectByLogin(String login) throws SQLException {
        String sql = "SELECT * FROM clients WHERE user_id = (SELECT id FROM users WHERE login = ?)";
        ResultSet resultSet = repositoryBD.getDataSource().executeQuery(sql, login);

        if (resultSet.next()) {
            return mapToClient(resultSet);
        }

        return null; // Aucun client trouvé avec ce login
    }

    // Mapper le ResultSet à l'objet Client
    private Client mapToClient(ResultSet resultSet) throws SQLException {
        Client client = new Client();
        client.setId(resultSet.getLong("id"));
        client.setSurname(resultSet.getString("surname"));
        client.setTelephone(resultSet.getString("telephone"));
        client.setAdresse(resultSet.getString("adresse"));

        // Mapper l'utilisateur associé
        User user = new User();
        user.setId(resultSet.getLong("user_id"));
        client.setUser(user);

        return client;
    }

    // Mettre à jour un client
    @Override
    public void update(Client client) throws SQLException {
        String sql = "UPDATE clients SET surname = ?, telephone = ?, adresse = ?, user_id = ? WHERE id = ?";
        repositoryBD.getDataSource().executeUpdate(sql, client.getSurname(), client.getTelephone(), client.getAdresse(), client.getUser().getId(), client.getId());
    }

    // Supprimer un client
    @Override
    public void delete(Client client) throws SQLException {
        String sql = "DELETE FROM clients WHERE id = ?";
        repositoryBD.getDataSource().executeUpdate(sql, client.getId());
    }

    // Supprimer un client par son ID
    @Override
    public void deleteById(Long id) throws SQLException {
        String sql = "DELETE FROM clients WHERE id = ?";
        repositoryBD.getDataSource().executeUpdate(sql, id);
    }

    @Override
    public Client findById(Long id) throws SQLException {
        String sql = "SELECT * FROM clients WHERE id = ?";
        ResultSet resultSet = repositoryBD.getDataSource().executeQuery(sql, id);

        if (resultSet.next()) {
            return mapToClient(resultSet);
        }

        return null; // Aucun client trouvé avec cet ID
    }
}

    

    

