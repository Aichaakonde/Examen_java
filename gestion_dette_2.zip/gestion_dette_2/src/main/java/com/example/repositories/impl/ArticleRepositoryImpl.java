package com.example.repositories.impl;

import com.example.entities.Article;
import com.example.repositories.IArticleRepository;
import com.example.datasource.DataSource;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ArticleRepositoryImpl implements IArticleRepository {
    private final DataSource dataSource;

    public ArticleRepositoryImpl(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @Override
    public Article add(Article article) throws SQLException {
        String sql = "INSERT INTO articles (nom, description, prix) VALUES (?, ?, ?)";

        try (Connection conn = dataSource.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            stmt.setString(1, article.getNom());
            stmt.setLong(2, article.getQteStock());
            stmt.setDouble(3, article.getPrix());

            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        article.setId(generatedKeys.getInt(1)); // Set the generated ID
                    }
                }
            }
        }
        return article;
    }

    @Override
    public List<Article> selectAll() throws SQLException {
        String sql = "SELECT id, nom, description, prix FROM articles";
        List<Article> articles = new ArrayList<>();

        try (Connection conn = dataSource.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Article article = mapToArticle(rs);
                articles.add(article);
            }
        }

        return articles;
    }

    @Override
    public Article findById(Long id) throws SQLException {
        String sql = "SELECT id, nom, description, prix FROM articles WHERE id = ?";
        Article article = null;

        try (Connection conn = dataSource.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setLong(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    article = mapToArticle(rs);
                }
            }
        }

        return article;
    }

    @Override
    public void update(Article article) throws SQLException {
        String sql = "UPDATE articles SET nom = ?, description = ?, prix = ? WHERE id = ?";

        try (Connection conn = dataSource.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, article.getNom());
            stmt.setLong(2, article.getQteStock());
            stmt.setDouble(3, article.getPrix());
            stmt.setLong(4, article.getId());

            stmt.executeUpdate();
        }
    }

    @Override
    public void delete(Article article) throws SQLException {
        String sql = "DELETE FROM articles WHERE id = ?";

        try (Connection conn = dataSource.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setLong(1, article.getId());
            stmt.executeUpdate();
        }
    }

    @Override
    public void deleteById( Long id) throws SQLException {
        String sql = "DELETE FROM articles WHERE id = ?";

        try (Connection conn = dataSource.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setLong(1, id);
            stmt.executeUpdate();
        }
    }

    @Override
    public Article findByLibelle(String libelle) throws SQLException {
        String sql = "SELECT id, nom, description, prix FROM articles WHERE nom = ?";
        Article article = null;

        try (Connection conn = dataSource.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, libelle);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    article = mapToArticle(rs);
                }
            }
        }

        return article;
    }

    // Mapper le ResultSet à un objet Article
    private Article mapToArticle(ResultSet rs) throws SQLException {
        Article article = new Article();
        article.setId(rs.getLong("id"));
        article.setNom(rs.getString("nom"));
        article.setQteStock(rs.getLong("quantite"));
        article.setPrix(rs.getDouble("prix"));

        return article;
    }
}
