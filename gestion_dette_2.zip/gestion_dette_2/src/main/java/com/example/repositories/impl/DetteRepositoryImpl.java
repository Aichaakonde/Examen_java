package com.example.repositories.impl;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import java.time.LocalDate;

import com.example.entities.Dette;
import com.example.entities.DetailsDetteArticle;
import com.example.entities.Paiement;
import com.example.entities.Client;
import com.example.repositories.IDetteRepository;

public class DetteRepositoryImpl implements IDetteRepository {

    // Connexion à la base de données, utilisez votre propre méthode de connexion
    private Connection connection;

    public DetteRepositoryImpl(Connection connection) {
        this.connection = connection;
    }

    @Override
    public Dette add(Dette dette) throws SQLException {
        String query = "INSERT INTO dette (date, montant, montant_verser, statut, client_id) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {
            statement.setDate(1, Date.valueOf(dette.getDate()));
            statement.setDouble(2, dette.getMontant());
            statement.setDouble(3, dette.getMontantVerser());
            statement.setString(4, dette.getStatut());
            statement.setLong(5, dette.getClient().getId()); // On suppose que le client est déjà associé

            int affectedRows = statement.executeUpdate();

            if (affectedRows > 0) {
                ResultSet generatedKeys = statement.getGeneratedKeys();
                if (generatedKeys.next()) {
                    Long id = generatedKeys.getLong(1);
                    dette.setId(id);
                    return dette;
                }
            }
            return null;
        }
    }

    @Override
    public List<Dette> selectAll() throws SQLException {
        String query = "SELECT * FROM dette";
        List<Dette> dettes = new ArrayList<>();

        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {

            while (resultSet.next()) {
                Dette dette = mapResultSetToDette(resultSet);
                dettes.add(dette);
            }
        }
        return dettes;
    }

    @Override
    public Dette findById(Long id) throws SQLException {
        String query = "SELECT * FROM dette WHERE id = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setLong(1, id);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                return mapResultSetToDette(resultSet);
            }
        }
        return null;
    }

    @Override
    public void update(Dette dette) throws SQLException {
        String query = "UPDATE dette SET date = ?, montant = ?, montant_verser = ?, statut = ?, client_id = ? WHERE id = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setDate(1, Date.valueOf(dette.getDate()));
            statement.setDouble(2, dette.getMontant());
            statement.setDouble(3, dette.getMontantVerser());
            statement.setString(4, dette.getStatut());
            statement.setLong(5, dette.getClient().getId());
            statement.setLong(6, dette.getId());

            statement.executeUpdate();
        }
    }

    @Override
    public void delete(Dette dette) throws SQLException {
        String query = "DELETE FROM dette WHERE id = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setLong(1, dette.getId());
            statement.executeUpdate();
        }
    }

    @Override
    public void deleteById(Long id) throws SQLException {
        String query = "DELETE FROM dette WHERE id = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setLong(1, id);
            statement.executeUpdate();
        }
    }

    private Dette mapResultSetToDette(ResultSet resultSet) throws SQLException {
        Long id = resultSet.getLong("id");
        LocalDate date = resultSet.getDate("date").toLocalDate();
        double montant = resultSet.getDouble("montant");
        double montantVerser = resultSet.getDouble("montant_verser");
        String statut = resultSet.getString("statut");

        // Récupérer l'ID du client
        Long clientId = resultSet.getLong("client_id");
        Client client = new Client(clientId, "Nom Client", "Prenom Client", statut, null, null, null);  // A adapter selon votre logique pour récupérer un client complet

        // Récupérer les paiements et details (vous aurez besoin de méthodes pour les récupérer selon votre structure de base de données)
        List<DetailsDetteArticle> detailsDetteArticles = new ArrayList<>();  // A compléter avec la logique pour récupérer les détails
        List<Paiement> paiements = new ArrayList<>(); // A compléter avec la logique pour récupérer les paiements

        return new Dette(id, date, montant, montantVerser, statut, detailsDetteArticles, paiements, client);
    }

    @Override
    public List<Dette> findByStatut(String statut) throws SQLException {
        String query = "SELECT * FROM dette WHERE statut = ?";
        List<Dette> dettesByStatut = new ArrayList<>();

        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, statut);
            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                Dette dette = mapResultSetToDette(resultSet);
                dettesByStatut.add(dette);
            }
        }

        return dettesByStatut;
    }

    @Override
    public List<Dette> findByClient(Client client) throws SQLException {
        String query = "SELECT * FROM dette WHERE client_id = ?";
        List<Dette> dettesByClient = new ArrayList<>();

        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setLong(1, client.getId());
            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                Dette dette = mapResultSetToDette(resultSet);
                dettesByClient.add(dette);
            }
        }

        return dettesByClient;
    }

    @Override
    public List<Dette> findByClientAndStatut(Client client, String statut) throws SQLException {
        String query = "SELECT * FROM dette WHERE client_id = ? AND statut = ?";
        List<Dette> dettesByClientAndStatut = new ArrayList<>();

        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setLong(1, client.getId());
            statement.setString(2, statut);
            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                Dette dette = mapResultSetToDette(resultSet);
                dettesByClientAndStatut.add(dette);
            }
        }

        return dettesByClientAndStatut;
    }

    
}
