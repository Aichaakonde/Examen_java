package com.example.repositories.impl;

import com.example.entities.Boutiquier;
import com.example.repositories.IBoutiquierRepository;
import com.example.entities.User;


import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BoutiquierRepositoryImpl implements IBoutiquierRepository {
    
    // Connexion à la base de données
    private Connection connection;

    public BoutiquierRepositoryImpl(Connection connection) {
        this.connection = connection;
    }

    @Override
    public Boutiquier add(Boutiquier boutiquier) {
        String query = "INSERT INTO boutiquiers (noms, prenoms, telephone, login, password) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {
            statement.setString(1, boutiquier.getNoms());
            statement.setString(2, boutiquier.getPrenoms());
            statement.setString(3, boutiquier.getTelephone());
            statement.setString(4, boutiquier.getUser().getLogin());
            statement.setString(5, boutiquier.getUser().getPassword());  // Assuming the User object has a password
            statement.executeUpdate();

            // Obtenir l'ID généré automatiquement
            ResultSet generatedKeys = statement.getGeneratedKeys();
            if (generatedKeys.next()) {
                boutiquier.setId(generatedKeys.getLong(1));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return boutiquier;
    }

    @Override
    public List<Boutiquier> selectAll() {
        List<Boutiquier> boutiquiers = new ArrayList<>();
        String query = "SELECT * FROM boutiquiers";
        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {

            while (resultSet.next()) {
                Boutiquier boutiquier = new Boutiquier();
                boutiquier.setId(resultSet.getLong("id"));
                boutiquier.setNoms(resultSet.getString("noms"));
                boutiquier.setPrenoms(resultSet.getString("prenoms"));
                boutiquier.setTelephone(resultSet.getString("telephone"));
                // Assuming the User is another entity to be fetched by login
                boutiquier.setUser(new User(resultSet.getString("login"), resultSet.getString("password"), "BOUTIQUIER", true));
                boutiquiers.add(boutiquier);            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return boutiquiers;
    }

    @Override
    public Boutiquier findById(Long id) {
        Boutiquier boutiquier = null;
        String query = "SELECT * FROM boutiquiers WHERE id = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setLong(1, id);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                boutiquier = new Boutiquier();
                boutiquier.setId(resultSet.getLong("id"));
                boutiquier.setNoms(resultSet.getString("noms"));
                boutiquier.setPrenoms(resultSet.getString("prenoms"));
                boutiquier.setTelephone(resultSet.getString("telephone"));
                boutiquier.setUser(new User(resultSet.getString("login"), resultSet.getString("password"), "BOUTIQUIER", true));
                 }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return boutiquier;
    }

    @Override
    public Boutiquier selectByLogin(String login) {
        Boutiquier boutiquier = null;
        String query = "SELECT * FROM boutiquiers WHERE login = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, login);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                boutiquier = new Boutiquier();
                boutiquier.setId(resultSet.getLong("id"));
                boutiquier.setNoms(resultSet.getString("noms"));
                boutiquier.setPrenoms(resultSet.getString("prenoms"));
                boutiquier.setTelephone(resultSet.getString("telephone"));
                boutiquier.setUser(new User(resultSet.getString("login"), resultSet.getString("password"), "BOUTIQUIER", true));
                }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return boutiquier;
    }

    @Override
    public void update(Boutiquier entity) {
        String query = "UPDATE boutiquiers SET noms = ?, prenoms = ?, telephone = ?, login = ?, password = ? WHERE id = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, entity.getNoms());
            statement.setString(2, entity.getPrenoms());
            statement.setString(3, entity.getTelephone());
            statement.setString(4, entity.getUser().getLogin());
            statement.setString(5, entity.getUser().getPassword());
            statement.setLong(6, entity.getId());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void delete(Boutiquier entity) {
        String query = "DELETE FROM boutiquiers WHERE id = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setLong(1, entity.getId());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void deleteById(Long id) {
        String query = "DELETE FROM boutiquiers WHERE id = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setLong(1, id);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
