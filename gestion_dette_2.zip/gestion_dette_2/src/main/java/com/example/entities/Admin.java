package com.example.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Admin {
    private Long id;
    private String noms, prenoms,telephone;
    private User user;
    private static long compteurId=1;

    public Admin( String noms, String prenoms, String telephone, User user) {
        this.id =compteurId++;
        this.noms = noms;
        this.prenoms = prenoms;
        this.telephone = telephone;
        this.user = user;
    }



    @Override
    public String toString() {
        return "Admin [id=" + id + ", noms=" + noms + ", prenoms=" + prenoms + ", telephone=" + telephone + ", userID=" + (user!=null ? user.getId() : "null")+ "]";
    }

    


    
}

