package com.example.entities;

import java.time.LocalDate;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor

public class Dette {

    private static long compteurId= 1;
    private Long id;
    private LocalDate date;
    private double montant;
    private double montantVerser;
    private String statut;
    private List<DetailsDetteArticle> detailsDetteArticles;
    private List<Paiement> paiements;
    private Client client;

    public Dette( LocalDate date, double montant, double montantVerser,String statut,Client client, List<DetailsDetteArticle> detailsDetteArticles,List<Paiement> paiements) {
        this.id = compteurId++;
        this.date = date;
        this.montant = montant;
        this.montantVerser = montantVerser;
        this.statut=statut;
        this.detailsDetteArticles = detailsDetteArticles;
        this.paiements = paiements;
        this.client = client;
    }


    @Override
    public String toString() {
        return "Dette [" +
                "id=" + id + 
                ", date=" + date + 
                ", montant=" + montant + 
                ", montantVerser=" + montantVerser + 
                ", statut="+ statut + 
                ", client="+ client + 
                ", details=" + detailsDetteArticles.size() + 
                ", paiements=" + paiements.size() + 
                "]";
    }

   
    
}
