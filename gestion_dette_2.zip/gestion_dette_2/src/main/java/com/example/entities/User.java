package com.example.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class User {
    private Long id;
    private String login;
    private String password;
    private String role;  // ADMIN, BOUTIQUIER, CLIENT
    private boolean isActive;

    private static long compteurId = 1;

    // Constantes pour les rôles
    public static final String ROLE_ADMIN = "ADMIN";
    public static final String ROLE_BOUTIQUIER = "BOUTIQUIER";
    public static final String ROLE_CLIENT = "CLIENT";

    // Constructeur sans ID (auto-généré)
    public User(String login, String password, String role, boolean isActive) {
        this.id = compteurId++;
        this.login = login;
        this.password = password;
        this.role = validateRole(role);
        this.isActive = isActive;
    }

    // Méthodes Utiles
    public void activate() {
        this.isActive = true;
    }

    public void deactivate() {
        this.isActive = false;
    }

    // Méthode de Validation du Rôle
    private String validateRole(String role) {
        if (!role.equals(ROLE_ADMIN) && !role.equals(ROLE_BOUTIQUIER) && !role.equals(ROLE_CLIENT)) {
            throw new IllegalArgumentException("Rôle invalide : " + role);
        }
        return role;
    }

    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                ", login='" + login + '\'' +
                ", role='" + role + '\'' +
                ", isActive=" + isActive +
                '}';
    }
}
