package com.example.entities;

import java.util.ArrayList;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor

public class Client {
    private Long id;
    private String surname,telephone,adresse;
    private User user;
    private List<Demande> demandes = new ArrayList<>();
    private List<Dette> dettes = new ArrayList<>();
    private static long compteurId=1;


    public Client( String surname, String telephone, String adresse, User user, List<Demande> demandes, List<Dette> dettes) {
        this.id = compteurId++;
        this.surname = surname;
        this.telephone = telephone;
        this.adresse = adresse;
        this.user = user;
        this.demandes = demandes;
        this.dettes = dettes;
    }
   
    
    @Override
    public String toString() {
        return "Client [id=" + id + ", surname=" + surname + ", telephone=" + telephone + ", adresse=" + adresse
                + ", userID=" + (user!=null ? user.getId() : "null") + ", demandes=" + demandes.size() + ", dettes=" + dettes.size() + "]";
    }

   
}
