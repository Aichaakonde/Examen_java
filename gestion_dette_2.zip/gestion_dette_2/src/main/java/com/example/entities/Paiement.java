package com.example.entities;

import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor

public class Paiement {
    private Long id;
    private LocalDate date;
    private double montant;
    private LocalDate datePaiement;
    private Long idClient;
    private static long compteurId= 1;
        
            // Constructeur corrigé
            public Paiement(LocalDate date, double montant) {
                this.id = compteurId++;
                this.date = date;
                this.montant = montant;
            }
        
            public LocalDate getDatePaiement() {
                return getDatePaiement();
            }
        
            public void setDatePaiement(LocalDate datePaiement) {
                this.datePaiement = datePaiement;
        }
    
        public int getIdClient() {
            return getIdClient();
        }
    
        public void setIdClient(Long idClient) {
            this.idClient = idClient;
    }
}
    

