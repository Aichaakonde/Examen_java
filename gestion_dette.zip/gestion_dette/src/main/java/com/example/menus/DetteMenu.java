package com.example.menus;

import java.util.Scanner;

import com.example.core.config.Config;
import com.example.entities.Client;
import com.example.entities.Dette;
import com.example.services.IArticleService;
import com.example.services.IClientService;
import com.example.services.IDetteService;
import com.example.views.ClientView;
import com.example.views.DetailsDetteArticleView;
import com.example.views.DetteView;
import com.example.views.PaiementDetteArticleView;


public abstract class DetteMenu {
    private static final Scanner scanner = new Scanner(System.in); 
    private static final IClientService clientService = Config.getClientService();
    private static final IArticleService articleService = Config.getArticleService();


    public static void commencer(IDetteService detteService) {
        int choix;
        do {
            choix = DetteView.menu(); // Appel de la méthode du menu dans DetteView
            switch (choix) {
                case 1:
                    Client client = ClientView.rechercheClientParTelephone(clientService.selectAll());
                    if(client != null) {
                        Dette dette = DetteView.create(articleService.selectAll(), client);
                        detteService.add(dette);
                    } else {
                        System.out.println("Il n'y a pas de client associé à ce telephone.");
                    }
                    
                    break;
                case 2:
                    DetteView.lister(detteService.selectAll());
                    break;
                case 3:
                    DetteView.lister(detteService.findByStatut("Soldée"));
                    break;
                case 4:
                    DetteView.lister(detteService.findByStatut("Non soldée"));
                    break;
                case 5:
                    Client clientTrouve = ClientView.rechercheClientParTelephone(clientService.selectAll());
                    if (clientTrouve!=null) {
                        DetteView.lister(detteService.findByClient(clientTrouve));  
                    }else{
                        System.out.println("Il n'y a pas de client associé à ce telephone.");
                    }
                    break;
                case 6:
                    Dette detteTrouve = DetteView.rechercherDetteParId(detteService.selectAll());
                    if (detteTrouve != null) {
                       int choixSousMenu = DetteView.menuDettesDetails();
                        do {
                            
                            switch (choixSousMenu) {
                                case 1:
                                    DetailsDetteArticleView.lister(detteTrouve.getDetailsDetteArticles());
                                    break;

                                case 2:
                                    PaiementDetteArticleView.lister(detteTrouve.getPaiements());
                                    break;
                                case 0:
                                    System.out.println("Quitter");
                                    break;
                                default:
                                    System.out.println("Choix  invalide.");
                                    break;
                            }
                        } while (choixSousMenu != 1 && choixSousMenu != 2);

                    } else {
                         System.out.println("Il n'y a pas de dette associée à cet ID.");
                        }
                        break;
                case 7:
                    // Recherche de la dette par ID
                    Dette detteTrouvee = DetteView.rechercherDetteParId(detteService.selectAll());
                    if (detteTrouvee!= null) {
                        if (detteTrouvee.getMontantVerser() == detteTrouvee.getMontant()) {
                            System.out.println("Cette dette est déjà soldée.");
                            break;
                            
                        }else{
                            System.out.println("Entrez un montant");
                            double montantPaiement;
                            while (true) {
                                try {
                                    montantPaiement = Double.parseDouble(scanner.nextLine());
    
                                    if (montantPaiement >= detteTrouvee.getMontant()) {
                                        System.out.println("Le montant du paiement doit être inferieur ou egal au montant Total de la dette.");  
                                        continue;  
                                    }
                                    else if (montantPaiement > (detteTrouvee.getMontant() - detteTrouvee.getMontantVerser())) { 
                                        System.out.println("Le montant du paiement dépasse le montant de la dette.");
                                        continue; 
                                    }
    
                                    
                                    break;
                                    
                                } catch (Exception e) {
                                    System.out.println("Veuillez saisir un montant valide");
                                }
                                
                            }
                           
                            detteTrouvee.setMontantVerser(detteTrouvee.getMontantVerser()+ montantPaiement);
                            if (detteTrouvee.getMontantVerser() == detteTrouvee.getMontant()) {
                                detteTrouvee.setStatut("Soldée");
                            
                            }
                        }
                    }else{
                         System.out.println("Il n'y a pas de dette associée à cet ID.");
                    }  
                    break;
                case 0:
                    System.out.println("Retour au menu principal.");
                    break;
                default:
                    System.out.println("Option invalide.");
                    break;
                }
            } while (choix != 0);
        }
    }
