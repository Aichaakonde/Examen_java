package com.example.menus;

import com.example.core.IAccount;
import com.example.core.IHasUser;
import com.example.entities.User;
import java.util.Scanner;

public abstract class LoginMenu {
    private static final Scanner scanner = new Scanner(System.in);

    private LoginMenu(){};

    public static <T> T afficherMenuConnexion(IAccount<T> service) {

        System.out.println("Login" + " :");
        String login = scanner.nextLine();
        System.out.println("Password :");
        String password = scanner.nextLine();

        T utilisateur = service.selectByLogin(login);
        if ((utilisateur != null) && (utilisateur instanceof IHasUser)) {
            User user = ((IHasUser)utilisateur).getUser();
            if (user != null && user.getLogin().equals(login) && user.getPassword().equals(password)) {
                return utilisateur;
            }
        }
        return null;
    }
}
