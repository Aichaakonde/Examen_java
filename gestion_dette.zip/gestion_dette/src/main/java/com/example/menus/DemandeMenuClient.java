package com.example.menus;

import com.example.entities.Client;
import com.example.entities.Demande;
import com.example.services.IArticleService;
import com.example.services.IDemandeService;
import com.example.views.DemandeView;
import com.example.views.DetailsDemandeView;

public  abstract class DemandeMenuClient {

    private DemandeMenuClient() {};

    public static void commencer(IDemandeService demandeService, IArticleService articleService, Client client) {
        // Menu Demande Client
        int choix;
        do {
            choix = DemandeView.menuClient();
            switch (choix) {
                case 1:
                    Demande demande = DemandeView.create(articleService.selectAll(), client);
                    demandeService.add(demande);
                    break;
                case 2:
                    DemandeView.lister(demandeService.findByClient(client));
                    break;
                case 3:
                    DemandeView.lister(demandeService.findByClientAndEtat(client, "En cours"));
                    break;  
                case 4:
                    DemandeView.lister(demandeService.findByClientAndEtat(client, "Rejetée"));
                    break; 
                case 5:
                     DemandeView.lister(demandeService.findByClientAndEtat(client, "Acceptée"));
                    break;   
                case 6 :
                    DemandeView.lister(demandeService.findByClient(client));
                    Demande demandeTrouvee =DemandeView.rechercherDemandeParId(demandeService.selectAll());
                    if (demandeTrouvee!=null) {
                        DetailsDemandeView.lister(demandeTrouvee.getDetailsDemandes());
                    }else{
                        System.out.println("Demande non trouvée.");
                    }
                    
                    break;    
                case 0:
                    System.out.println("Quitter");
                    return;
                default:
                    System.out.println("Faites votre choix");
            }
        } while (choix!=0);
    }    
    
}
