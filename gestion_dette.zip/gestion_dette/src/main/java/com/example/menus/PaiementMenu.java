package com.example.menus;

public abstract class PaiementMenu {
    
}
