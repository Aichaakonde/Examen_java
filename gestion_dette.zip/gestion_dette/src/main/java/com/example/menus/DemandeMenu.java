package com.example.menus;

import com.example.services.IDemandeService;
import com.example.views.DemandeView;

public abstract class DemandeMenu {

    private DemandeMenu(){};

    public static void commencer(IDemandeService demandeService){
        //Menu demande
        int choix;
        do {
            choix = DemandeView.menu();
            switch (choix) {
                case 1:
                    DemandeView.lister(demandeService.selectAll());
                    break;
                case 2:
                    DemandeView.lister(demandeService.findByEtat("En cours"));
                    break;
                case 3:
                   DemandeView.lister(demandeService.findByEtat("Rejetée"));
                    break;
                case 4:
                    DemandeView.lister(demandeService.findByEtat("Acceptée"));
                    break;
                case 5:

                    break;
                case 0:
                
                    // Quitter
                    System.out.println("Quitter");
                    return;
                default:
                    System.out.println("Faites votre choix");
            }
        } while (true);
    }

    
}
