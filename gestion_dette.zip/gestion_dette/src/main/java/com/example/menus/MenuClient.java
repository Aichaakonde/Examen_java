package com.example.menus;

import com.example.core.config.Config;
import com.example.entities.Client;
import com.example.services.IArticleService;
import com.example.services.IClientService;
import com.example.services.IDemandeService;
import com.example.services.IDetteService;
import com.example.views.ClientView;

public abstract class MenuClient {
     private static final IDemandeService demandeService = Config.getDemandeService();
    private static final IDetteService detteService = Config.getDetteService();
    private static final IArticleService articleService = Config.getArticleService();

    private MenuClient(){};

    public static void commencer(IClientService clientService){
        Client client = LoginMenu.afficherMenuConnexion(clientService);


        int choix;
        do {
            choix = ClientView.menuClient();
            switch (choix) {
                case 1:
                    DemandeMenuClient.commencer(demandeService, articleService, client);
                    break;
                case 2:
                    DetteMenuClient.commencer(detteService, articleService, client);
                    break;
                case 0 :
                    System.out.println("Quitter"); 
                default :
                    System.out.println("Choix Invalide");    
                }
            
        } while (choix != 0);
              
                   
                
    }


    
}
