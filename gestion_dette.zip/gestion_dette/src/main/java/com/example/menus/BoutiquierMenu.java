package com.example.menus;

import com.example.core.config.Config;
import com.example.entities.Boutiquier;
import com.example.services.IArticleService;
import com.example.services.IBoutiquierService;
import com.example.services.IClientService;
import com.example.services.IDemandeService;
import com.example.services.IDetteService;
import com.example.views.BoutiquierView;

public abstract class BoutiquierMenu {
    
        private static final IClientService clientService = Config.getClientService();
        private static final IArticleService articleService = Config.getArticleService();
        private static final IDemandeService demandeService = Config.getDemandeService();
        private static final IDetteService detteService = Config.getDetteService();

    private BoutiquierMenu(){};



   
    public static void commencer(IBoutiquierService boutiquierService) {

        Boutiquier boutiquier = LoginMenu.afficherMenuConnexion(boutiquierService);
        if (boutiquier != null) {
            int choix;
        do {
            choix = BoutiquierView.menu();
            switch (choix) {
                case 1 :
                    ClientMenu.commencer(clientService);
                    break;
                case 2 :
                    ArticleMenu.commencer(articleService);
                    break;
                case 3 :
                     DemandeMenu.commencer(demandeService);
                    break;
                case 4 :
                    DetteMenu.commencer(detteService);
                    break;
                    case 0 :
                    System.out.println("Quitter"); 
                default :
                    System.out.println("Choix Invalide"); 
            }
            
        } while (choix != 0); 
            
        } else {
            System.out.println("Identifiants invalides");
        } 
    }

}
