package com.example.core;

public interface IAccount <T> {
    T selectByLogin(String login);
}
