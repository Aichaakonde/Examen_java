package com.example.core;

import java.util.List;


public interface IService <T>{

   T add(T entity);
    List<T> selectAll();
    T findById(int id);
    void update(T entity);
    void delete(T entity);
    void deleteById(int id );
    
} 