package com.example.core.config;

import com.example.repositories.*;
import com.example.repositories.impl.*;
import com.example.services.*;
import com.example.services.impl.*;


import lombok.Getter;





public class Config {

    private  static final IClientRepository clientRepository = new ClientRepositoryImpl();

    private  static final IArticleRepository articleRepository = new ArticleRepositoryImpl();

    private  static final IBoutiquierRepository boutiquierRepository = new BoutiquierRepositoryImpl();

    private  static final IDetteRepository detteRepository = new DetteRepositoryImpl(); 

    private  static final IDemandeRepository demandeRepository = new DemandeRepositoryImpl();

    private static final IAdminRepository adminRepository = new AdminRepositoryImpl();

    private static final IPaiementRepository paiementRepository = new PaiementRepositoryImpl();

    private static final IUserRepository userRepository = new UserRepositoryImpl();

    private static final IDetailsDemandeRepository detailsDemandeRepository = new DetailsDemandeRepositoryImpl();

    private static final IDetailsDetteArticleRepository detailsDetteArticleRepository = new DetailsDetteArticleRepositoryImpl();




    @Getter
    private  static final IClientService clientService = new ClientServiceImpl(clientRepository);
    @Getter
    private  static final IArticleService articleService = new ArticleServiceImpl(articleRepository);
    @Getter
    private  static final IBoutiquierService boutiquierService = new BoutiquierServiceImpl(boutiquierRepository);
    @Getter
    private  static final IDetteService detteService = new DetteServiceImpl(detteRepository);
    @Getter
    private  static final IDemandeService demandeService = new DemandeServiceImpl(demandeRepository);
    @Getter
    private static final IAdminService adminService = new AdminServiceImpl(adminRepository);
    @Getter
    private static final IPaiementService paiementService = new PaiementServiceImpl(paiementRepository);
    @Getter
    private static final IUserService userService = new UserServiceImpl(userRepository);
    @Getter
    private static final IDetailsDemandeService detailsDemandeService = new DetailsDemandeServiceImpl(detailsDemandeRepository);
    @Getter
    private static final IDetailsDetteArticleService detailsDetteArticleService = new DetailsDetteArticleServiceImpl(detailsDetteArticleRepository);


private Config(){}



    
}
