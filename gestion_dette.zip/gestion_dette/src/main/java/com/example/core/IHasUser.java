package com.example.core;

import com.example.entities.User;

public interface IHasUser {

    void setUser(User user);

    User getUser();
    
}
