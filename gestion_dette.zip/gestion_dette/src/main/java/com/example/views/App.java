package com.example.views;

import java.util.List;

import com.example.core.config.Config;
import com.example.entities.Admin;
import com.example.entities.Article;
import com.example.entities.Boutiquier;
import com.example.entities.User;
import com.example.menus.MainMenu;

public class App {  
    public static void main(String[] args) {
        List<Article> articlesDisponibles = initArticlesDisponibles();
        for (Article article : articlesDisponibles) {
            Config.getArticleService().add(article);
        }

        Admin admin = new Admin("akonde", "aicha", "771001010", null);
        User userAdmin = new User("aicha@gmail.com", "passer123", "Admin", true);
        admin.setUser(userAdmin);
        Config.getAdminService().add(admin);

        Boutiquier boutiquier = new Boutiquier("diallo", "alpha", "771001020", null);
        User userBoutiquier = new User("alpha@gmail.com", "passer123", "Boutiquier", true);
        boutiquier.setUser(userBoutiquier);
        Config.getBoutiquierService().add(boutiquier);

        MainMenu.commencer();

    }

    public static List<Article> initArticlesDisponibles() {
        return List.of(
            new Article("Pain", 150, 30, "Disponible"),
            new Article("Lait", 125, 150, "Disponible"),
            new Article("Sucre", 700, 50, "Disponible"),
            new Article("Farine", 1000, 48, "Disponible"),
            new Article("Beurre", 900, 20, "Disponible"),
            new Article("Jus", 1000, 90, "Disponible"),
            new Article("Chocolat", 1200, 17, "Disponible"),
            new Article("Cafe", 50, 250, "Disponible"),
            new Article("Cerelac", 350, 100, "Disponible"),
            new Article("Pates", 500, 68, "Disponible")
        );
    }

}

 