//  package com.example.views;

//  import java.util.ArrayList;
// import java.util.List;
// import java.util.Scanner;

// import com.example.entities.Article;
// import com.example.entities.Admin;
// import com.example.entities.Client;
// import com.example.entities.Demande;
// import com.example.entities.Dette;
// import com.example.entities.User;
// import com.example.services.IArticleService;
// import com.example.services.IClientService;
// import com.example.services.IUserService;


// public class MenuAdmin {
//     private Admin admin;
//     private final Scanner scanner = new Scanner(System.in);
//     private final IArticleService articleService;
//     private final IClientService clientService;
//     private final IUserService userService;
    
//      // Constructeur
//      public MenuAdmin(Admin admin, IArticleService articleService, IClientService clientService, IUserService userService) {
//         this.admin = admin;
//         this.articleService = articleService;
//         this.clientService = clientService;
//         this.userService = userService;
//     }

//     public void afficherMenuAdmin() {
//         while (true) {
//             System.out.println("Menu Admin");
//             System.out.println("1. Dettes");
//             System.out.println("2. Clients");
//             System.out.println("3. Articles");
//             System.out.println("4. Demandes");
//             System.out.println("5. Utilisateurs");
//             System.out.println("6. Quitter");
//             System.out.print("Entrez votre choix: ");
//             int choix = scanner.nextInt();
//             scanner.nextLine();

//             switch (choix) {
//                 case 1 : 
//                     menuDettes();
//                     break;
//                 case 2 : 
//                     menuClients();
//                     break;
//                 case 3 : 
//                     menuArticles();
//                     break;
//                 case 4 :
//                     menuDemandes();
//                     break;
//                 case 5 :
//                     menuUtilisateurs();
//                     break;
//                 case 6 : 
//                     System.out.println("Retour au menu principal.");
//                     return;
//                 default:
//                     System.out.println("Option invalide.");
//                     break;
//             }
//         }
//     } 
//     public void menuDettes() {
//         while (true) {
//             System.out.println("Menu Dettes");
//             System.out.println("1. Ajouter une demande");
//             System.out.println("2. Liste des dettes");
//             System.out.println("3. Sélectionner une demande");
//             System.out.println("4. Quitter");
//             System.out.print("Entrez votre choix: ");
//             int choix = scanner.nextInt();
//             scanner.nextLine();
            
//             switch (choix) {
//                 case 1 -> {
//                     System.out.println("Ajouter une demande");
//                     System.out.print("Entrer le montant de la demande : ");
//                     double montantDette = scanner.nextDouble();
//                     scanner.nextLine();
//                     System.out.print("Entrer le statut de la demande : ");
//                     String statut = scanner.nextLine();
//                     System.out.print("Entrer le numéro de téléphone du client : ");
//                     String telephone = scanner.nextLine();
                    
//                     Client client = clientService.selectByTelephone(telephone);
//                     if (client == null) {
//                         System.out.println("Aucun client trouvé avec ce numéro.");
//                         break;
//                     }
                    
//                     List<Article> articles = new ArrayList<>();
//                     Dette dette = new Dette(null, montantDette, 0, articles, new ArrayList<>());
//                     Demande demande = new Demande(null, montantDette, statut, client, articles);
//                     client.getDemandes().add(demande);
//                     System.out.println("Demande ajoutée avec succès.");
//                 }
//                 case 2 -> {
//                     System.out.println("Liste des dettes");
//                     List<Client> clients = clientService.findAll();
//                     if (clients.isEmpty()) {
//                         System.out.println("Aucune dette trouvée.");
//                     } else {
//                         clients.forEach(System.out::println);
//                     }
//                 }
//                 case 3 -> {
//                     System.out.println("Sélectionner une demande");
//                     System.out.print("Entrer le numéro de téléphone du client : ");
//                     String telephone = scanner.nextLine();
//                     Client client = clientService.selectByTelephone(telephone);
//                     if (client == null || client.getDemandes().isEmpty()) {
//                         System.out.println("Aucun client ou aucune demande trouvée.");
//                         break;
//                     }
//                     System.out.print("Entrer l'id de la demande : ");
//                     int id = scanner.nextInt();
//                     scanner.nextLine();
                    
//                     Demande demandeTrouveId = client.getDemandes().stream()
//                             .filter(d -> d.getId() == id)
//                             .findFirst()
//                             .orElse(null);
//                     if (demandeTrouveId != null) {
//                         System.out.println("Détails de la demande: " + demandeTrouveId);
//                     } else {
//                         System.out.println("Demande non trouvée.");
//                     }
//                 }
//                 case 4 -> {
//                     System.out.println("Retour au menu principal.");
//                     return; // Quitter le menu dettes
//                 }
//                 default -> System.out.println("Option invalide.");
//             }
//         }
//     }
    

//     public void menuClients() {

//     while (true) {
//         System.out.println("Menu Client");
//         System.out.println("1. Ajouter un client");
//         System.out.println("2. Liste les clients");
//         System.out.println("3. Rechercher un client par telephone");
//         System.out.println("4. Selectionner un client");
//         System.out.println("5. Quitter");
//         System.out.print("Entrez votre choix: ");
//         int choix = scanner.nextInt();
//         scanner.nextLine(); 

//         switch (choix) {
//             case 1:
//                 System.out.println("Ajouter un Client");
//                 System.out.println("Entrer le surname du client");
//                 String surname = scanner.nextLine();
//                 System.out.println("Entrer le telephone du client");
//                 String telephone = scanner.nextLine();
//                 System.out.println("Entrer l adresse du client");
//                 String adresse = scanner.nextLine();
//                 List<Demande>demandes = new ArrayList<>();
//                 List<Dette>dettes = new ArrayList<>();
//                 Client client = new Client(surname, telephone, adresse, null, demandes, dettes);
//                 clientService.create(client);
//                 break;
//             case 2:
//                System.out.println("Liste des clients");
//                 System.out.println(clientService.findAll());

//                 break;   
//             case 3:
//                 System.out.println("Entrer le numero telephone");
//                 String searchTelephone = scanner.nextLine();
//                 Client clientTrouve = clientService.selectByTelephone(searchTelephone);
//                 if (clientTrouve != null) {
//                     System.out.println(clientTrouve);
//                 } else {
//                     System.out.println("Il n'y a pas de client associé a ce numero");
//                 }
//                 break; 
                  
//             case 4 :
//                 System.out.println("Selectionner client par Id ");
//                 System.out.println("Enter l id du client");
//                 int id = scanner.nextInt();
//                 scanner.nextLine();
//                 Client clientTrouveId = clientService.rechercherParId(id);
//                 if (clientTrouveId != null) {
//                     System.out.println(clientTrouveId);
                    
//                 } else {
//                     System.out.println("Il n y a pas de client associé a cet id"); 
//                 }

//                 break;  
//             case 5 :
//                 System.out.println("Retour au Menu Principal.");
//                 return; // Quitter le menu client
//             default:
//                 System.out.println("Option invalide.");
//             break;  
              
//         }

//     }

// }

//     public void menuArticles() {
//         while (true) {
//             System.out.println("Menu Articles");
//             System.out.println("1. Ajouter un article");
//             System.out.println("2. Liste des articles");
//             System.out.println("3. Rechercher un article par id");
//             System.out.println("4. Quitter");
//             System.out.print("Entrez votre choix: ");
//             int choix = scanner.nextInt();
//             scanner.nextLine();
//             switch (choix) {
//                 case 1:
//                     System.out.println("Ajouter un Article");
//                     System.out.println("Entrer le nom du produit");
//                     String nom = scanner.nextLine();
//                     System.out.println("Entrer le prix du produit");
//                     double prix = scanner.nextDouble();
//                     System.out.println("Entrer la quantité en stock du produit");
//                     int qteStock = scanner.nextInt();
//                     System.out.println("Entrer la description du produit");
//                     String etat = scanner.nextLine();
//                     scanner.nextLine();
//                     Article article = new Article(nom, prix, qteStock, etat);
//                     articleService.create(article);
//                     break;
//                 case 2:
//                     System.out.println("Liste des articles");
//                     System.out.println(articleService.findAll());
//                     break;
//                 case 3:
//                     System.out.println("Entrer le id du produit");
//                     int id = scanner.nextInt();
//                     scanner.nextLine();
//                     Article articleTrouve = articleService.rechercherParId(id);
//                     if (articleTrouve!= null) {
//                         System.out.println(articleTrouve);
//                     } else {
//                         System.out.println("Il n y a pas de produit associé a cet id");
//                     }
//                     break;
                    
//                 case 4 :
//                 System.out.println("Retour au Menu Principal.");
//                 return; // Quitter le menu article
//                 default:
//                 System.out.println("Option invalide.");
//                 break;

//             }
//         } 

//     }
//     public void menuDemandes() {
//         while (true) {
//             System.out.println("Menu Demandes");
//             System.out.println("1. Lister les demandes");
//             System.out.println("2. Voir une demande par id");
//             System.out.println("3. Annuler une demande");
//             System.out.println("4. Accepter une demande");
//             System.out.println("5. Quitter");
//             System.out.print("Entrez votre choix: ");
//             int choix = scanner.nextInt();
//             scanner.nextLine();
    
//             // Déclarez les variables partagées ici
//             Client client = null;
//             boolean success = false; // Déclarée une seule fois ici
    
//             switch (choix) {
//                 case 1:
//                     System.out.print("Entrez le numéro de téléphone du client: ");
//                     String telephone = scanner.nextLine();
    
//                     client = clientService.selectByTelephone(telephone);
//                     if (client != null) {
//                         System.out.println("Liste des demandes");
//                         if (client.getDemandes() != null && !client.getDemandes().isEmpty()) {
//                             System.out.println(client.getDemandes());
//                         } else {
//                             System.out.println("Aucune demande trouvée pour ce client.");
//                         }
//                     } else {
//                         System.out.println("Aucun client trouvé avec ce numéro.");
//                     }
//                     break;
    
//                 case 2:
//                     System.out.print("Entrez l'ID du client: ");
//                     int clientId = scanner.nextInt();
//                     scanner.nextLine();
    
//                     client = clientService.rechercherParId(clientId);
//                     if (client != null) {
//                         System.out.print("Entrez l'ID de la demande: ");
//                         int id = scanner.nextInt();
//                         scanner.nextLine();
    
//                         Demande demande = client.getDemandes().stream()
//                             .filter(d -> d.getId() == id)
//                             .findFirst()
//                             .orElse(null);
    
//                         if (demande != null) {
//                             System.out.println(demande);
//                         } else {
//                             System.out.println("Il n'y a pas de demande associée à cet ID.");
//                         }
//                     } else {
//                         System.out.println("Aucun client trouvé avec cet ID.");
//                     }
//                     break;
    
//                 case 3:
//                     System.out.print("Entrez l'ID de la demande à annuler: ");
//                     int idDemandeAnnuler = scanner.nextInt();
//                     scanner.nextLine();
    
//                     success = clientService.annulerDemande(idDemandeAnnuler);
//                     if (success) {
//                         System.out.println("Demande annulée avec succès.");
//                     } else {
//                         System.out.println("Demande introuvable ou non annulée.");
//                     }
//                     break;
    
//                 case 4:
//                     System.out.print("Entrez l'ID de la demande à accepter: ");
//                     int idDemandeAccepter = scanner.nextInt();
//                     scanner.nextLine();
    
//                     success = clientService.accepterDemande(idDemandeAccepter);
//                     if (success) {
//                         System.out.println("Demande acceptée avec succès.");
//                     } else {
//                         System.out.println("Demande introuvable ou non acceptée.");
//                     }
//                     break;
    
//                 case 5:
//                     System.out.println("Retour au Menu Principal.");
//                     return;
    
//                 default:
//                     System.out.println("Option invalide.");
//                     break;
//             }
//         }
//     }
    
//             public void menuUtilisateurs() {
//                 while (true) {
//                     System.out.println("Menu Utilisateurs");
//                     System.out.println("1. Ajouter un utilisateur");
//                     System.out.println("2. Lister les utilisateurs");
//                     System.out.println("3. Modifier un utilisateur");
//                     System.out.println("4. Supprimer un utilisateur");
//                     System.out.println("5. Quitter");
//                     System.out.print("Entrez votre choix: ");
//                     int choix = scanner.nextInt();
//                     scanner.nextLine();
            
//                     // Déclarez les variables partagées ici
//                     User user = null;
//                     boolean success = false;
            
//                     switch (choix) {
//                         case 1:
//                             System.out.println("Ajouter un Utilisateur");
//                             System.out.print("Entrez le login de l utilisateur : ");
//                             String login = scanner.nextLine();
//                             System.out.print("Entrez le mot de passe de l utilisateur : ");
//                             String password = scanner.nextLine();
//                             System.out.print("Entrez le rôle (Admin / Boutiquier / Client) : ");
//                             String role = scanner.nextLine();
//                             System.out.print("Entrez le numéro de téléphone : ");
//                             boolean isActive = scanner.nextBoolean();
            
//                             user = new User(login, password, role, isActive);
//                             success = userService.create(user);
//                             if (success) {
//                                 System.out.println("Utilisateur ajouté avec succès.");
//                             } else {
//                                 System.out.println("Erreur lors de l'ajout de l'utilisateur.");
//                             }
//                             break;
//                         case 2:
//                             System.out.println("Liste des utilisateurs :");
//                             List<User> utilisateurs = userService.findAll();
//                             if (utilisateurs.isEmpty()) {
//                                 System.out.println("Aucun utilisateur trouvé.");
//                             } else {
//                                 utilisateurs.forEach(System.out::println);
//                             }
//                             break;
//                         case 3:
//                             System.out.print("Entrez l'ID de l'utilisateur à modifier : ");
//                             int idModifier = scanner.nextInt();
//                             scanner.nextLine();
            
//                             user = userService.findById(idModifier);
//                             if (user != null) {
//                                 System.out.println("Utilisateur trouvé : " + user);
//                                 System.out.print("Entrez le nouveau nom (laisser vide pour conserver le même) : ");
//                                 String nouveauNom = scanner.nextLine();
//                                 System.out.print("Entrez le nouveau prénom (laisser vide pour conserver le même) : ");
//                                 String nouveauPrenom = scanner.nextLine();
//                                 System.out.print("Entrez le nouveau téléphone (laisser vide pour conserver le même) : ");
//                                 String nouveauTelephone = scanner.nextLine();
            
//                                 userService.update(idModifier, nouveauNom, nouveauPrenom, nouveauTelephone);
//                                 System.out.println("Utilisateur modifié avec succès.");
//                             } else {
//                                 System.out.println("Utilisateur introuvable.");
//                             }
//                             break;
//                         case 4:
//                             System.out.print("Entrez l'ID de l'utilisateur à supprimer : ");
//                             int idSupprimer = scanner.nextInt();
//                             scanner.nextLine();
            
//                             success = userService.delete(idSupprimer);
//                             if (success) {
//                                 System.out.println("Utilisateur supprimé avec succès.");
//                             } else {
//                                 System.out.println("Utilisateur introuvable ou non supprimé.");
//                             }
//                             break;
//                         case 5:
//                             System.out.println("Retour au Menu Principal.");
//                             return;
//                         default:
//                             System.out.println("Option invalide.");
//                             break;
//                     }
//                 }
                    

//             }
            
//     }




