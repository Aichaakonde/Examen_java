package com.example.views;

import java.util.List;
import com.example.entities.DetailsDetteArticle;


public abstract class DetailsDetteArticleView {

     public static void lister(List<DetailsDetteArticle> detailsDetteArticles) {
        if (detailsDetteArticles.isEmpty()) {
            System.out.println("Il n y a pas de dette d article disponible");
        }
        else {
            for(DetailsDetteArticle detailsDetteArticle : detailsDetteArticles) {
                 System.out.println(detailsDetteArticle);

             } 
        }   
    }

    
}
