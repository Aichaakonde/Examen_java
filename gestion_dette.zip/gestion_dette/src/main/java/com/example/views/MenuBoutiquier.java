// package com.example.views;

// import java.util.ArrayList;
// import java.util.List;
// import java.util.Scanner;

// import com.example.entities.Article;
// import com.example.entities.Boutiquier;
// import com.example.entities.Client;
// import com.example.entities.Demande;
// import com.example.entities.Dette;
// import com.example.repositories.IArticleRepository;
// import com.example.repositories.IClientRepository;
// import com.example.services.IArticleService;
// import com.example.services.IClientService;



// public class MenuBoutiquier {
//     private Boutiquier boutiquier; 
//     private final Scanner scanner = new Scanner(System.in);
//     private final IArticleService articleService;
//     private final IClientService clientService;





//     // Constructeur
//     public MenuBoutiquier(Boutiquier boutiquier,IArticleService articleService,IClientService clientService ) {
//         this.boutiquier = boutiquier;
//         this.articleService = articleService;
//         this.clientService = clientService; 
//     }



//     public void afficherMenuBoutiquier() {
//         while (true) {
//             System.out.println("Menu Boutiquier");
//             System.out.println("1. Dettes");
//             System.out.println("2. Clients");
//             System.out.println("3. Articles");
//             System.out.println("4. Demandes");
//             System.out.println("5. Quitter");
//             System.out.print("Entrez votre choix: ");
//             int choix = scanner.nextInt();
//             scanner.nextLine(); 

//             switch (choix) {
//                 case 1:
//                     menuDettes();
//                     break;
//                 case 2:
//                     menuClients();
//                     break; 
//                 case 3 :
//                     menuArticles();
//                     break;
//                 case 4 :
//                     menuDemandes();
//                     break; 
//                 case 5 :
//                 System.out.println("Retour au menu principal.");
//                 return; 
//             default:
//                 System.out.println("Option invalide.");
//                 break;
//             }

//         }
//     }

//         public void menuDettes() {
//             while (true) {
//                 System.out.println("Menu Dettes");
//                 System.out.println("1. Ajouter une demande");
//                 System.out.println("2. Liste des dettes");
//                 System.out.println("3. Sélectionner une demande");
//                 System.out.println("4. Quitter");
//                 System.out.print("Entrez votre choix: ");
//                 int choix = scanner.nextInt();
//                 scanner.nextLine();
                
//                 switch (choix) {
//                     case 1 -> {
//                         System.out.println("Ajouter une demande");
//                         System.out.print("Entrer le montant de la demande : ");
//                         double montantDette = scanner.nextDouble();
//                         scanner.nextLine();
//                         System.out.print("Entrer le statut de la demande : ");
//                         String statut = scanner.nextLine();
//                         System.out.print("Entrer le numéro de téléphone du client : ");
//                         String telephone = scanner.nextLine();
                        
//                         Client client = clientService.selectByTelephone(telephone);
//                         if (client == null) {
//                             System.out.println("Aucun client trouvé avec ce numéro.");
//                             break;
//                         }
                        
//                         List<Article> articles = new ArrayList<>();
//                         Dette dette = new Dette(null, montantDette, 0, articles, new ArrayList<>());
//                         Demande demande = new Demande(null, montantDette, statut, client, articles);
//                         client.getDemandes().add(demande);
//                         System.out.println("Demande ajoutée avec succès.");
//                     }
//                     case 2 -> {
//                         System.out.println("Liste des dettes");
//                         List<Client> clients = clientService.findAll();
//                         if (clients.isEmpty()) {
//                             System.out.println("Aucune dette trouvée.");
//                         } else {
//                             clients.forEach(System.out::println);
//                         }
//                     }
//                     case 3 -> {
//                         System.out.println("Sélectionner une demande");
//                         System.out.print("Entrer le numéro de téléphone du client : ");
//                         String telephone = scanner.nextLine();
//                         Client client = clientService.selectByTelephone(telephone);
//                         if (client == null || client.getDemandes().isEmpty()) {
//                             System.out.println("Aucun client ou aucune demande trouvée.");
//                             break;
//                         }
//                         System.out.print("Entrer l'id de la demande : ");
//                         int id = scanner.nextInt();
//                         scanner.nextLine();
                        
//                         Demande demandeTrouveId = client.getDemandes().stream()
//                                 .filter(d -> d.getId() == id)
//                                 .findFirst()
//                                 .orElse(null);
//                         if (demandeTrouveId != null) {
//                             System.out.println("Détails de la demande: " + demandeTrouveId);
//                         } else {
//                             System.out.println("Demande non trouvée.");
//                         }
//                     }
//                     case 4 -> {
//                         System.out.println("Retour au menu principal.");
//                         return; // Quitter le menu dettes
//                     }
//                     default -> System.out.println("Option invalide.");
//                 }
//             }
//         }
        

//     public void menuClients() {

//         while (true) {
//             System.out.println("Menu Client");
//             System.out.println("1. Ajouter un client");
//             System.out.println("2. Liste les clients");
//             System.out.println("3. Rechercher un client par telephone");
//             System.out.println("4. Selectionner un client");
//             System.out.println("5. Quitter");
//             System.out.print("Entrez votre choix: ");
//             int choix = scanner.nextInt();
//             scanner.nextLine(); 

//             switch (choix) {
//                 case 1:
//                     System.out.println("Ajouter un Client");
//                     System.out.println("Entrer le surname du client");
//                     String surname = scanner.nextLine();
//                     System.out.println("Entrer le telephone du client");
//                     String telephone = scanner.nextLine();
//                     System.out.println("Entrer l adresse du client");
//                     String adresse = scanner.nextLine();
//                     List<Demande>demandes = new ArrayList<>();
//                     List<Dette>dettes = new ArrayList<>();
//                     Client client = new Client(surname, telephone, adresse, null, demandes, dettes);
//                     clientService.create(client);
//                     break;
//                 case 2:
//                    System.out.println("Liste des clients");
//                     System.out.println(clientService.findAll());

//                     break;   
//                 case 3:
//                     System.out.println("Entrer le numero telephone");
//                     String searchTelephone = scanner.nextLine();
//                     Client clientTrouve = clientService.selectByTelephone(searchTelephone);
//                     if (clientTrouve != null) {
//                         System.out.println(clientTrouve);
//                     } else {
//                         System.out.println("Il n'y a pas de client associé a ce numero");
//                     }


//                     break; 
                    
                    
//                 case 4 :
//                     System.out.println("Selectionner client par Id ");
//                     System.out.println("Enter l id du client");
//                     int id = scanner.nextInt();
//                     scanner.nextLine();
//                     Client clientTrouveId = clientService.rechercherParId(id);
//                     if (clientTrouveId != null) {
//                         System.out.println(clientTrouveId);
                        
//                     } else {
//                         System.out.println("Il n y a pas de client associé a cet id");
                        
//                     }

//                     break;  
//                 case 5 :
//                     System.out.println("Retour au Menu Principal.");
//                     return; // Quitter le menu client
//                 default:
//                     System.out.println("Option invalide.");
//                 break;  
                  
//             }

//         }

//     }
//     public void menuArticles() {
//         while (true) {
//             System.out.println("Menu Articles");
//             System.out.println("1. Ajouter un article");
//             System.out.println("2. Liste des articles");
//             System.out.println("3. Rechercher un article par id");
//             System.out.println("4. Quitter");
//             System.out.print("Entrez votre choix: ");
//             int choix = scanner.nextInt();
//             scanner.nextLine();
//             switch (choix) {
//                 case 1:
//                     System.out.println("Ajouter un Article");
//                     System.out.println("Entrer le nom du produit");
//                     String nom = scanner.nextLine();
//                     System.out.println("Entrer le prix du produit");
//                     double prix = scanner.nextDouble();
//                     System.out.println("Entrer la quantité en stock du produit");
//                     int qteStock = scanner.nextInt();
//                     System.out.println("Entrer la description du produit");
//                     String etat = scanner.nextLine();
//                     scanner.nextLine();
//                     Article article = new Article(nom, prix, qteStock, etat);
//                     articleService.create(article);
//                     break;
//                 case 2:
//                     System.out.println("Liste des articles");
//                     System.out.println(articleService.findAll());
//                     break;
//                 case 3:
//                     System.out.println("Entrer le id du produit");
//                     int id = scanner.nextInt();
//                     scanner.nextLine();
//                     Article articleTrouve = articleService.rechercherParId(id);
//                     if (articleTrouve!= null) {
//                         System.out.println(articleTrouve);
//                     } else {
//                         System.out.println("Il n y a pas de produit associé a cet id");
//                     }
//                     break;
                    
//                 case 4 :
//                 System.out.println("Retour au Menu Principal.");
//                 return; // Quitter le menu article
//                 default:
//                 System.out.println("Option invalide.");
//                 break;

//             }
//         } 

//     }
//     public void menuDemandes() {
//         while (true) {
//             System.out.println("Menu Demandes");
//             System.out.println("1. Voir les demandes");
//             System.out.println("2. Voir une demande par id");
//             System.out.println("3. Quitter");
//             System.out.print("Entrez votre choix: ");
//             int choix = scanner.nextInt();
//             scanner.nextLine();
            
//             Client client = null; 
            
//             switch (choix) {
//                 case 1:
//                     // Demander le téléphone du client
//                     System.out.print("Entrez le numéro de téléphone du client: ");
//                     String telephone = scanner.nextLine();
                    
//                     client = clientService.selectByTelephone(telephone);
//                     if (client != null) {
//                         System.out.println("Liste des demandes");
//                         if (client.getDemandes() != null && !client.getDemandes().isEmpty()) {
//                             System.out.println(client.getDemandes());
//                         } else {
//                             System.out.println("Aucune demande trouvée pour ce client.");
//                         }
//                     } else {
//                         System.out.println("Aucun client trouvé avec ce numéro.");
//                     }
//                     break;
//                 case 2:
//                     // Demander l'ID du client et de la demande
//                     System.out.print("Entrez l id du client: ");
//                     int clientId = scanner.nextInt();
//                     scanner.nextLine();
                    
//                     client = clientService.rechercherParId(clientId);
//                     if (client != null) {
//                         System.out.println("Entrer l id de la demande");
//                         int id = scanner.nextInt();
//                         scanner.nextLine();
                        
//                         Demande demande = client.getDemandes().stream()
//                             .filter(d -> d.getId() == id)
//                             .findFirst()
//                             .orElse(null);
                        
//                         if (demande != null) {
//                             System.out.println(demande);
//                         } else {
//                             System.out.println("Il n y a pas de demande associée à cet id");
//                         }
//                     } else {
//                         System.out.println("Aucun client trouvé avec cet id.");
//                     }
//                     break;
//                 case 3:
//                     System.out.println("Retour au Menu Principal.");
//                     return; 
//                 default:
//                     System.out.println("Option invalide.");
//                     break;
//             }
//         }
//     }
    
// }
