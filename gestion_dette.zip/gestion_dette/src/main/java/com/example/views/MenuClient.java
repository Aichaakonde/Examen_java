// package com.example.views;

// import com.example.entities.Article;
// import com.example.entities.Client;
// import com.example.entities.Demande;
// import com.example.entities.Dette;
// import com.example.entities.Paiement;

// import java.time.LocalDate;
// import java.util.ArrayList;
// import java.util.List;
// import java.util.Scanner;

// public class MenuClient {
//     private Client client; // Déclaration de la variable client
//     private final Scanner scanner = new Scanner(System.in);

//     // Liste de 10 articles disponibles pour le client, avec quantité en stock
//     private final List<Article> articlesDisponibles = initArticlesDisponibles();

//     // Constructeur
//     public MenuClient(Client client) {
//         this.client = client; 
//     }

    // private List<Article> initArticlesDisponibles() {
    //     return List.of(
    //         new Article("Pain", 150, 30, "Disponible"),
    //         new Article("Lait", 125, 150, "Disponible"),
    //         new Article("Sucre", 700, 50, "Disponible"),
    //         new Article("Farine", 1000, 48, "Disponible"),
    //         new Article("Beurre", 900, 20, "Disponible"),
    //         new Article("Jus", 1000, 90, "Disponible"),
    //         new Article("Chocolat", 1200, 17, "Disponible"),
    //         new Article("Cafe", 50, 250, "Disponible"),
    //         new Article("Cerelac", 350, 100, "Disponible"),
    //         new Article("Pates", 500, 68, "Disponible")
    //     );
    // }
    

//     public void afficherMenuClient() {
//         while (true) {
//             System.out.println("Menu Client");
//             System.out.println("1. Ajouter une demande");
//             System.out.println("2. Lister les demandes");
//             System.out.println("3. Voir les détails d'une demande");
//             System.out.println("4. Lister les dettes");
//             System.out.println("5. Sélectionner une dette");
//             System.out.println("6. Quitter");
//             System.out.print("Entrez votre choix: ");
//             int choix = scanner.nextInt();
//             scanner.nextLine(); 

//             switch (choix) {
//                 case 1 -> {
//                     // Ajouter une demande
//                     System.out.print("Entrez le nombre d'articles à ajouter: ");
//                     int nombreArticles = scanner.nextInt();
//                     scanner.nextLine(); 

//                     List<Article> articles = new ArrayList<>();
//                     double montantTotal = 0;
//                     LocalDate date = LocalDate.now();

//                     for (int i = 0; i < nombreArticles; i++) {
//                         System.out.print("Entrez le libellé de l'article " + (i + 1) + ": ");
//                         String libelle = scanner.nextLine();

//                         Article articleTrouve = articlesDisponibles.stream()
//                                 .filter(article -> article.getNom().equalsIgnoreCase(libelle))
//                                 .findFirst()
//                                 .orElse(null);

//                         if (articleTrouve != null) {
//                             int quantite;
//                             while (true) {
//                                 System.out.print("Entrez la quantité de l'article \"" + libelle + "\": ");
//                                 quantite = scanner.nextInt();
//                                 scanner.nextLine();

//                                 if (quantite <= articleTrouve.getQteStock()) {
//                                     articles.add(articleTrouve); // Ajoutez l'article à la demande
//                                     montantTotal = articleTrouve.getPrix() * quantite;
//                                     System.out.println("Article ajouté: " + articleTrouve.getNom() + " (Quantité: " + quantite + ")");
//                                     break;
//                                 } else {
//                                     System.out.println("Quantité demandée supérieure au stock disponible. Veuillez ressaisir.");
//                                 }
//                             }
//                         } else {
//                             System.out.println("Article \"" + libelle + "\" introuvable dans la liste des articles disponibles.");
//                             i--; // Réduire l'index pour ressaisir cet article
//                         }
//                     }

//                     // Créez une nouvelle demande avec les articles sélectionnés
//                     Demande nouvelleDemande = new Demande(date, montantTotal,  "en_cours", client, articles); 
//                     client.getDemandes().add(nouvelleDemande); 
//                     System.out.println("Demande enregistrée avec succès.");
//                 }
//                 case 2 -> {
//                     // Lister les demandes
//                     System.out.println("Liste des demandes:");
//                     if (client.getDemandes().isEmpty()) {
//                         System.out.println("Aucune demande enregistrée.");
//                     } else {
//                         for (Demande demande : client.getDemandes()) {
//                             System.out.println(demande);
//                         }
//                     }
//                 }
//                 case 3 -> {
//                     // Voir les détails d'une demande
//                     System.out.print("Entrez l'id de la demande: ");
//                     int id = scanner.nextInt();
//                     scanner.nextLine();
//                     Demande demande = client.getDemandes().stream()
//                             .filter(d -> d.getId() == id)
//                             .findFirst()
//                             .orElse(null);
//                     if (demande != null) {
//                         System.out.println("Détails de la demande: " + demande);
//                     } else {
//                         System.out.println("Demande non trouvée.");
//                     }
//                 }
//                 case 4 -> {
//                     // Lister les dettes
//                     System.out.println("Liste des dettes:");
//                     if (client.getDettes().isEmpty()) {
//                         System.out.println("Aucune dette enregistrée.");
//                     } else {
//                         for (Dette dette : client.getDettes()) {
//                             System.out.println(dette);
//                         }
//                     }
//                 }
//                 case 5 -> {
//                     // Sélectionner une dette
//                     System.out.print("Entrez l'id de la dette: ");
//                     int id = scanner.nextInt();
//                     scanner.nextLine();
//                     Dette dette = client.getDettes().stream()
//                             .filter(d -> d.getId() == id)
//                             .findFirst()
//                             .orElse(null);
//                     if (dette != null) {
//                         System.out.println("Détails de la dette: " + dette);
//                         System.out.println("Articles associés :");
//                         for (Article article : dette.getArticles()) {
//                             System.out.println(article);
//                         }
//                         System.out.println("Paiements associés :");
//                         for (Paiement paiement : dette.getPaiements()) {
//                             System.out.println(paiement);
//                         }
//                     } else {
//                         System.out.println("Il n’y a pas de dettes associées à cet id.");
//                     }
//                 }
//                 case 6 -> {
//                     // Quitter
//                     System.out.println("Retour au menu principal.");
//                     return; // Quitter le menu client
//                 }
//                 default -> System.out.println("Option invalide.");
//             }
//         }
//     }
// }




























