// package com.example.views;


// import java.util.Scanner;

// import com.example.entities.Admin;
// import com.example.entities.Boutiquier;
// import com.example.entities.Client;
// import com.example.services.IArticleService;
// import com.example.services.IClientService;
// import com.example.services.IUserService;


// public class MenuPrincipal {
//     private Scanner scanner = new Scanner(System.in);

//     public void afficherMenuPrincipal(Client client, Boutiquier boutiquier,Admin admin, IArticleService articleService, IClientService clientService, IUserService userService) {
//         while (true) {
//             System.out.println("\nMenu Principal");
//             System.out.println("1. Client");
//             System.out.println("2. Boutiquier");
//             System.out.println("3. Admin");
//             System.out.println("4. Quitter");
//             System.out.print("Entrez votre choix : ");
//             int choix = scanner.nextInt();
//             scanner.nextLine(); // Consomme la nouvelle ligne

//             switch (choix) {
//                 case 1:
//                     MenuClient menuClient = new MenuClient(client);
//                     menuClient.afficherMenuClient();
//                     break;
//                 case 2:
//                     MenuBoutiquier menuBoutiquier = new MenuBoutiquier(boutiquier, articleService, clientService);
//                     menuBoutiquier.afficherMenuBoutiquier();
//                     break;
//                 case 3:
//                     MenuAdmin menuAdmin = new MenuAdmin(admin, articleService, clientService, userService);
//                     menuAdmin.afficherMenuAdmin();
//                     break;
//                 case 4:
//                     System.out.println("Au revoir!");
//                     return;
//                 default:
//                     System.out.println("Choix invalide");
//             }
//         }
//     }

    

    
// }






