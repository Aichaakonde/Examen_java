package com.example.entities;

import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Paiement {
    private int id;
    private LocalDate date;
    private double montant;
    private static int compteurId = 1;

    // Constructeur corrigé
    public Paiement(LocalDate date, double montant) {
        this.id = compteurId++;
        this.date = date;
        this.montant = montant;
    }
}
