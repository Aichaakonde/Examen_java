package com.example.entities;

import lombok.AllArgsConstructor;
import lombok.Data;


@Data
@AllArgsConstructor
public class DetailsDemande {
    private int id;
    private int quantite;
    private Article article;
    private Demande demande;

    private static int compteurId=1;

    public DetailsDemande() {
        this.id = compteurId++;
    }


    public DetailsDemande( int quantite, Article article, Demande demande) {
        this.id = compteurId++;
        this.quantite = quantite;
        this.article = article;
        this.demande = demande;
    }


    @Override
    public String toString() {
        return "DetailsDemande [id=" + id + ", quantite=" + quantite + ", article=" + article.getNom() + ", demande=" + demande.getId()
                + "]";
    }    
}
