package com.example.entities;

import com.example.core.IHasUser;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@AllArgsConstructor

public class Admin implements IHasUser{
    private int id;
    private String noms;
    private String prenoms;
    private String telephone;
    private User user;
    private static int compteurId=1;



    public Admin( String noms, String prenoms, String telephone, User user) {
        this.id =compteurId++;
        this.noms = noms;
        this.prenoms = prenoms;
        this.telephone = telephone;
        this.user = user;
    }
    @Override
    public void setUser( User user){
        this.user = user;
    }

    @Override
    public User getUser(){
        return user;
    }



    @Override
    public String toString() {
        return "Admin [id=" + id + ", noms=" + noms + ", prenoms=" + prenoms + ", telephone=" + telephone + ", userID=" + (user!=null ? user.getId() : "null")+ "]";
    }

    
    

    
}
