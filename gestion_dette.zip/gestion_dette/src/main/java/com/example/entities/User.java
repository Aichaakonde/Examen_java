package com.example.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class User {
    private static int compteurId = 1;  // Compteur statique pour générer des ID uniques
    private int id;
    private String login;
    private String password;
    private String role;  // ADMIN, BOUTIQUIER, CLIENT
    private boolean isActive;

    // Constructeur avec les paramètres appropriés
    public User(String login, String password, String role, boolean isActive) {
        this.id = compteurId++;  // ID auto-incrémenté
        this.login = login;
        this.password = password;
        this.role = role;
        this.isActive = isActive;
    }
    

}
