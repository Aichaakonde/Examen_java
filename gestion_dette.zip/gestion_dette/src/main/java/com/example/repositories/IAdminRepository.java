package com.example.repositories;

import com.example.core.IRepository;
import com.example.entities.Admin;

public interface IAdminRepository  extends IRepository<Admin>{

    Admin selectByLogin(String login);
    
}
 