package com.example.repositories;

import com.example.core.IRepository;
import com.example.entities.DetailsDemande;

public interface IDetailsDemandeRepository  extends IRepository <DetailsDemande>{

    
    
}
