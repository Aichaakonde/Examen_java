package com.example.repositories.impl;

import java.util.ArrayList;
import java.util.List;

import com.example.entities.Client;
import com.example.repositories.IClientRepository;

public class ClientRepositoryImpl implements IClientRepository{
    private List<Client> clients = new ArrayList<>();

    @Override
    public Client add(Client client){
        clients.add(client);
        return client;        
    }
    @Override
    public List<Client> selectAll(){
        return clients;
        
    }
    @Override
    public Client findById(int id){
         Client clientTrouve = clients.stream()
        .filter(client -> client.getId() == id)
        .findFirst()
        .orElse(null);

        return clientTrouve;
    }
    

    @Override
    public Client selectByTelephone(String telephone) {

        Client clientTrouve = clients.stream()
                    .filter(client -> client.getTelephone().equalsIgnoreCase(telephone))
                    .findFirst()
                    .orElse(null);
        
        return clientTrouve;
    }
    
    @Override
    public Client selectByLogin(String login) {
        for (Client client : clients) {
            if (client.getUser().getLogin().equals(login)) {
                return client;
            }
        }
        return null;
    }

    @Override
    public Client create(Client client){
        ((IClientRepository) clients).create(client);
        return client;

    }

    @Override
    public void update(Client client) {
        for (int i = 0; i < clients.size(); i++) {
            if (clients.get(i).getId() == client.getId()) {
                clients.set(i, client);
                return;
            }
        }

        

    }
    @Override
    public void delete(Client client) {
        clients.remove(client);

    }
    @Override
    public void deleteById(int id) {
        for (int i = 0; i < clients.size(); i++) {
            if (clients.get(i).getId() == id) {
                clients.remove(i);
                return;
            }
    
        }
    }
   
       
    

      
}


