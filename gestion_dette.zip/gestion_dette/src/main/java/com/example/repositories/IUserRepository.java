package com.example.repositories;

import com.example.core.IRepository;
import com.example.entities.User;



public interface IUserRepository extends IRepository <User>{
     User selectByLogin(String login);
    
}
