package com.example.repositories;

import com.example.core.IRepository;
import com.example.entities.Client;

public interface IClientRepository extends IRepository <Client>{

    Client selectByTelephone(String telephone);

    Client selectByLogin(String login);

    Object create(Client client);

} 