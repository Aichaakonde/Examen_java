package com.example.repositories;

import java.util.List;

import com.example.core.IRepository;
import com.example.entities.Client;
import com.example.entities.Dette;

public interface IDetteRepository extends IRepository<Dette>{
    List<Dette> findByStatut(String statut);
    List<Dette> findByClient(Client client);
    List<Dette> findByClientAndStatut(Client client, String statut);
    
    
}
