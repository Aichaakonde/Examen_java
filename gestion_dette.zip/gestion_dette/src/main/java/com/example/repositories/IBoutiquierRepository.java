package com.example.repositories;

import com.example.core.IRepository;
import com.example.entities.Boutiquier;

public interface IBoutiquierRepository extends IRepository <Boutiquier>{

    Boutiquier selectByLogin(String login);
    
}
