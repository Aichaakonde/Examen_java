package com.example.repositories.impl;

import java.util.ArrayList;
import java.util.List;

import com.example.entities.Admin;
import com.example.repositories.IAdminRepository;

public class AdminRepositoryImpl implements IAdminRepository{
     private List<Admin> admins = new ArrayList<>();  

    @Override
    public Admin add(Admin admin) {
        admins.add(admin);
        return admin;        
    }

    @Override
    public List<Admin> selectAll() {
        return admins; 
    }
    @Override
    public Admin findById(int id){
        Admin adminTrouve = admins.stream()
       .filter(admin -> admin.getId() == id)
       .findFirst()
       .orElse(null);

       return adminTrouve;
   }
   
    @Override
    public Admin selectByLogin(String login) {
        for (Admin admin : admins) {
            if (admin.getUser().getLogin().equals(login)) {
                return admin;
            }
        }
        return null;
    }

    @Override
    public void update(Admin admin) {
        for (int i = 0; i < admins.size(); i++) {
            if (admins.get(i).getId() == admin.getId()) {
                admins.set(i, admin);
                break;
            }
        }
    }

    @Override
    public void delete(Admin entity) {
        admins.remove(entity);
 
   }

    @Override
    public void deleteById(int id) {
        for (int i = 0; i < admins.size(); i++) {
            if (admins.get(i).getId() == id) {
                admins.remove(i);
                break;
            }
        }
    }

   


}


    

