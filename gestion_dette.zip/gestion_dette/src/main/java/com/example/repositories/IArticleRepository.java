package com.example.repositories;

import com.example.core.IRepository;
import com.example.entities.Article;

public interface IArticleRepository extends IRepository <Article>{

    Article findByLibelle(String libelle);
}
