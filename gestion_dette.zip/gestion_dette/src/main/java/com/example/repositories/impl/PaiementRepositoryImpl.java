package com.example.repositories.impl;

import java.util.ArrayList;
import java.util.List;

import com.example.entities.Paiement;
import com.example.repositories.IPaiementRepository;

public class PaiementRepositoryImpl  implements IPaiementRepository{
    private List<Paiement> paiements = new ArrayList<>();

    @Override
    public Paiement add(Paiement paiement) {
        paiements.add(paiement);
        return paiement;        
    }

    @Override
    public List<Paiement> selectAll() {
      return paiements;
    }

    @Override
    public Paiement findById(int id) {
        Paiement paiementTrouve = paiements.stream()
        .filter(paiement -> paiement.getId() == id)
        .findFirst()
        .orElse(null);

        return paiementTrouve;
    }

    @Override
    public void update(Paiement paiement) {

        int index = paiements.indexOf(paiement);
        if(index!= -1) {
            paiements.set(index, paiement);
        }
        else {
            throw new IllegalArgumentException("Paiement not found");
        }

    }

    @Override
    public void delete(Paiement paiement) {
        paiements.remove(paiement);
    }

    @Override
    public void deleteById(int id) {
        Paiement paiementToDelete = findById(id);
        if(paiementToDelete!= null) {
            delete(paiementToDelete);
        }
        else {
            throw new IllegalArgumentException("Paiement not found");
        }
    }

   

   
}
