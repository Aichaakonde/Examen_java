package com.example.repositories.impl;

import java.util.ArrayList;
import java.util.List;

import com.example.entities.DetailsDemande;
import com.example.repositories.IDetailsDemandeRepository;

public class DetailsDemandeRepositoryImpl implements IDetailsDemandeRepository{
    List<DetailsDemande>  detailsDemandes = new ArrayList<>();

    @Override
    public DetailsDemande add(DetailsDemande detailsDemande) {
        detailsDemandes.add(detailsDemande);
        return detailsDemande;
        
    }

    @Override
    public List<DetailsDemande> selectAll() {
        return detailsDemandes;
       
    }

    @Override
    public DetailsDemande findById(int id) {
      DetailsDemande detailsDemandeTrouve = detailsDemandes.stream()
      .filter(detailsDemande -> detailsDemande.getId() == id)
      .findFirst()
      .orElse(null);

      return detailsDemandeTrouve;
    }

    @Override
    public void update(DetailsDemande detailsDemande) {
        detailsDemandes.removeIf(d -> d.getId() == detailsDemande.getId());
        detailsDemandes.add(detailsDemande);
    }

    @Override
    public void delete(DetailsDemande detailsDemande) {
       detailsDemandes.remove(detailsDemande);
    }

    @Override
    public void deleteById(int id) {
       detailsDemandes.removeIf(d -> d.getId() == id);
    }

     
}
