package com.example.repositories.impl;

import java.util.ArrayList;
import java.util.List;

import com.example.entities.User;
import com.example.repositories.IUserRepository;


public class UserRepositoryImpl implements IUserRepository {
    private List<User> users = new ArrayList<>();  

    @Override
    public User add(User user) {
        users.add(user);
        return user;        
    }

    @Override
    public List<User> selectAll() {
        return users; 
    }
    @Override
    public User findById(int id){
        User userTrouve = users.stream()
       .filter(user -> user.getId() == id)
       .findFirst()
       .orElse(null);

       return userTrouve;
   }
   
    @Override   
    public User selectByLogin(String login) {
        for (User user : users) {
            if (user.getLogin().equals(login)) {
                return user;
            }
        }
        return null;
    }

    @Override
    public void update(User user) {
        for (int i = 0; i < users.size(); i++) {
            if (users.get(i).getId() == user.getId()) {
                users.set(i, user);
                return;
            }
        }

    }

    @Override
    public void delete(User user) {
        users.remove(user);
    }

    @Override
    public void deleteById(int id) {
        for (int i = 0; i < users.size(); i++) {
            if (users.get(i).getId() == id) {
                users.remove(i);
                return;
            }
        }
    }

   

   }
