package com.example.repositories.impl;

import java.util.ArrayList;
import java.util.List;

import com.example.entities.DetailsDetteArticle;
import com.example.repositories.IDetailsDetteArticleRepository;

public class DetailsDetteArticleRepositoryImpl implements IDetailsDetteArticleRepository {
    private List<DetailsDetteArticle> detailsDetteArticles=new ArrayList<>();

    @Override
    public DetailsDetteArticle add(DetailsDetteArticle detailsDetteArticle) {
        detailsDetteArticles.add(detailsDetteArticle);
        return detailsDetteArticle;
    }

    @Override
    public List<DetailsDetteArticle> selectAll() {

       return detailsDetteArticles;
    }

    @Override
    public DetailsDetteArticle findById(int id) {
        DetailsDetteArticle detailsDetteArticleTrouve = detailsDetteArticles.stream()
         .filter(detailsDetteArticle -> detailsDetteArticle.getId() == id)
         .findFirst()
         .orElse(null);

         return detailsDetteArticleTrouve;
    }

    @Override
    public void update(DetailsDetteArticle detailsDetteArticle) {
       
        for(int i = 0; i < detailsDetteArticles.size(); i++){
            if(detailsDetteArticles.get(i).getId() == detailsDetteArticle.getId()){
                detailsDetteArticles.set(i, detailsDetteArticle);
                break;
            }   
        }
    }

    @Override
    public void delete(DetailsDetteArticle detailsDetteArticle) {
       detailsDetteArticles.remove(detailsDetteArticle);
    }

    @Override
    public void deleteById(int id) {
        DetailsDetteArticle detailsDetteArticleSupprimer = findById(id);
        if(detailsDetteArticleSupprimer!= null){
            detailsDetteArticles.remove(detailsDetteArticleSupprimer);
        }
    }

    

    
}
