
package com.example.repositories.impl;

import java.util.ArrayList;
import java.util.List;

import com.example.entities.Client;
import com.example.entities.Demande;
import com.example.repositories.IDemandeRepository;

public class DemandeRepositoryImpl implements IDemandeRepository {
    private List<Demande> demandes = new ArrayList<>();

    @Override
    public Demande add(Demande demande) {
        demandes.add(demande);
        return demande;        
    }

    @Override
    public List<Demande> selectAll() {
        return demandes;        
    }
    @Override
    public Demande findById(int id){
        Demande demandeTrouve = demandes.stream()
       .filter(demande -> demande.getId() == id)
       .findFirst()
       .orElse(null);

       return demandeTrouve;
   }

    @Override
    public void update(Demande demande) {

        demandes.removeIf(d -> d.getId() == demande.getId());
        demandes.add(demande);

    }

    @Override
    public void delete(Demande demande) {
        demandes.remove(demande);
    }

    @Override
    public void deleteById(int id) {
        demandes.removeIf(d -> d.getId() == id);
    }

    @Override
    public List<Demande> findByEtat(String etat) {
        List<Demande> demandesByEtat = new ArrayList<>();

        for (Demande demande : demandes) {
            if (demande.getStatut().equalsIgnoreCase(etat)) {
                demandesByEtat.add(demande);
            }
        } 
        return demandesByEtat; 
    }

    @Override
    public List<Demande> findByClient(Client client) {
        List<Demande> demandesByClient = new ArrayList<>();
        for (Demande demande : demandes) {
            if (demande.getClient().equals(client)) {
                demandesByClient.add(demande);
            }
        }
        return demandesByClient;
    }

    @Override
    public List<Demande> findByClientandEtat(Client client, String etat) {
        List<Demande> demandesByClientEtat = new ArrayList<>();
        for (Demande demande : demandes) {
            if (demande.getClient().equals(client) && demande.getStatut().equalsIgnoreCase(etat)) {
                demandesByClientEtat.add(demande);
            }
        }
        return demandesByClientEtat;  
    }
   

    
    

}
