package com.example.repositories;

import com.example.core.IRepository;
import com.example.entities.DetailsDetteArticle;

public interface IDetailsDetteArticleRepository extends IRepository<DetailsDetteArticle> {

    
}
