package com.example.repositories.impl;

import java.util.ArrayList;
import java.util.List;

import com.example.entities.Client;
import com.example.entities.Dette;
import com.example.repositories.IDetteRepository;

public class DetteRepositoryImpl implements IDetteRepository {
    
    private List<Dette> dettes = new ArrayList<>();

    @Override
    public Dette add(Dette dette){
        dettes.add(dette);
        return dette;        
    }
    @Override
    public List<Dette> selectAll(){
        return dettes;
        
    }
    @Override
    public Dette findById(int id){
         Dette detteTrouve = dettes.stream()
        .filter(dette -> dette.getId() == id)
        .findFirst()
        .orElse(null);

        return detteTrouve;
    }
    @Override
    public void update(Dette dette) {

        for(int i=0; i<dettes.size(); i++) {
            if(dettes.get(i).getId() == dette.getId()) {
                dettes.set(i, dette);
                break;
            }
        }
    }
    @Override
    public void delete(Dette dette) {
        dettes.remove(dette);
    }
    @Override
    public void deleteById(int id) {
        Dette detteASupprimer = findById(id);
        if(detteASupprimer!= null) {
            dettes.remove(detteASupprimer);
        }
    }
    @Override
    public List<Dette> findByStatut(String statut) {
       List<Dette> dettesByStatut = new ArrayList<>();

        for (Dette dette : dettes) {
            if (dette.getStatut().equalsIgnoreCase(statut)) {
                dettesByStatut.add(dette);
            }
        } 
        return dettesByStatut; 
    }
    @Override
    public List<Dette> findByClient(Client client) {
        List<Dette> dettesByClient = new ArrayList<>();
        for (Dette dette : dettes) {
            if (dette.getClient().getId() == client.getId()) {
                dettesByClient.add(dette);
            }
        }
        return dettesByClient;
    }
    @Override
    public List<Dette> findByClientAndStatut(Client client, String statut) {
        List<Dette> dettesByClientAndStatut = new ArrayList<>();
        for (Dette dette : dettes) {
            if (dette.getClient().getId() == client.getId() && dette.getStatut().equalsIgnoreCase(statut)) {
                dettesByClientAndStatut.add(dette);
            }
        }
        return dettesByClientAndStatut;
        
    }
}
   
    

    

    
      





