package com.example.repositories.impl;

import java.util.ArrayList;
import java.util.List;

import com.example.entities.Boutiquier;
import com.example.repositories.IBoutiquierRepository;

public class BoutiquierRepositoryImpl implements IBoutiquierRepository {
    private List<Boutiquier> boutiquiers = new ArrayList<>();  

    @Override
    public Boutiquier add(Boutiquier boutiquier) {
        boutiquiers.add(boutiquier);
        return boutiquier;        
    }

    @Override
    public List<Boutiquier> selectAll() {
        return boutiquiers; 
    }
    @Override
    public Boutiquier findById(int id){
        Boutiquier boutiquierTrouve = boutiquiers.stream()
       .filter(boutiquier -> boutiquier.getId() == id)
       .findFirst()
       .orElse(null);

       return boutiquierTrouve;
   }
   
    @Override
    public Boutiquier selectByLogin(String login) {
        for (Boutiquier boutiquier : boutiquiers) {
            if (boutiquier.getUser().getLogin().equals(login)) {
                return boutiquier;
            }
        }
        return null;
    }

    @Override
    public void update(Boutiquier entity) {

        for (int i = 0; i < boutiquiers.size(); i++) {
            if (boutiquiers.get(i).getId() == entity.getId()) {
                boutiquiers.set(i, entity);
                break;
            }
        }
    }

    @Override
    public void delete(Boutiquier entity) {
        boutiquiers.remove(entity);
    }

    @Override
    public void deleteById(int id) {
        for (Boutiquier boutiquier : boutiquiers) {
            if (boutiquier.getId() == id) {
                boutiquiers.remove(boutiquier);
                break;
            }
        }
    }

   
   

}

