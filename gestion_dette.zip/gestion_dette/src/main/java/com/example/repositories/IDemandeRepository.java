package com.example.repositories;

import java.util.List;

import com.example.core.IRepository;
import com.example.entities.Client;
import com.example.entities.Demande;

public interface IDemandeRepository extends IRepository<Demande>{
    List<Demande> findByEtat(String etat);
    List<Demande> findByClient(Client client);
    List<Demande> findByClientandEtat(Client client, String etat);
  
    
}
