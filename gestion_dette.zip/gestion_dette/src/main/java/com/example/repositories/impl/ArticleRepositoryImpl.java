package com.example.repositories.impl;

import java.util.ArrayList;
import java.util.List;

import com.example.entities.Article;
import com.example.repositories.IArticleRepository;

public class ArticleRepositoryImpl implements IArticleRepository {
    private List<Article> articles = new ArrayList<>();

    @Override
    public Article add(Article article){
        articles.add(article);
        return article;        
    }

    @Override
    public List<Article> selectAll(){
        return articles;
        
    }
    @Override
    public Article findById(int id){
        Article articleTrouve = articles.stream()
        .filter(article -> article.getId() == id)
        .findFirst()
        .orElse(null);

        return articleTrouve;

    }

    @Override
    public void update(Article article) {

        int index = articles.indexOf(article);
        if(index!= -1){
            articles.set(index, article);
        }
        else{
            throw new IllegalArgumentException("Article not found");
        }
    }

    @Override
    public void delete(Article article) {
        articles.remove(article);
    }

    @Override
    public void deleteById(int id) {
        Article articleToDelete = findById(id);
        if(articleToDelete!= null){
            delete(articleToDelete);
        }
        else{
            throw new IllegalArgumentException("Article not found");
        }
    }

    @Override
    public Article findByLibelle(String libelle) {
        Article articleTrouve = articles.stream()
       .filter(article -> article.getNom().equalsIgnoreCase(libelle))
       .findFirst()
       .orElse(null);

       return articleTrouve;

       
    }

    
    
}
