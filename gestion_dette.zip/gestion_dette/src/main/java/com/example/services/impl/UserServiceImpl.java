package com.example.services.impl;

import java.util.List;

import com.example.core.IHasUser;
import com.example.entities.User;
import com.example.repositories.IUserRepository;
import com.example.services.IUserService;

public class UserServiceImpl implements IUserService{
    private final IUserRepository userRepository;

    public UserServiceImpl(IUserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public User add(User user) {
        return userRepository.add(user);
    }

    @Override
    public List<User> selectAll() {
        return userRepository.selectAll();
    }

    @Override
    public User findById(int id) {
        return userRepository.findById(id);
    }

    @Override
    public void update(User user) {
        userRepository.update(user);
    }

    @Override
    public void delete(User user) {
        userRepository.delete(user);
    }

    @Override
    public void deleteById(int id) {
        userRepository.deleteById(id);
    }


    @Override
    public <T extends IHasUser> T associerUser(T entity, User user) {
       if (entity != null) {
         entity.setUser(user);
         user.setActive(true);

         userRepository.update(user);
         return entity;
        
       }else {
        System.out.println("Entite ou Utilisateur introuvable.");
        return null;
        }
    }   

    
}
