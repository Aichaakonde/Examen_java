package com.example.services.impl;

import java.util.List;

import com.example.entities.Paiement;
import com.example.repositories.IPaiementRepository;
import com.example.services.IPaiementService;

public class PaiementServiceImpl implements IPaiementService{

private  final IPaiementRepository paiementRepository;
public PaiementServiceImpl(IPaiementRepository paiementRepository) {
        this.paiementRepository = paiementRepository;
    }
    @Override
    public Paiement add(Paiement paiement) {
        return paiementRepository.add(paiement);
    }

    @Override
    public List<Paiement> selectAll() {
        return paiementRepository.selectAll();
    }

    @Override
    public Paiement findById(int id) {
        return paiementRepository.findById(id);
    }
    @Override
    public void update(Paiement paiement) {
        paiementRepository.update(paiement); 
    }
    @Override
    public void delete(Paiement paiement) {
        paiementRepository.delete(paiement);
    }
    @Override
    public void deleteById(int id) {
        paiementRepository.deleteById(id);
    }
   

   
    
}
