package com.example.services.impl;

import java.util.List;

import com.example.entities.Article;
import com.example.repositories.IArticleRepository;
import com.example.services.IArticleService;

public class ArticleServiceImpl implements IArticleService{
    private final IArticleRepository articleRepository;
      public ArticleServiceImpl(IArticleRepository articleRepository) {
        this.articleRepository = articleRepository;
    }
    @Override
    public Article add(Article article) {
        return articleRepository.add(article);
    }
    @Override
    public List<Article> selectAll() {
        return articleRepository.selectAll();
    }
    @Override
    public Article findById(int id) {
        return articleRepository.findById(id);
    }
    @Override
    public void update(Article article) {
        articleRepository.update(article);
    }
    @Override
    public void delete(Article article) {
        articleRepository.delete(article);
    }
    @Override
    public void deleteById(int id) {
        articleRepository.deleteById(id);
    }
    @Override
    public Article findByLibelle(String libelle) {
       return articleRepository.findByLibelle(libelle);
    }
   
   



}
