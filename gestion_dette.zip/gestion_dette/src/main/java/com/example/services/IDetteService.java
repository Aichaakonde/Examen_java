package com.example.services;

import java.util.List;

import com.example.core.IService;
import com.example.entities.Client;
import com.example.entities.Dette;

public interface IDetteService extends IService<Dette> {

    void delete(Dette dette);
     List<Dette> findByStatut(String statut);
     List<Dette> findByClient(Client client);
    void enregistrerPaiement(Dette detteTrouvee, double montantPaiement);
    List<Dette> findByClientAndStatut(Client client, String statut);
    
}
