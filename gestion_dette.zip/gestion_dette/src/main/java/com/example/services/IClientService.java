package com.example.services;


import com.example.core.IAccount;
import com.example.core.IService;
import com.example.entities.Client;

public interface IClientService extends IAccount <Client>, IService<Client> {

    Client selectByTelephone(String telephone);

    Client selectByLogin(String email);

}
