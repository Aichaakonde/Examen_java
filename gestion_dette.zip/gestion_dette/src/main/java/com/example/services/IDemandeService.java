package com.example.services;

import java.util.List;

import com.example.core.IService;
import com.example.entities.Client;
import com.example.entities.Demande;

public interface IDemandeService extends IService <Demande>{

    void delete(Demande demande);
     List<Demande> findByEtat(String etat);
     List<Demande> findByClient(Client client);
     List<Demande> findByClientAndEtat(Client client, String etat);
    
    
}
