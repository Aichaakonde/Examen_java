package com.example.services.impl;

import java.util.List;

import com.example.entities.Client;
import com.example.entities.Demande;
import com.example.repositories.IDemandeRepository;
import com.example.services.IDemandeService;

public class DemandeServiceImpl implements IDemandeService {
    private final IDemandeRepository demandeRepository;
    public DemandeServiceImpl(IDemandeRepository demandeRepository) {
        this.demandeRepository = demandeRepository;
    }

    @Override
    public Demande add(Demande demande) {
        return demandeRepository.add(demande);
    }

    @Override
    public List<Demande> selectAll() {
        return demandeRepository.selectAll();
    }

    @Override
    public Demande findById(int id) {
        return demandeRepository.findById(id);
    }

    @Override
    public void update(Demande demande) {
        demandeRepository.update(demande); 
    }

    @Override
    public void delete(Demande demande) {
        demandeRepository.delete(demande);
    }

    @Override
    public void deleteById(int id) {
        demandeRepository.deleteById(id);
    }

    @Override
    public List<Demande> findByEtat(String etat){
        return demandeRepository.findByEtat(etat);

    }

    @Override
    public List<Demande> findByClient(Client client) {
        return demandeRepository.findByClient(client);
    }

    @Override
    public List<Demande> findByClientAndEtat(Client client, String etat) {
        return demandeRepository.findByClientandEtat(client, etat); 
    }

    

    
    
    
}
