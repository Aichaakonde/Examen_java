package com.example.services.impl;

import java.util.List;

import com.example.entities.Client;
import com.example.entities.Dette;
import com.example.repositories.IDetteRepository;
import com.example.services.IDetteService;

public class DetteServiceImpl  implements IDetteService{

    private final IDetteRepository detteRepository;
    public DetteServiceImpl(IDetteRepository detteRepository) {
        this.detteRepository = detteRepository;
    }


    @Override
    public Dette add(Dette dette) {
        return detteRepository.add(dette);
    }

    @Override
    public List<Dette> selectAll() {
        return detteRepository.selectAll();
    }

    @Override
    public Dette findById(int id) {
        return detteRepository.findById(id);
    }

    @Override
    public void update(Dette dette) {
        detteRepository.update(dette); 
    }

    @Override
    public void delete(Dette dette) {
        detteRepository.delete(dette);
    }

    @Override
    public void deleteById(int id) {
        detteRepository.deleteById(id);
    }

    @Override
    public List<Dette> findByStatut(String statut) {
       return detteRepository.findByStatut(statut);   
    }

    @Override
    public List<Dette> findByClient(Client client) {
        return detteRepository.findByClient(client);
     
    }

    @Override
    public void enregistrerPaiement(Dette dette, double montant) {
    dette.setMontant(dette.getMontant() - montant);
    

//     Paiement paiement = new Paiement(dette.getPaiements().size() + 1, montant);
//     dette.getPaiements().add(paiement);
}


    @Override
    public List<Dette> findByClientAndStatut(Client client, String statut) {
        return detteRepository.findByClientAndStatut(client, statut);
    }

   
}