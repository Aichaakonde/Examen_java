package com.example.services;

import com.example.core.IAccount;
import com.example.core.IService;
import com.example.entities.Admin;

public interface IAdminService extends IAccount<Admin>, IService<Admin> {

}
