package com.example.services;

import com.example.core.IService;
import com.example.entities.Article;

public interface IArticleService extends IService <Article>{

    Article findByLibelle(String libelle);
    
}
