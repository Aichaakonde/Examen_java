package com.example.services;

import com.example.core.IService;
import com.example.entities.Paiement;

public interface IPaiementService extends IService<Paiement> {

    // void delete(Paiement paiement);
    
}
