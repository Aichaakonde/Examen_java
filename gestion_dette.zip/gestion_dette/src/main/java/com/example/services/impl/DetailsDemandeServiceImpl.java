package com.example.services.impl;

import java.util.List;

import com.example.entities.DetailsDemande;
import com.example.repositories.IDetailsDemandeRepository;
import com.example.services.IDetailsDemandeService;

public class DetailsDemandeServiceImpl implements IDetailsDemandeService {
    private final IDetailsDemandeRepository detailsDemandeRepository;
    
    public DetailsDemandeServiceImpl(IDetailsDemandeRepository detailsDemandeRepository) {
        this.detailsDemandeRepository = detailsDemandeRepository;
    }

    @Override
    public DetailsDemande add(DetailsDemande detailsDemande) {
        return detailsDemandeRepository.add(detailsDemande);  
    }

    @Override
    public List<DetailsDemande> selectAll() {
       return detailsDemandeRepository.selectAll();
    }

    @Override
    public DetailsDemande findById(int id) {
        return detailsDemandeRepository.findById(id);
    }

    @Override
    public void update(DetailsDemande detailsDemande) {
       detailsDemandeRepository.update(detailsDemande);
        }

    @Override
    public void delete(DetailsDemande detailsDemande) {
       detailsDemandeRepository.delete(detailsDemande);
    }

    @Override
    public void deleteById(int id) {
       detailsDemandeRepository.deleteById(id);
    }
    
}
