package com.example.services.impl;

import java.util.List;

import com.example.entities.Admin;
import com.example.repositories.IAdminRepository;
import com.example.services.IAdminService;

public class AdminServiceImpl implements IAdminService{
    private final IAdminRepository adminRepository;

     public AdminServiceImpl(IAdminRepository adminRepository) {
        this.adminRepository = adminRepository;
    }

    @Override
    public Admin selectByLogin(String login) {
       return adminRepository.selectByLogin(login);
    }

    @Override
    public Admin add(Admin entity) {
        return adminRepository.add(entity);
    }

    @Override
    public List<Admin> selectAll() {
        return adminRepository.selectAll();
    }

    @Override
    public Admin findById(int id) {
        return adminRepository.findById(id);
    }

    @Override
    public void update(Admin entity) {
        adminRepository.update(entity);
    }

    @Override
    public void delete(Admin entity) {
        adminRepository.delete(entity);
    }

    @Override
    public void deleteById(int id) {
        adminRepository.deleteById(id);
    }
   


}
    



