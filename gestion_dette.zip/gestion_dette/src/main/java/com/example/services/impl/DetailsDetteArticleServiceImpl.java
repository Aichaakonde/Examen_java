package com.example.services.impl;

import java.util.List;

import com.example.entities.DetailsDetteArticle;
import com.example.repositories.IDetailsDetteArticleRepository;
import com.example.services.IDetailsDetteArticleService;

public class DetailsDetteArticleServiceImpl  implements IDetailsDetteArticleService{

    private final IDetailsDetteArticleRepository detailsDetteArticleRepository;
    public DetailsDetteArticleServiceImpl(IDetailsDetteArticleRepository detailsDetteArticleRepository) {
        this.detailsDetteArticleRepository= detailsDetteArticleRepository;
    }
    @Override
    public DetailsDetteArticle add(DetailsDetteArticle detailsDetteArticle) {
        return detailsDetteArticleRepository.add(detailsDetteArticle);
        
    }

    @Override
    public List<DetailsDetteArticle> selectAll() {
     return detailsDetteArticleRepository.selectAll();
    }

    @Override
    public DetailsDetteArticle findById(int id) {
        return detailsDetteArticleRepository.findById(id);
    }

    @Override
    public void update(DetailsDetteArticle detailsDetteArticle) {
       detailsDetteArticleRepository.update(detailsDetteArticle);
    }

    @Override
    public void delete(DetailsDetteArticle detailsDetteArticle) {
        detailsDetteArticleRepository.delete(detailsDetteArticle);
       
    }

    @Override
    public void deleteById(int id) {
        detailsDetteArticleRepository.deleteById(id);
    }
    
}
