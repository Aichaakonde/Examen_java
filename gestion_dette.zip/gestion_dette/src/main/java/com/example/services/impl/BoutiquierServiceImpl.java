package com.example.services.impl;

import java.util.List;

import com.example.entities.Boutiquier;
import com.example.repositories.IBoutiquierRepository;
import com.example.services.IBoutiquierService;


public class BoutiquierServiceImpl implements IBoutiquierService{
    private final IBoutiquierRepository boutiquierRepository;
    public BoutiquierServiceImpl(IBoutiquierRepository boutiquierRepository) {
        this.boutiquierRepository = boutiquierRepository;
    }
    @Override
    public Boutiquier add(Boutiquier boutiquier) {
        return boutiquierRepository.add(boutiquier); //
    }
    @Override
    public List<Boutiquier> selectAll() {
        return boutiquierRepository.selectAll();
    }
    @Override
    public Boutiquier findById(int id) {
        return boutiquierRepository.findById(id);
    }
    @Override
    public void update(Boutiquier boutiquier){
        boutiquierRepository.update(boutiquier); 
    }
    @Override
    public void delete(Boutiquier boutiquier) {
        boutiquierRepository.delete(boutiquier);
    }
    @Override
    public void deleteById(int id) {
        boutiquierRepository.deleteById(id);
    }
    @Override
    public Boutiquier selectByLogin(String email) {
        return boutiquierRepository.selectByLogin(email);
    }

   
   
    


}
    

