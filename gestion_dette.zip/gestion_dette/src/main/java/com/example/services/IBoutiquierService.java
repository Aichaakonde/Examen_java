package com.example.services;

import com.example.core.IAccount;
import com.example.core.IService;
import com.example.entities.Boutiquier;

public interface IBoutiquierService extends IAccount<Boutiquier>, IService<Boutiquier> {
    Boutiquier selectByLogin(String email);
}
