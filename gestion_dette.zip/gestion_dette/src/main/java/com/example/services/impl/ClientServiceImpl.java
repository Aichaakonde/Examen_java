package com.example.services.impl;

import java.util.List;

import com.example.entities.Client;
import com.example.repositories.IClientRepository;
import com.example.services.IClientService;

public class ClientServiceImpl implements IClientService {
    private final IClientRepository clientRepository;
    
    public ClientServiceImpl(IClientRepository clientRepository) {
        this.clientRepository = clientRepository;
    }

    @Override
    public Client add(Client entity) {
        return clientRepository.add(entity);
    }

    @Override
    public List<Client> selectAll() {
        return clientRepository.selectAll();
    }

    @Override
    public Client findById(int id) {
        return clientRepository.findById(id);
    }

    @Override
    public void update(Client client) {
        clientRepository.update(client);
    }

    @Override
    public void delete(Client client) {
        clientRepository.delete(client);
    }

    @Override
    public void deleteById(int id) {
        clientRepository.deleteById(id);
    }

    public Client selectByTelephone(String telephone) {
        return clientRepository.selectByTelephone(telephone);
    }


    @Override
    public Client selectByLogin(String email) {
       return clientRepository.selectByLogin(email);
    }

   


}
